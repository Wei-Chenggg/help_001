import serial
import time
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from collections import deque

# ================= 設定區域 =================
COM_PORT = 'COM5'      # 請改成你裝置管理員看到的 COM Port
BAUD_RATE = 115200     # 必須與 C2000 程式碼一致
# ===========================================

# 初始化串列埠
try:
    ser = serial.Serial(COM_PORT, BAUD_RATE, timeout=0.1)
    print(f"成功連線到 {COM_PORT}，鮑率 {BAUD_RATE}")
except Exception as e:
    print(f"連線失敗: {e}")
    exit()

time.sleep(0.5) # 等待連線穩定

# 發送啟動指令
ser.write(b"ADC START\r\n")
print("已發送 ADC START，等待啟動回覆...")

# ================= 關鍵修正：先讀取啟動回覆 =================
# 避免啟動訊息與第一筆資料混在一起
startup_reply = ser.readline().decode('ascii', errors='ignore').strip()
print(f"收到啟動回覆: {startup_reply}")

if "OK" not in startup_reply:
    print("啟動失敗，請檢查硬體連線與 C2000 程式狀態。")
    ser.close()
    exit()

print("開始接收連續數據，準備繪圖...")

# ================= 資料緩衝與繪圖設定 =================
# 使用 deque 限制顯示的資料點數量 (例如只顯示最近 500 筆，避免記憶體無限增長)
data_buffer = deque([0]*500, maxlen=500)

fig, ax = plt.subplots()
line_obj, = ax.plot([], [], lw=1.5)
ax.set_ylim(0, 4096)
ax.set_title("Real-time ADC Stream (1000Hz)")
ax.set_xlabel("Sample Index (Recent 500 Samples)")
ax.set_ylabel("ADC Value (0-4095)")
ax.grid(True)

# 用來暫存不完整的字串片段 (例如收到 "10" 但其實是 "1028" 的前半段)
buffer_str = ""

def update_plot(frame):
    global buffer_str
    
    try:
        # 1. 讀取目前串列埠緩衝區中所有可用的位元組
        if ser.in_waiting > 0:
            raw_data = ser.read(ser.in_waiting)
            buffer_str += raw_data.decode('ascii', errors='ignore')
            
            # 2. 依照逗號分割字串
            parts = buffer_str.split(',')
            
            # 3. 將前面完整的數字轉成整數
            values = []
            for x in parts[:-1]:
                x = x.strip()
                if x:
                    try:
                        values.append(int(x))
                    except ValueError:
                        pass # 忽略突發的雜訊或非數字字元
            
            # 4. 把最後一個未完成的片段留給下一輪
            buffer_str = parts[-1]
            
            # 5. 將新資料加入顯示緩衝區
            for v in values:
                data_buffer.append(v)
                
            if values:
                # 在終端機印出部分資訊，證明資料有在跑
                print(f"收到 {len(values)} 筆: {values[:3]} ... (最後一筆: {values[-1]}) | 緩衝區剩餘: {len(data_buffer)}")
        
        # 更新圖表線條
        line_obj.set_ydata(data_buffer)
        line_obj.set_xdata(range(len(data_buffer)))
        ax.set_xlim(0, len(data_buffer))
        
        return line_obj,
        
    except Exception as e:
        # 發生錯誤時不要讓動畫崩潰
        return line_obj,

# 啟動 Matplotlib 動畫 (每 50ms 更新一次畫面)
ani = animation.FuncAnimation(fig, update_plot, interval=50, blit=True, cache_frame_data=False)

try:
    plt.show() # 顯示圖表 (這會阻塞在這裡直到你關閉視窗)
except KeyboardInterrupt:
    pass # 允許使用者在終端機按 Ctrl+C 中斷

# ================= 程式結束前的清理 =================
print("\n停止接收...")
ser.write(b"ADC STOP\r\n") # 發送停止指令
time.sleep(0.5)            # 等待 C2000 處理完畢
ser.close()
print("已停止串流並關閉連線。")