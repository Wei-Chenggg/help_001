//#############################################################################
// FILE:   adc_ex1_soc_software.c
// TITLE:  Continuous ADC Streaming with Ring Buffer (F28004x).
//
// Commands:
//   "ADC START" -> Starts continuous 1000Hz sampling & streaming
//   "ADC STOP"  -> Stops sampling & streaming
//   "DOUT 58 ON/OFF"
//#############################################################################
#include "driverlib.h"
#include "device.h"
#include <string.h>
#include <stdio.h>

#define SCI_BAUD_RATE 115200U
#define CMD_SIZE 64U
#define DOUT_GPIO 58U
#define RING_BUF_SIZE 1024U // 環形緩衝區大小 (2KB)，必須是 2 的次方

volatile uint16_t dout58 = 0U;

// 將環形緩衝區強制分配到較大的 RAMGS0 區塊，避免記憶體溢出
#pragma DATA_SECTION(ring_buf, "ramgs0");
volatile uint16_t ring_buf[RING_BUF_SIZE];
volatile uint16_t ring_head = 0U; // ISR 寫入位置
volatile uint16_t ring_tail = 0U; // 主迴圈讀取位置
volatile uint16_t overflow_flag = 0U; // 溢位標記
volatile uint32_t total_overflow_count = 0U; // 累計丟失筆數 (新增)
volatile uint8_t streaming_enabled = 0U; // 串流開關

// 寫入字串到 SCI
void sci_write(const char *msg)
{
    while(*msg != '\0')
    {
        SCI_writeCharBlockingFIFO(SCIA_BASE, (uint16_t)*msg);
        msg++;
    }
}

// 讀取 ADC A0 (在 ISR 中呼叫)
uint16_t read_adc0(void)
{
    ADC_forceSOC(ADCA_BASE, ADC_SOC_NUMBER0);
    while(ADC_getInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1) == false)
    {
    }
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);
    return ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0);
}

// =========================================================
// CPUTimer0 中斷服務函數 (每 1ms 觸發一次)
// =========================================================
__interrupt void cpuTimer0ISR(void)
{
    if (streaming_enabled)
    {
        uint16_t val = read_adc0(); // 觸發並讀取 ADC
        
        // 使用位元運算 (&) 取代取餘數 (%)，速度更快
        uint16_t next_head = (ring_head + 1U) & (RING_BUF_SIZE - 1U);
        
        if (next_head != ring_tail)
        {
            ring_buf[ring_head] = val;
            ring_head = next_head;
        }
        else
        {
            overflow_flag = 1U; // 緩衝區滿了，標記溢位
            total_overflow_count++; // 累計丟失筆數 (新增)
        }
    }
    
    // 清除中斷旗標
    CPUTimer_clearOverflowFlag(CPUTIMER0_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

void execute_cmd(const char *cmd)
{
    if(strcmp(cmd, "ADC START") == 0)
    {
        ring_head = 0U;
        ring_tail = 0U;
        overflow_flag = 0U;
        total_overflow_count = 0U; // 重置丟失筆數 (新增)
        streaming_enabled = 1U;
        CPUTimer_startTimer(CPUTIMER0_BASE);
        sci_write("OK ADC STREAMING STARTED\r\n");
    }
    else if(strcmp(cmd, "ADC STOP") == 0)
    {
        streaming_enabled = 0U;
        CPUTimer_stopTimer(CPUTIMER0_BASE);
        sci_write("OK ADC STREAMING STOPPED\r\n");
    }
    else if(strcmp(cmd, "DOUT 58 ON") == 0)
    {
        GPIO_writePin(DOUT_GPIO, 1U);
        dout58 = 1U;
        sci_write("OK DOUT 58 ON\r\n");
    }
    else if(strcmp(cmd, "DOUT 58 OFF") == 0)
    {
        GPIO_writePin(DOUT_GPIO, 0U);
        dout58 = 0U;
        sci_write("OK DOUT 58 OFF\r\n");
    }
    else
    {
        sci_write("ERR INVALID CMD\r\n");
    }
}

void main(void)
{
    char cmd[CMD_SIZE];
    uint16_t cmdLength = 0U;
    uint16_t cmdError = 0U;
    uint16_t receivedChar;
    int j; // C89 標準

    Device_init();
    Device_initGPIO();
    DINT;

    // --- 修正 1：初始化 PIE 中斷控制器與向量表 (評估報告指出的缺漏) ---
    Interrupt_initModule();
    Interrupt_initVectorTable();

    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_SCIA);

    // --- 初始化 CPUTimer0 為 1ms 週期中斷 ---
    CPUTimer_setEmulationMode(CPUTIMER0_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_setPeriod(CPUTIMER0_BASE, 100000U - 1U);
    CPUTimer_setPreScaler(CPUTIMER0_BASE, 0U);
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    
    Interrupt_register(INT_TIMER0, &cpuTimer0ISR);
    Interrupt_enable(INT_TIMER0);
    CPUTimer_enableInterrupt(CPUTIMER0_BASE);

    // --- SCI-A 引腳設定 ---
    GPIO_setControllerCore(DEVICE_GPIO_PIN_SCIRXDA, GPIO_CORE_CPU1);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_SCIRXDA);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_SCIRXDA, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(DEVICE_GPIO_PIN_SCIRXDA, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(DEVICE_GPIO_PIN_SCIRXDA, GPIO_QUAL_ASYNC);

    GPIO_setControllerCore(DEVICE_GPIO_PIN_SCITXDA, GPIO_CORE_CPU1);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_SCITXDA);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_SCITXDA, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(DEVICE_GPIO_PIN_SCITXDA, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(DEVICE_GPIO_PIN_SCITXDA, GPIO_QUAL_ASYNC);

    // --- DOUT GPIO58 設定 ---
    GPIO_setControllerCore(DOUT_GPIO, GPIO_CORE_CPU1);
    GPIO_setPinConfig(GPIO_58_GPIO58);
    GPIO_setPadConfig(DOUT_GPIO, GPIO_PIN_TYPE_STD);
    GPIO_writePin(DOUT_GPIO, 0U);
    GPIO_setDirectionMode(DOUT_GPIO, GPIO_DIR_MODE_OUT);

    // --- SCI 初始化 ---
    SCI_performSoftwareReset(SCIA_BASE);
    SCI_setConfig(SCIA_BASE, DEVICE_LSPCLK_FREQ, SCI_BAUD_RATE,
                  SCI_CONFIG_WLEN_8 | SCI_CONFIG_STOP_ONE | SCI_CONFIG_PAR_NONE);
    SCI_disableLoopback(SCIA_BASE);
    SCI_resetChannels(SCIA_BASE);
    SCI_resetRxFIFO(SCIA_BASE);
    SCI_resetTxFIFO(SCIA_BASE);
    SCI_clearOverflowStatus(SCIA_BASE);
    SCI_clearInterruptStatus(SCIA_BASE, SCI_INT_TXFF | SCI_INT_RXFF);
    SCI_enableFIFO(SCIA_BASE);
    SCI_enableModule(SCIA_BASE);
    SCI_performSoftwareReset(SCIA_BASE);

    // --- ADC 初始化 ---
    ADC_setVREF(ADCA_BASE, ADC_REFERENCE_INTERNAL, ADC_REFERENCE_3_3V);
    ADC_setPrescaler(ADCA_BASE, ADC_CLK_DIV_2_0);
    ADC_setInterruptPulseMode(ADCA_BASE, ADC_PULSE_END_OF_CONV);
    ADC_setupSOC(ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_SW_ONLY,
                 ADC_CH_ADCIN0, 8);
    ADC_setInterruptSource(ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
    
    // --- 修正 2：啟用 ADC 中斷來源並清除旗標 (評估報告指出的缺漏) ---
    ADC_enableInterrupt(ADCA_BASE, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);
    
    ADC_enableConverter(ADCA_BASE);
    DEVICE_DELAY_US(1000);

    EINT; // 啟用全域中斷
    ERTM; // 啟用即時中斷 (C2000 必備！)

    for(;;)
    {
        // --- 1. 接收並解析 SCI 指令 (非阻塞模式) ---
        if (SCI_getRxFIFOStatus(SCIA_BASE) != SCI_FIFO_RX0)
        {
            receivedChar = SCI_readCharNonBlocking(SCIA_BASE);
            
            if((SCI_getRxStatus(SCIA_BASE) & SCI_RXSTATUS_ERROR) != 0U ||
               SCI_getOverflowStatus(SCIA_BASE))
            {
                SCI_performSoftwareReset(SCIA_BASE);
                SCI_resetRxFIFO(SCIA_BASE);
                SCI_clearOverflowStatus(SCIA_BASE);
                cmdLength = 0U;
                cmdError = 3U;
                continue;
            }
            
            if(receivedChar == '\r' || receivedChar == '\n')
            {
                if(cmdError == 1U) { sci_write("ERR COMMAND_TOO_LONG\r\n"); }
                else if(cmdError == 2U) { sci_write("ERR INVALID_CHARACTER\r\n"); }
                else if(cmdError == 3U) { sci_write("ERR SCI_RX\r\n"); }
                else if(cmdLength > 0U)
                {
                    cmd[cmdLength] = '\0';
                    execute_cmd(cmd);
                }
                cmdLength = 0U;
                cmdError = 0U;
            }
            else if(cmdError == 0U)
            {
                if(receivedChar < 32U || receivedChar > 126U) { cmdError = 2U; }
                else if(cmdLength < CMD_SIZE - 1U) { cmd[cmdLength++] = (char)receivedChar; }
                else { cmdError = 1U; }
            }
        }

        // --- 2. 持續從環形緩衝區傳輸資料 ---
        while (ring_tail != ring_head)
        {
            char num_buf[16];
            int len = sprintf(num_buf, "%u,", (unsigned int)ring_buf[ring_tail]);
            for(j = 0; j < len; j++)
            {
                while(SCI_getTxFIFOStatus(SCIA_BASE) == SCI_FIFO_TX16) {}
                SCI_writeCharBlockingFIFO(SCIA_BASE, num_buf[j]);
            }
            ring_tail = (ring_tail + 1U) & (RING_BUF_SIZE - 1U);
        }

        // --- 3. 檢查緩衝區是否溢位 ---
        if (overflow_flag)
        {
            overflow_flag = 0U;
            // 這裡可以選擇發送警告，但為了不干擾資料流，目前不發送
            // 你可以透過偵錯模式觀察 total_overflow_count 來確認是否有丟失資料
        }
    }
}