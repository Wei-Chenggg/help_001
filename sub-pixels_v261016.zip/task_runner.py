import os
import time
import numpy as np
from scipy.special import expit
from scipy.ndimage import shift as ndshift
import matplotlib
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting


class Global_LK:
    """
    Global Lucas-Kanade：對整張圖做線性化的亮度守恆方程，
    最小平方解出全域平移 (dx, dy)。

        Ix·dx + Iy·dy = -(I1 - I0)

    支援可選的「Canny-LSQ 粗估 + shift 對齊」前處理：
      lsq_init=False（預設）：直接對原圖解 LK。
      lsq_init=True：
        1. Canny-LSQ 分別找 img0, img1 圓心 → d_coarse = c1 - c0
        2. 反向 shift img1 d_coarse → 對齊到 img0 座標系
        3. 對齊後解 Global-LK → 殘差 d_fine
        4. 回傳 d_coarse + d_fine

    lsq_init=True 的動機：
      純 LK 直接對未對齊的兩張圖解 lstsq，當位移大時
      Ix·dx + Iy·dy ≈ -It 的一階近似失效（It 太大、梯度採樣點錯位）；
      先用 LSQ 消掉大位移，LK 只需解小殘差，線性化誤差大幅下降。
    """
    @staticmethod
    def _grad_central(I):
        """中央差分梯度（避開邊界 one-sided difference 的誤差）。"""
        Ix = np.zeros_like(I)
        Iy = np.zeros_like(I)
        Ix[:, 1:-1] = (I[:, 2:] - I[:, :-2]) / 2.0
        Iy[1:-1, :] = (I[2:, :] - I[:-2, :]) / 2.0
        return Ix, Iy

    @staticmethod
    def predict_dxy(img0, img1, border=1,
                    lsq_init=False, canny_low=50, canny_high=150):
        I0 = img0.astype(np.float64)
        I1 = img1.astype(np.float64)

        # ---- 可選：LSQ 粗估 + shift 對齊 ----
        d_coarse = np.zeros(2, dtype=np.float64)
        if lsq_init:
            c0 = Canny_LSQ.predict_center(img0, canny_low, canny_high)
            c1 = Canny_LSQ.predict_center(img1, canny_low, canny_high)
            d_coarse = c1 - c0
            # 反向 shift img1，使 I1_aligned(p) = I1(p + d_coarse)
            I1 = ndshift(
                I1,
                shift=(-d_coarse[1], -d_coarse[0]),
                order=1,
                mode="nearest",
            )

        # ---- Global-LK ----
        Ix, Iy = Global_LK._grad_central(I0)
        It = I1 - I0
        sl = (slice(border, -border), slice(border, -border))
        A = np.stack([Ix[sl].ravel(), Iy[sl].ravel()], axis=1)
        b = -It[sl].ravel()
        d_fine, *_ = np.linalg.lstsq(A, b, rcond=None)

        return d_coarse + d_fine


class Canny_LSQ:
    def __init__(self, img, canny_low=50, canny_high=150):
        self.img = img
        self.canny_low = canny_low
        self.canny_high = canny_high
        self.cx = None
        self.cy = None
        self.r = None
        self.n_pts = 0
        self.pts = None
        self.edges = None
        self.pfit = None
        self.trained = False
    def learn(self):
        self.edges = Imgtool(self.img.astype(np.uint8)).canny(
            low=self.canny_low, high=self.canny_high)
        ys, xs = np.where(self.edges > 0)
        self.pts = np.column_stack([xs, ys]).astype(np.float64)
        self.n_pts = int(self.pts.shape[0])
        z = self.pts[:, 0] ** 2 + self.pts[:, 1] ** 2
        self.pfit = Poly_Fitting(basis="泰勒")
        self.pfit.learn(
            self.pts, z,
            order=[[0, 0], [1, 0], [0, 1]],
        )
        w = self.pfit.w
        self.cx = float(w[1]) / 2.0
        self.cy = float(w[2]) / 2.0
        inside = float(w[0]) + self.cx ** 2 + self.cy ** 2
        self.r = float(np.sqrt(max(inside, 0.0)))
        self.trained = True
        return self
    def forward(self, img):
        inst = Canny_LSQ(img, self.canny_low, self.canny_high).learn()
        return inst.center()
    def center(self):
        return np.array([self.cx, self.cy])
    def result(self):
        return {"cx": self.cx, "cy": self.cy, "r": self.r,
                "n_pts": self.n_pts}
    @staticmethod
    def inspect(img, canny_low=50, canny_high=150):
        inst = Canny_LSQ(img, canny_low, canny_high).learn()
        return {"pts": inst.pts, "xy_mean": inst.center(),
                "r_mean": inst.r, "edges": inst.edges}
    @classmethod
    def predict_center(cls, img, canny_low=50, canny_high=150):
        return cls(img, canny_low, canny_high).learn().center()


class Canny_Mean:
    def __init__(self, img, canny_low=50, canny_high=150):
        self.img = img
        self.canny_low = canny_low
        self.canny_high = canny_high
        self.cx = None
        self.cy = None
        self.r = None
        self.n_pts = 0
        self.pts = None
        self.edges = None
        self.trained = False
    def learn(self):
        self.edges = Imgtool(self.img.astype(np.uint8)).canny(
            low=self.canny_low, high=self.canny_high)
        ys, xs = np.where(self.edges > 0)
        self.pts = np.column_stack([xs, ys]).astype(np.float64)
        xy_mean = self.pts.mean(axis=0)
        self.cx = float(xy_mean[0])
        self.cy = float(xy_mean[1])
        self.r = float(np.mean(np.linalg.norm(self.pts - xy_mean, axis=1)))
        self.n_pts = int(self.pts.shape[0])
        self.trained = True
        return self
    def forward(self, img):
        inst = Canny_Mean(img, self.canny_low, self.canny_high).learn()
        return inst.center()
    def center(self):
        return np.array([self.cx, self.cy])
    def result(self):
        return {"cx": self.cx, "cy": self.cy, "r": self.r,
                "n_pts": self.n_pts}
    @staticmethod
    def inspect(img, canny_low=50, canny_high=150):
        inst = Canny_Mean(img, canny_low, canny_high).learn()
        return {"pts": inst.pts, "xy_mean": inst.center(),
                "r_mean": inst.r, "edges": inst.edges}
    @classmethod
    def predict_center(cls, img, canny_low=50, canny_high=150):
        return cls(img, canny_low, canny_high).learn().center()


class GD_Circle_Fit:
    @staticmethod
    def _sigmoid(z):
        return expit(z)
    def __init__(self,
                 cen_init_method="canny_mean",
                 lr=0.1, tau=2.0, margin=20.0,
                 epoch=10000, early_stop=1e-6,
                 debug=False, log_every=0):
        self.cen_init_method = cen_init_method
        self.tau = float(tau)
        self.lr = lr
        self.margin = margin
        self.epoch = epoch
        self.early_stop = early_stop
        self.debug = debug
        self.log_every = log_every
        self.cx = None
        self.cy = None
        self.r  = None
        self.init_cx = None
        self.init_cy = None
        self.init_r  = None
        self._reset_state()
    def _reset_state(self):
        self.m = {"cx": 0.0, "cy": 0.0, "r": 0.0}
        self.v = {"cx": 0.0, "cy": 0.0, "r": 0.0}
        self.beta1, self.beta2, self.eps = 0.9, 0.999, 1e-8
        self.loss_hist = []
        self.loss = None
        self.trained = False
        self.n_iter = 0
        self.early_stopped = False
        self.stop_iter = None
    @staticmethod
    def _canny_pts(img, canny_low=50, canny_high=150):
        edges = Imgtool(img.astype(np.uint8)).canny(low=canny_low, high=canny_high)
        ys, xs = np.where(edges > 0)
        return np.column_stack([xs, ys]).astype(np.float64)
    def _init_by_canny_mean(self, img):
        pts = self._canny_pts(img)
        xy_mean = pts.mean(axis=0)
        cx = float(xy_mean[0])
        cy = float(xy_mean[1])
        r  = float(np.mean(np.linalg.norm(pts - xy_mean, axis=1)))
        return cx, cy, r
    def _init_by_canny_lsq(self, img):
        pts = self._canny_pts(img)
        z = pts[:, 0] ** 2 + pts[:, 1] ** 2
        pfit = Poly_Fitting(basis="泰勒")
        pfit.learn(pts, z, order=[[0, 0], [1, 0], [0, 1]])
        w = pfit.w
        cx = float(w[1]) / 2.0
        cy = float(w[2]) / 2.0
        inside = float(w[0]) + cx ** 2 + cy ** 2
        r = float(np.sqrt(max(inside, 0.0)))
        return cx, cy, r
    def _get_init_circle(self, img):
        if self.cen_init_method == "canny_mean":
            cx, cy, r = self._init_by_canny_mean(img)
        elif self.cen_init_method == "canny_lsq":
            cx, cy, r = self._init_by_canny_lsq(img)
        else:
            raise ValueError(f"unknown cen_init_method: {self.cen_init_method}")
        self.cx = cx
        self.cy = cy
        self.r  = r
        self.init_cx = cx
        self.init_cy = cy
        self.init_r  = r
        return self
    def _set_init_circle(self, cx, cy, r):
        self.cx = float(cx)
        self.cy = float(cy)
        self.r  = float(r)
        self.init_cx = self.cx
        self.init_cy = self.cy
        self.init_r  = self.r
        return self
    def _init_roi(self, img, margin):
        H, W = img.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
        d0 = np.sqrt((xx - self.cx) ** 2 + (yy - self.cy) ** 2)
        roi = np.abs(d0 - self.r) < margin
        self.xs = xx[roi].copy()
        self.ys = yy[roi].copy()
        self.vs = img[roi].astype(np.float64)
        self.N = float(self.xs.size)
        self.n_roi = int(self.xs.size)
        return self
    def _forward(self):
        dx = self.xs - self.cx
        dy = self.ys - self.cy
        d = np.sqrt(dx * dx + dy * dy) + 1e-6
        z = (self.r - d) / self.tau
        sig = self._sigmoid(z)
        res = 255.0 * sig - self.vs
        loss = float(np.mean(res ** 2))
        return dx, dy, d, sig, res, loss
    def _gradient(self, dx, dy, d, sig, res):
        dsig = sig * (1.0 - sig)
        common = 255.0 * dsig / self.tau
        return {
            "cx": 2.0 * float(np.sum(res * common * dx / d)) / self.N,
            "cy": 2.0 * float(np.sum(res * common * dy / d)) / self.N,
            "r":  2.0 * float(np.sum(res * common))           / self.N,
        }
    def _adam_step(self, t, g):
        for k in ("cx", "cy", "r"):
            self.m[k] = self.beta1 * self.m[k] + (1 - self.beta1) * g[k]
            self.v[k] = self.beta2 * self.v[k] + (1 - self.beta2) * g[k] * g[k]
            m_h = self.m[k] / (1 - self.beta1 ** t)
            v_h = self.v[k] / (1 - self.beta2 ** t)
            step = self.lr * m_h / (np.sqrt(v_h) + self.eps)
            if   k == "cx": self.cx -= step
            elif k == "cy": self.cy -= step
            else:           self.r = max(self.r - step, 1.0)
    def _debug_first_iter(self, t):
        if self.debug and t == 1:
            print(f"[debug] t={t}, cx={self.cx:.3f}, cy={self.cy:.3f}, "
                  f"r={self.r:.3f}, tau={self.tau:.3f}")
            print(f"[debug] roi N={self.n_roi}")
    def _log_epoch(self, t, loss):
        if self.log_every and (t == 1 or t % self.log_every == 0 or t == self.epoch):
            print(f"  [epoch {t:5d}] loss={loss:10.4f}  "
                  f"cx={self.cx:9.4f}  cy={self.cy:9.4f}  r={self.r:9.4f}")
    def learn(self, img, init_circle=None):
        """
        init_circle : (cx, cy, r) or None
            若給定，跳過 _get_init_circle，直接用此初值。
            用於「外部提供初值」（例如 Global-LK 位移後的圓心）。
        """
        self._reset_state()
        if init_circle is not None:
            self._set_init_circle(*init_circle)
        else:
            self._get_init_circle(img)
        self._init_roi(img, self.margin)
        prev_loss = None
        t_start = time.perf_counter()
        for t in range(1, self.epoch + 1):
            self._debug_first_iter(t)
            dx, dy, d, sig, res, loss = self._forward()
            if not np.isfinite(res).all():
                self.loss = float("inf")
                self.n_iter = t
                self.trained = True
                return self
            self.loss_hist.append(loss)
            self.loss = loss
            self.n_iter = t
            self._log_epoch(t, loss)
            if self.early_stop is not None and prev_loss is not None:
                rel = abs(prev_loss - loss) / (abs(prev_loss) + 1e-12)
                if rel < self.early_stop:
                    self.trained = True
                    self.early_stopped = True
                    self.stop_iter = t
                    dt = time.perf_counter() - t_start
                    print(f"  [early-stop] iter={t:5d}  "
                          f"loss={loss:.6f}  Δrel={rel:.3e} < {self.early_stop:.1e}  "
                          f"time={dt:.4f}s")
                    break
            prev_loss = loss
            g = self._gradient(dx, dy, d, sig, res)
            self._adam_step(t, g)
        self.trained = True
        return self
    def predict_center(self, img):
        return self.learn(img).center()
    def center(self):
        return np.array([self.cx, self.cy])
    def result(self):
        return {"cx": self.cx,
                "cy": self.cy,
                "r":  self.r,
                "cen_init_method": self.cen_init_method,
                "init_cx": self.init_cx,
                "init_cy": self.init_cy,
                "init_r":  self.init_r,
                "loss": self.loss,
                "n_iter": self.n_iter,
                "n_roi": self.n_roi,
                "loss_hist": self.loss_hist,
                "early_stopped": self.early_stopped,
                "stop_iter": self.stop_iter}


class Sub_Pixel_Task_Runner:
    def __init__(self, chart_folder="./charts/chart0/2000x2000",
                 noise_sigma=0.0, noise_seed=None):
        self.chart_folder = chart_folder
        self.charts = self.load_chart(chart_folder=chart_folder)
        self.algorithm_name = ""
        self.algorithm_flow = None
        self.algorithm_mode = "single"
        self.last_results = None
        self.last_time = 0.0
        self.noise_sigma = float(noise_sigma)
        self.noise_seed = noise_seed
        self._trial = 0
    @staticmethod
    def load_chart(fpath=None, chart_folder=None, accept=None, reject=None, sort=True):
        if fpath is not None:
            return load_pkl(fpath)
        files = get_files(chart_folder, types=["pkl"], accept=accept, reject=reject)
        if sort:
            files = sorted(files, key=lambda t: t[2])
        out = []
        for idx, path, name, sub_name in files:
            d = load_pkl(path)
            out.append({"name": name, "path": path, "img0": d["img0"], "img1": d["img1"], "dxy": d["dxy"]})
        return out
    @staticmethod
    def _fmt(xy, nd=4):
        return f"({xy[0]:.{nd}f}, {xy[1]:.{nd}f})"
    @staticmethod
    def get_error(pred_dxy, gt_dxy=None, label="", verbose=True):
        if gt_dxy is None:
            errs = pred_dxy
            ex = np.array([r["ex"] for r in errs])
            ey = np.array([r["ey"] for r in errs])
            ee = np.array([r["e"] for r in errs])
            if verbose:
                print(f"\n  summary over {len(errs)} chart(s):")
                print(f"    |位移dy誤差(px)|     : mean={ex.mean():.4f}  max={ex.max():.4f}")
                print(f"    |位移dx誤差(px)|     : mean={ey.mean():.4f}  max={ey.max():.4f}")
                print(f"    |位移長度(px)| : mean={ee.mean():.4f}  max={ee.max():.4f}")
            return {"ex": ex, "ey": ey, "e": ee}
        pred = np.asarray(pred_dxy, dtype=float)
        gt = np.asarray(gt_dxy, dtype=float)
        e = pred - gt
        ex, ey = abs(e[0]), abs(e[1])
        dist = float(np.linalg.norm(e))
        if verbose:
            print(f"      pred = {Sub_Pixel_Task_Runner._fmt(pred)}")
            print(f"      gt   = {Sub_Pixel_Task_Runner._fmt(gt)}")
            print(f"      |ex|={ex:.4f}  |ey|={ey:.4f}  |e|={dist:.4f}")
        return {"ex": ex, "ey": ey, "e": dist}
    def set_algorithm_flow(self, algorithm_name="", func=None):
        """func(img) -> (cx, cy)"""
        self.algorithm_name = algorithm_name
        self.algorithm_flow = func
        self.algorithm_mode = "single"
        return self
    def set_algorithm_flow_pair(self, algorithm_name="", func=None):
        """func(img0, img1) -> (dx, dy)"""
        self.algorithm_name = algorithm_name
        self.algorithm_flow = func
        self.algorithm_mode = "pair"
        return self
    def set_noise(self, sigma=0.0, seed=None):
        """設定雜訊等級與（可選）seed，並重置 trial counter。"""
        self.noise_sigma = float(sigma)
        self.noise_seed = seed
        self._trial = 0
        return self
    @staticmethod
    def _add_noise(img, sigma, rng):
        if sigma <= 0:
            return img
        noise = rng.normal(0.0, sigma, size=img.shape)
        return np.clip(img + noise, 0.0, 255.0)
    def _prepare_imgs(self, c):
        if self.noise_sigma <= 0:
            return c["img0"], c["img1"]
        if self.noise_seed is None:
            rng = np.random.default_rng()
        else:
            rng = np.random.default_rng(self.noise_seed + self._trial)
        img0 = self._add_noise(c["img0"], self.noise_sigma, rng)
        img1 = self._add_noise(c["img1"], self.noise_sigma, rng)
        return img0, img1
    def run(self, verbose=True):
        if self.algorithm_flow is None:
            raise ValueError("algorithm_flow not set")
        results = []
        t0 = time.perf_counter()
        for c in self.charts:
            img0, img1 = self._prepare_imgs(c)
            if self.algorithm_mode == "single":
                c0 = np.asarray(self.algorithm_flow(img0), dtype=float)
                c1 = np.asarray(self.algorithm_flow(img1), dtype=float)
                pred = c1 - c0
            elif self.algorithm_mode == "pair":
                pred = np.asarray(self.algorithm_flow(img0, img1), dtype=float)
            else:
                raise ValueError(f"unknown algorithm_mode: {self.algorithm_mode!r}")
            err = self.get_error(pred, c["dxy"], verbose=False)
            results.append({"name": c["name"], "path": c["path"],
                            "img0": img0, "img1": img1,
                            "pred": pred, "gt": c["dxy"], "err": err})
        t1 = time.perf_counter()
        self.last_results = results
        self.last_time = t1 - t0
        if verbose:
            noise_info = f"noise_sigma={self.noise_sigma}" if self.noise_sigma > 0 else "noise=off"
            print(f"\n--- algorithm: {self.algorithm_name}  [{noise_info}, trial={self._trial}, mode={self.algorithm_mode}] ---")
            for r in results:
                print(f"\n  chart    : {r['path']}")
                print(f"  圖片大小 : {r['img0'].shape}")
                print(f"  真實位移 : {self._fmt(r['gt'])}")
                print(f"  預測位移 : {self._fmt(r['pred'])}")
                self.get_error(r["pred"], r["gt"], verbose=True)
            print(f"\n[Cost time] run : {self.last_time:.4f} s  ({(self.last_time) / max(len(results), 1) * 1000:.2f} ms/chart)")
        self._trial += 1
        return results
    def print_summary(self, all_results):
        print("\n" + "=" * 76)
        print("  最終結果彙總")
        print("=" * 76)
        print(f"  {'algorithm':<16}  {'|dy err|':>10}  {'|dx err|':>10}  {'|len err|':>10}  {'ms/chart':>10}")
        print("  " + "-" * 72)
        for entry in all_results:
            name = entry["name"]
            results = entry["results"]
            t_total = entry["t_total"]
            ex = np.array([r["err"]["ex"] for r in results])
            ey = np.array([r["err"]["ey"] for r in results])
            ee = np.array([r["err"]["e"]  for r in results])
            n = max(len(results), 1)
            print(f"  {name:<16}  {ex.mean():>10.4f}  {ey.mean():>10.4f}  {ee.mean():>10.4f}  {t_total / n * 1000:>10.2f}")
        print("=" * 76)
    def debug_one(self, idx=0, **gd_kwargs):
        c = self.charts[idx]
        print(f"\n--- single chart: {c['name']} ---")
        t0 = time.perf_counter()
        fit0 = GD_Circle_Fit(**gd_kwargs).learn(c["img0"])
        fit1 = GD_Circle_Fit(**gd_kwargs).learn(c["img1"])
        t1 = time.perf_counter()
        pred = fit1.center() - fit0.center()
        r0 = fit0.result()
        r1 = fit1.result()
        print(f"  [fit0] init : cx={r0['init_cx']:9.4f}  cy={r0['init_cy']:9.4f}  r={r0['init_r']:9.4f}")
        print(f"  [fit1] init : cx={r1['init_cx']:9.4f}  cy={r1['init_cy']:9.4f}  r={r1['init_r']:9.4f}")
        print(f"\n  fit0: cx={r0['cx']:9.4f}  cy={r0['cy']:9.4f}  r={r0['r']:9.4f}  "
              f"loss={r0['loss']:10.4f}  n_iter={r0['n_iter']:5d}  n_roi={r0['n_roi']}  "
              f"early_stopped={r0['early_stopped']}")
        print(f"  fit1: cx={r1['cx']:9.4f}  cy={r1['cy']:9.4f}  r={r1['r']:9.4f}  "
              f"loss={r1['loss']:10.4f}  n_iter={r1['n_iter']:5d}  n_roi={r1['n_roi']}  "
              f"early_stopped={r1['early_stopped']}")
        print(f"  pred dxy = {self._fmt(pred)}")
        print(f"  gt   dxy = {self._fmt(c['dxy'])}")
        print(f"  [time] gd : {t1 - t0:.4f} s")
        self.get_error(pred, c["dxy"], label=c["name"])
        return pred, fit0, fit1


if __name__ == "__main__":
    runner = Sub_Pixel_Task_Runner(chart_folder="./charts/chart0/400x400")
    print(f"found {len(runner.charts)} chart(s)")

    all_results = []

    # 1. canny-mean（單圖模式：分別找 c0, c1，相減）
    runner.set_algorithm_flow("canny-mean", Canny_Mean.predict_center).run()
    all_results.append({"name": "canny-mean",
                        "results": runner.last_results,
                        "t_total": runner.last_time})

    # 2. canny-lsq
    runner.set_algorithm_flow("canny-lsq", Canny_LSQ.predict_center).run()
    all_results.append({"name": "canny-lsq",
                        "results": runner.last_results,
                        "t_total": runner.last_time})

    # 3. gray-grad（GD_Circle_Fit，Canny-LSQ init）
    hpr_lsq = GD_Circle_Fit(
        cen_init_method="canny_lsq",
        lr=0.1, tau=2.0, margin=20.0,
        epoch=10000, early_stop=1e-9,
    )
    runner.set_algorithm_flow("gray-grad", hpr_lsq.predict_center).run()
    all_results.append({"name": "gray-grad",
                        "results": runner.last_results,
                        "t_total": runner.last_time})

    # 4. global-lk（純全域 LK）
    runner.set_algorithm_flow_pair(
        "global-lk",
        lambda img0, img1: Global_LK.predict_dxy(img0, img1, lsq_init=False),
    ).run()
    all_results.append({"name": "global-lk",
                        "results": runner.last_results,
                        "t_total": runner.last_time})

    # 5. global-lk(lsq-init)（LSQ 粗估 → shift → LK）
    runner.set_algorithm_flow_pair(
        "global-lk(lsq-init)",
        lambda img0, img1: Global_LK.predict_dxy(img0, img1, lsq_init=True),
    ).run()
    all_results.append({"name": "global-lk(lsq-init)",
                        "results": runner.last_results,
                        "t_total": runner.last_time})

    runner.print_summary(all_results)