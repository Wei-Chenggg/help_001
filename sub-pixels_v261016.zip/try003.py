import os
import time
import numpy as np
from scipy.special import expit
import matplotlib
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting
from task_runner import *


def plot_err_vs_gt(all_results, logx=False, logy=False):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    for entry in all_results:
        name = entry["name"]
        results = entry["results"]

        # ---- dx 圖：x = |dx_gt|, y = |dx err| ----
        xs = np.array([float(np.asarray(r["gt"], dtype=float)[0]) for r in results])
        ys = np.array([float(r["err"]["ex"]) for r in results])
        idx = np.argsort(np.abs(xs))
        axes[0].plot(np.abs(xs[idx]), ys[idx], marker="o", lw=1.5, label=name)

        # ---- dy 圖：x = |dy_gt|, y = |dy err| ----
        xs = np.array([float(np.asarray(r["gt"], dtype=float)[1]) for r in results])
        ys = np.array([float(r["err"]["ey"]) for r in results])
        idx = np.argsort(np.abs(xs))
        axes[1].plot(np.abs(xs[idx]), ys[idx], marker="o", lw=1.5, label=name)

    axes[0].set_xlabel("|dx_gt| (px)")
    axes[0].set_ylabel("|dx err| (px)")
    axes[0].set_title("dx error vs dx ground truth")
    axes[1].set_xlabel("|dy_gt| (px)")
    axes[1].set_ylabel("|dy err| (px)")
    axes[1].set_title("dy error vs dy ground truth")

    for ax in axes:
        ax.grid(True, which="both", ls="--", alpha=0.4)
        ax.legend()
        if logx:
            ax.set_xscale("log")
        if logy:
            ax.set_yscale("log")

    plt.tight_layout()
    plt.show()


def plot_err_table(all_results, sort_by_gt=True,
                   vmin=-6, vmax=-1,
                   cmap="RdYlGn_r",
                   floor=1e-16,
                   fmt_small=1e-3,
                   fontsize=7,
                   ):
    """
    表格熱圖：rows = 演算法，cols = chart。
    - vmin / vmax : log10(err) 的 colormap 邊界
                    預設 vmin=-6 (err=1e-6) → 綠
                         vmax=-1 (err=1e-1) → 紅
                    傳 None 讓 matplotlib 自動決定
    - cmap        : colormap
    - floor       : err 下限，避免 log10(0)
    - fmt_small   : 小於此值用科學記號印
    """
    import matplotlib.pyplot as plt

    names = [e["name"] for e in all_results]
    n_methods = len(names)

    ref = all_results[0]["results"]
    gt_xs = np.array([float(np.asarray(r["gt"], dtype=float)[0]) for r in ref])
    gt_ys = np.array([float(np.asarray(r["gt"], dtype=float)[1]) for r in ref])
    n_charts = len(gt_xs)

    order = np.argsort(gt_xs) if sort_by_gt else np.arange(n_charts)

    err_dx = np.array([[float(r["err"]["ex"]) for r in e["results"]] for e in all_results])[:, order]
    err_dy = np.array([[float(r["err"]["ey"]) for r in e["results"]] for e in all_results])[:, order]
    gt_xs_sorted = gt_xs[order]
    gt_ys_sorted = gt_ys[order]

    show_dx = np.maximum(err_dx, floor)
    show_dy = np.maximum(err_dy, floor)

    fig_h = max(6.0, 2.2 * n_methods + 3.0) // 2
    fig_w = max(11.0, 1.4 * n_charts + 3.0) // 2
    fig, axes = plt.subplots(2, 1, figsize=(fig_w, fig_h))

    for ax, data, gt_vals, title in [
        (axes[0], show_dx, gt_xs_sorted, "|dx err|"),
        (axes[1], show_dy, gt_ys_sorted, "|dy err|"),
    ]:
        log_data = np.log10(data)

        im = ax.imshow(
            log_data,
            aspect="auto",
            cmap=cmap,
            vmin=vmin,
            vmax=vmax,
        )

        ax.set_xticks(range(n_charts))
        ax.set_xticklabels([f"{v:+.4g}" for v in gt_vals], rotation=45, ha="right", fontsize=8)
        ax.set_yticks(range(n_methods))
        ax.set_yticklabels(names, fontsize=9)

        vmin_s = f"{vmin:g}" if vmin is not None else "auto"
        vmax_s = f"{vmax:g}" if vmax is not None else "auto"
        # ax.set_title(f"{title}   (bg = log10 err, cmap range [{vmin_s}, {vmax_s}])")
        ax.set_xlabel("ground truth (px)")

        ax.set_xticks(np.arange(-0.5, n_charts, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, n_methods, 1), minor=True)
        ax.grid(which="minor", color="black", lw=0.6)
        ax.tick_params(which="minor", length=0)

        for i in range(n_methods):
            for j in range(n_charts):
                v = data[i, j]
                if v < fmt_small:
                    txt = f"{v:.2e}"
                else:
                    txt = f"{v:.4f}"
                ax.text(j, i, txt, ha="center", va="center", fontsize=fontsize, color="black")

        cb = plt.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
        cb.set_label("log10(err)")

    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    chart_folder = "./charts/chart0/400x400"
    # chart_folder = "./charts/chart0/2000x2000"
    runner = Sub_Pixel_Task_Runner(chart_folder=chart_folder)
    print(f"found {len(runner.charts)} chart(s) in {chart_folder}")

    all_results = []

    runner.set_algorithm_flow("canny-mean", Canny_Mean.predict_center).run(verbose=False)
    all_results.append({"name": "canny-mean", "results": runner.last_results, "t_total": runner.last_time})

    runner.set_algorithm_flow("canny-lsq", Canny_LSQ.predict_center).run(verbose=False)
    all_results.append({"name": "canny-lsq", "results": runner.last_results, "t_total": runner.last_time})

    hpr_mean = GD_Circle_Fit(
        cen_init_method="canny_mean",
        lr=0.1, tau=2.0, margin=10.0,
        epoch=1000, early_stop=1e-9,
    )
    runner.set_algorithm_flow("Gray-Grad", hpr_mean.predict_center).run(verbose=False)
    all_results.append({"name": "Gray-Grad", "results": runner.last_results, "t_total": runner.last_time})

    # ---- 新方法：Global LK（配對模式）----
    runner.set_algorithm_flow_pair("Global-LK", Global_LK.predict_dxy).run(verbose=False)
    all_results.append({"name": "Global-LK", "results": runner.last_results, "t_total": runner.last_time})

    hpr_lsq = GD_Circle_Fit(
        cen_init_method="canny_lsq",
        lr=0.1, tau=2.0, margin=10.0,
        epoch=1000, early_stop=1e-9,
    )
    # runner.set_algorithm_flow("gd(lsq-init)", hpr_lsq.predict_center).run(verbose=False)
    # all_results.append({"name": "gd(lsq-init)", "results": runner.last_results, "t_total": runner.last_time})

    runner.print_summary(all_results)

    # 原本的折線圖（保留）
    # plot_err_vs_gt(all_results)

    # 新增的表格熱圖
    plot_err_table(all_results)