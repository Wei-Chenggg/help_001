import os
import time
import numpy as np
from scipy.special import expit
import matplotlib
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False
from toolbox.image_helper import *
from toolbox.files_helper import *
from toolbox.poly_fitting_helper import Poly_Fitting
from task_runner import *


def plot_grid_dxy_noise(all_grid, sigma_list, metrics=("ex", "ey", "e"),
                        center="mean", spread="std",
                        logy=True, ylim=(1e-4, 1e-1), suptitle="",
                        cell_w=2.4, cell_h=2.8,
                        line_color="steelblue",
                        marker="o", lw=1.5, ms=4,
                        zero_floor=1e-12,
                        highlight_best=True,
                        best_color="crimson"):
    """
    每個 metric 一張圖。
    子圖網格：row = noise level（上→下 sigma 增加），
              col = dxy condition（左→右依 dx, dy 排序）。
    每個子圖：以「算法」為 x 軸，畫折線（marker + errorbar）。

    center : "mean" | "median"            → 曲線的 y 值
    spread : "std" | "iqr" | "max" | None → errorbar 的長度
    ylim   : None 或 (lo, hi)
        None   → 每個子圖自動決定
        (lo,hi) → 所有子圖統一此範圍（log 模式下 lo 需 > 0）
    highlight_best : 每個子圖中最小 center 的算法點用 best_color 標示
    """
    import matplotlib.pyplot as plt

    algo_names = list(all_grid.keys())

    # --- 收集所有 (dxy condition) ---
    cond_set = set()
    for algo in algo_names:
        for sigma in sigma_list:
            for t in all_grid[algo][sigma]:
                for r in t["results"]:
                    gt = np.asarray(r["gt"], dtype=float)
                    cond_set.add((round(float(gt[0]), 6),
                                  round(float(gt[1]), 6)))
    cond_keys = sorted(cond_set, key=lambda c: (c[0], c[1]))
    n_sigma = len(sigma_list)
    n_cond  = len(cond_keys)

    # --- 統計收集 ---
    stats = {a: {s: {c: {m: [] for m in metrics} for c in cond_keys}
                 for s in sigma_list} for a in algo_names}
    for algo in algo_names:
        for sigma in sigma_list:
            for t in all_grid[algo][sigma]:
                for r in t["results"]:
                    gt = np.asarray(r["gt"], dtype=float)
                    c = (round(float(gt[0]), 6), round(float(gt[1]), 6))
                    for m in metrics:
                        stats[algo][sigma][c][m].append(float(r["err"][m]))

    def _agg(vals):
        v = np.asarray(vals, dtype=float)
        if v.size == 0:
            return np.nan, 0.0
        if center == "mean":
            ctr = v.mean()
        elif center == "median":
            ctr = np.median(v)
        else:
            raise ValueError(f"unknown center: {center}")
        if spread == "std":
            spr = v.std()
        elif spread == "iqr":
            spr = np.percentile(v, 75) - np.percentile(v, 25)
        elif spread == "max":
            spr = v.max() - ctr
        elif spread is None:
            spr = 0.0
        else:
            raise ValueError(f"unknown spread: {spread}")
        return float(ctr), float(spr)

    for metric in metrics:
        fig, axes = plt.subplots(
            n_sigma, n_cond,
            figsize=(cell_w * n_cond, cell_h * n_sigma),
            squeeze=False,
        )
        for i, sigma in enumerate(sigma_list):
            for j, cond in enumerate(cond_keys):
                ax = axes[i, j]
                xs = np.arange(len(algo_names))
                centers, spreads = [], []
                for algo in algo_names:
                    c_, s_ = _agg(stats[algo][sigma][cond][metric])
                    centers.append(c_)
                    spreads.append(s_)
                centers = np.asarray(centers, dtype=float)
                spreads = np.asarray(spreads, dtype=float)

                # log 刻度保護：把非正值抬到 zero_floor
                plot_centers = centers.copy()
                if logy:
                    plot_centers = np.where(plot_centers <= 0,
                                            zero_floor, plot_centers)

                # --- 曲線（折線 + errorbar）---
                ax.errorbar(xs, plot_centers,
                            yerr=spreads if spread else None,
                            marker=marker, lw=lw, ms=ms,
                            capsize=3, color=line_color)

                # --- 標最佳點 ---
                if highlight_best and np.any(np.isfinite(centers)):
                    best_idx = int(np.nanargmin(centers))
                    ax.plot(xs[best_idx], plot_centers[best_idx],
                            marker=marker, ms=ms + 5,
                            color=best_color, zorder=5)

                ax.set_xticks(xs)
                ax.set_xticklabels(algo_names, rotation=60,
                                   ha="right", fontsize=6)
                ax.tick_params(axis="y", labelsize=6)
                ax.grid(True, which="both", ls="--", alpha=0.4)
                if logy:
                    ax.set_yscale("log")

                # --- 統一 / 自動 ylim ---
                if ylim is not None:
                    lo, hi = ylim
                    ax.set_ylim(lo, hi)
                elif logy:
                    ax.set_ylim(bottom=zero_floor)

                ax.set_title(
                    f"σ={sigma:g}  dxy=({cond[0]:.3f},{cond[1]:.3f})",
                    fontsize=7,
                )
                if j == 0:
                    ax.set_ylabel(f"|{metric}| (px)", fontsize=7)

        tag = f"[{center}±{spread}]" if spread else f"[{center}]"
        fig.suptitle(f"{suptitle} — metric = {metric}  {tag}", fontsize=12)
        plt.tight_layout(rect=[0, 0, 1, 0.96])
        plt.show()


def run_sweep(runner, algorithms, sigma_list, n_repeats, seed_base,
              csv_path=None):
    """
    algorithms : dict {algo_name: (mode, func)}
                 mode ∈ {"single", "pair"}
    csv_path   : 若給定，將每筆 (trial, method, dx, dy, noise_sigma,
                 pred_dx, pred_dy, err_dx, err_dy, err_dist) 寫入 CSV
    """
    all_grid = {}
    csv_rows = []
    header = ["trial", "method", "dx", "dy", "noise_sigma",
              "pred_dx", "pred_dy", "err_dx", "err_dy", "err_dist"]

    for algo_name, (mode, algo_func) in algorithms.items():
        print(f"\n=== {algo_name} ({mode}) ===")
        if mode == "single":
            runner.set_algorithm_flow(algo_name, algo_func)
        else:
            runner.set_algorithm_flow_pair(algo_name, algo_func)
        grid = {}
        for sigma in sigma_list:
            runner.set_noise(sigma=sigma, seed=seed_base)
            trials = []
            for r in range(n_repeats):
                runner.run(verbose=False)
                trials.append({
                    "trial": r,
                    "results": runner.last_results,
                    "t_total": runner.last_time,
                })
                for res in runner.last_results:
                    gt = np.asarray(res["gt"], dtype=float)
                    pred = np.asarray(res["pred"], dtype=float)
                    err = res["err"]
                    csv_rows.append([
                        r,
                        algo_name,
                        float(gt[0]),
                        float(gt[1]),
                        float(sigma),
                        float(pred[0]),
                        float(pred[1]),
                        float(err["ex"]),
                        float(err["ey"]),
                        float(err["e"]),
                    ])
            ee = np.array([x["err"]["e"] for t in trials for x in t["results"]])
            print(f"  sigma={sigma:>4}  mean|e|={ee.mean():.4f}  std={ee.std():.4f}  max={ee.max():.4f}")
            grid[sigma] = trials
        all_grid[algo_name] = grid

    if csv_path is not None:
        save_csv(csv_path, [header] + csv_rows)
        print(f"\nCSV saved → {csv_path}  ({len(csv_rows)} rows)")

    return all_grid


if __name__ == "__main__":
    chart_folder = "./charts/chart0/400x400"
    runner = Sub_Pixel_Task_Runner(chart_folder=chart_folder)
    print(f"found {len(runner.charts)} chart(s) in {chart_folder}")

    sigma_list = [0, 2, 4, 8]
    n_repeats  = 5
    seed_base  = 1000

    algorithms = {
        "canny-mean": ("single", Canny_Mean.predict_center),
        "canny-lsq":  ("single", Canny_LSQ.predict_center),
        # "gray-grad":  ("single", GD_Circle_Fit(
            # cen_init_method="canny_lsq",
            # lr=0.1, tau=2.0, margin=20.0,
            # epoch=10000, early_stop=1e-9,
        # ).predict_center),
        "global-lk":           ("pair", Global_LK.predict_dxy),
        "global-lk(lsq-init)": ("pair",
                                lambda img0, img1: Global_LK.predict_dxy(
                                    img0, img1, lsq_init=True)),
    }

    csv_path = f"./results/noise_sweep_{get_timestamp()}.csv"

    all_grid = run_sweep(runner, algorithms, sigma_list, n_repeats, seed_base,
                         csv_path=csv_path)

    plot_grid_dxy_noise(all_grid, sigma_list,
                        metrics=("e",),
                        center="mean", spread="std",
                        suptitle="noise sweep (400x400)",
                        logy=True,
                        ylim=(1e-4, 1e-0),
                        highlight_best=True)