import os
import numpy as np
from dataclasses import dataclass, replace
from scipy.ndimage import gaussian_filter

import matplotlib
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = ["Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans"]
matplotlib.rcParams["axes.unicode_minus"] = False

from toolbox.image_helper import *
from toolbox.files_helper import *


@dataclass
class Config:
    width: int = 2000
    height: int = 2000
    dx: float = 0.0
    dy: float = 0.0
    shape_ratio: float = 0.3      # 圓半徑 / (min(W, H)/2)，0~1
    supersample: int = 4
    blur_size: int = 7
    blur_sigma: float = 2

def renderer_chart0(cfg: Config, target: bool = False) -> np.ndarray:
    ss = cfg.supersample
    W_ss = cfg.width * ss
    H_ss = cfg.height * ss
    x = (np.arange(W_ss) + 0.5) / ss - 0.5
    y = (np.arange(H_ss) + 0.5) / ss - 0.5
    xx, yy = np.meshgrid(x, y)
    canvas = np.zeros((H_ss, W_ss), dtype=np.float64)

    # 圓心固定在畫面中心；target=True 時整體平移 (dx, dy)
    cx = cfg.width / 2.0 + (cfg.dx if target else 0.0)
    cy = cfg.height / 2.0 + (cfg.dy if target else 0.0)

    # 半徑依圖片大小正規化：shape_ratio=1 時圓內切於短邊
    r = cfg.shape_ratio * min(cfg.width, cfg.height) / 2.0

    mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= r ** 2
    canvas[mask] = 255.0

    canvas = canvas.reshape(cfg.height, ss, cfg.width, ss).mean(axis=(1, 3))
    canvas = np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)
    if cfg.blur_sigma > 0:
        canvas = gaussian_filter(canvas, sigma=cfg.blur_sigma, truncate=cfg.blur_size / 2.0 / cfg.blur_sigma)
    return canvas


def clear_folder(folder):
    """刪除資料夾內所有檔案（保留資料夾本身）。"""
    if not os.path.isdir(folder):
        return
    for fn in os.listdir(folder):
        full = os.path.join(folder, fn)
        if os.path.isfile(full):
            os.remove(full)
    print(f"cleared: {folder}")


if __name__ == "__main__":
    width = 400
    height = 400
    shape_ratio = 0.8

    dx_all = np.linspace(0, 1, 10) ** 0.7 +10
    dy_all = -dx_all + 0.0456789

    out_dir = f"./charts/chart0/{width}x{height}"
    clear_folder(out_dir)

    base_cfg = Config(
        width=width, height=height,
        dx=0.0, dy=0.0,
        shape_ratio=shape_ratio,
        supersample=4,
        blur_size=7,
        blur_sigma=2.0,
    )
    img0 = renderer_chart0(base_cfg, target=False)
    print(f"img0: shape={img0.shape}, dtype={img0.dtype}")

    stamp = get_timestamp()
    n = len(dx_all)

    for i, (dx, dy) in enumerate(zip(dx_all, dy_all)):
        cfg = replace(base_cfg, dx=float(dx), dy=float(dy))
        img1 = renderer_chart0(cfg, target=True)
        dxy = (float(dx), float(dy))

        name = f"{stamp}_{i:04d}"
        pkl_path = f"{out_dir}/{name}.pkl"
        save_pkl(pkl_path, {"img0": img0, "img1": img1, "dxy": dxy})

        img0_path = f"{out_dir}/{name}_img0.png"
        img1_path = f"{out_dir}/{name}_img1.png"
        Imgtool(img0.astype(np.uint8)).save(img0_path)
        Imgtool(img1.astype(np.uint8)).save(img1_path)

        print(f"[{i+1:4d}/{n}] {name}  "
              f"dxy=({dx:+.8f}, {dy:+.8f})")

    print(f"\nall {n} charts saved to {out_dir}")