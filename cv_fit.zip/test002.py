"""Image -> Canny -> supplied Poly_Fitting -> analytic comparison.
Edit BASE_CONFIG, TEST_CASES and controls at the bottom, then run this file.
Optional CLI: python try01.py --sweep --no-show
Dependencies: numpy, matplotlib, opencv-python-headless, pillow, pyyaml, chardet
Keep the supplied image_helper, poly_fitting_helper and files_helper beside this file.
Helper filenames with (1) are also accepted.
Image coordinates: x right, y down; angles increase clockwise.
"""
from dataclasses import dataclass, replace
from itertools import product
import argparse
import contextlib
import io
import csv
import numpy as np
import importlib.util
from pathlib import Path
from toolbox.image_helper import Imgtool
from toolbox.poly_fitting_helper import Poly_Fitting
import toolbox.files_helper as files_helper



@dataclass
class Config:
    width: int = 640
    height: int = 480
    theta: float = 8.0       # initial tangent angle, degrees
    delta_theta: float = 0.0 # target minus initial angle, degrees
    dx: float = 0.0         # target translation in image x, px
    dy: float = 0.37        # target translation in image y, px
    mode: str = 'halfplane' # 'halfplane': f<0 white, f>=0 black; or 'strips'
    strips: int = 3
    thickness: float = 20.0 # strip thickness, px
    gap: float = 20.0       # clear gap between strips, px
    line_length: float = 400.0 # fitting ROI along initial tangent, px
    supersample: int = 4    # 1: binary pixel sampling; >1: area averaging
    blur_size: int = 7       # Imgtool.smooth() kernel size
    blur_sigma: float = 0.8 # Gaussian blur, px; 0 disables
    noise_sigma: float = 1.0 # independent grey-level noise per pixel
    canny_low: float = 50
    canny_high: float = 150
    times: int = 1          # Poly_Fitting random subset fits
    p: float = 0.05         # fraction randomly omitted when times>1
    # Integer pitch can place edges at the same pixel phase: their biases
    # are correlated, so more edges need not remove quantization bias.
    seed: int = 42
    compare_counts: tuple = (1, 2, 4, 8) # strip counts in comparison
    trials: int = 10        # independent noisy image pairs for sweep


def geometry(cfg, target=False):
    center = np.array([(cfg.width - 1) / 2, (cfg.height - 1) / 2])
    theta = np.deg2rad(cfg.theta + (cfg.delta_theta if target else 0))
    tangent = np.array([np.cos(theta), np.sin(theta)])
    normal = np.array([-np.sin(theta), np.cos(theta)])
    shift = np.array([cfg.dx, cfg.dy]) if target else np.zeros(2)
    if cfg.mode == 'halfplane':
        offsets = np.array([0.0])
    elif cfg.mode == 'strips':
        centers = (np.arange(cfg.strips) - (cfg.strips - 1) / 2)
        centers = centers * (cfg.thickness + cfg.gap)
        offsets = np.sort(np.ravel(centers[:, None] +
                                  np.array([-cfg.thickness/2, cfg.thickness/2])))
    else:
        raise ValueError("mode must be 'halfplane' or 'strips'")
    # Each analytic boundary is A*x + B*y + C = 0, with A^2+B^2=1.
    equations = np.column_stack((np.tile(normal, (len(offsets), 1)),
                                -normal @ (center + shift) - offsets))
    return center, tangent, normal, offsets, equations


def render(cfg, rng, target=False):
    center, _, normal, offsets, _ = geometry(cfg, target)
    shift = np.array([cfg.dx, cfg.dy]) if target else np.zeros(2)
    ss = cfg.supersample
    x = (np.arange(cfg.width * ss) + 0.5) / ss - 0.5
    y = (np.arange(cfg.height * ss) + 0.5) / ss - 0.5
    u = (normal[0] * (x[None, :] - center[0] - shift[0]) +
         normal[1] * (y[:, None] - center[1] - shift[1]))
    if cfg.mode == 'halfplane':
        image = np.where(u < 0, 255.0, 0.0)
    else:
        inside = np.zeros(u.shape, dtype=bool)
        for lo, hi in offsets.reshape(-1, 2):
            inside |= (u >= lo) & (u < hi)
        image = np.where(inside, 0.0, 255.0)
    image = image.reshape(cfg.height, ss, cfg.width, ss).mean(axis=(1, 3))
    tool = Imgtool(np.rint(image)).cvt_cv2_img(bound='clip', mode='gray')
    if cfg.blur_sigma > 0:
        tool.smooth(size=cfg.blur_size, sigma=cfg.blur_sigma)
    image = tool.get().astype(float)
    # image += rng.normal(0, cfg.noise_sigma, image.shape) * 20
    image += np.random.randint(-20,20,  image.shape)
    return Imgtool(np.rint(image)).cvt_cv2_img(bound='clip', mode='gray').get()


def detect(cfg, image):
    center, tangent, normal, offsets, _ = geometry(cfg)
    edges = Imgtool(image).canny(low=cfg.canny_low, high=cfg.canny_high)
    ys, xs = np.nonzero(edges)
    pts = np.column_stack((xs, ys)).astype(float)
    relative = pts - center
    s, u = relative @ tangent, relative @ normal
    keep = np.abs(s) <= cfg.line_length / 2
    pts, s, u = pts[keep], s[keep], u[keep]
    if len(u) == 0:
        raise ValueError('Canny found no points in the fitting ROI.')
    # Group observed edges by gaps in projected normal coordinates.
    # Suitable for this synthetic scene with separated, nearly parallel lines.
    # No true boundary locations are used to assign points to a group.
    order = np.argsort(u)
    split = np.flatnonzero(np.diff(u[order]) > 3.0) + 1
    groups = np.split(order, split)
    if len(groups) != len(offsets):
        raise ValueError(f'Expected {len(offsets)} edges; detected {len(groups)}. '
                         'Reduce rotation/noise or increase edge spacing.')
    rows = []
    for idx in groups:
        if len(idx) < 20 or np.ptp(s[idx]) < cfg.line_length * 0.8:
            raise ValueError('Edge too short or truncated by the image boundary.')
        model = Poly_Fitting()
        with contextlib.redirect_stdout(io.StringIO()):
            model.learn(s[idx], u[idx], order=[0, 1],
                        times=cfg.times, p=cfg.p, rescale=True)
        b, y1 = model.forward(np.array([0.0, 1.0]))
        a = y1 - b
        # u=a*s+b -> (normal-a*tangent).(point-center)-b=0.
        nf = normal - a * tangent
        norm = np.linalg.norm(nf)
        equation = np.r_[nf / norm, (-nf @ center - b) / norm]
        angle = np.rad2deg(np.arctan(a)) + cfg.theta
        rmse = np.sqrt(np.mean(((u[idx]-model.forward(s[idx]))/norm)**2))
        rows.append(dict(b=float(b), angle=float(angle), equation=equation,
                         rmse=float(rmse), points=pts[idx], s=s[idx],
                         residual=(u[idx]-model.forward(s[idx]))/norm))
    return edges, rows


def run_pair(cfg, rng):
    image0, image1 = render(cfg, rng), render(cfg, rng, target=True)
    edges0, fits0 = detect(cfg, image0)
    edges1, fits1 = detect(cfg, image1)
    edge_displacements = np.array([b['b']-a['b'] for a,b in zip(fits0, fits1)])
    displacement = np.mean(edge_displacements)
    angle = np.mean([b['angle']-a['angle'] for a,b in zip(fits0, fits1)])
    _, _, n0, _, _ = geometry(cfg)
    _, _, nt, _, truth = geometry(cfg, target=True)
    # Centerline intersection shift at s=0, along the initial normal.
    true_displacement = nt @ np.array([cfg.dx, cfg.dy]) / (nt @ n0)
    return dict(image=image1, initial_image=image0, edges=edges1,
                fits=fits1, initial_fits=fits0, truth=truth,
                edge_displacements=edge_displacements,
                displacement=displacement, true_displacement=true_displacement,
                angle=angle, position_error=displacement-true_displacement,
                angle_error=angle-cfg.delta_theta)


def sweep(cfg):
    print(f'\n多片比較：每種配置重複 {cfg.trials} 對影像')
    print('片數 邊界數 位移誤差RMSE(px) 平均位移誤差(px) 位移誤差標準差(px) 轉角誤差RMSE( deg) max_abs_error(px) averaged_abs_error(px)')
    for count in cfg.compare_counts:
        c = replace(cfg, mode='strips', strips=count)
        rng = np.random.default_rng(c.seed)
        np.random.seed(c.seed) # supplied helper uses NumPy global RNG
        results = [run_pair(c, rng) for _ in range(c.trials)]
        ep = np.array([r['position_error'] for r in results])
        ea = np.array([r['angle_error'] for r in results])
        print(f'{count:6d} {2*count:5d} {np.sqrt(np.mean(ep**2)):21.6f} '
              f'{ep.mean():9.6f} {ep.std():9.6f} {np.sqrt(np.mean(ea**2)):15.6f} '
              f'{np.max(np.abs(ep)):17.6f} {abs(ep.mean()):22.6f}')
    print('以上 RMSE 為估計值與真實值之差，並非點到線的殘差。')
    print('固定幾何與像素相位、每次加入獨立影像雜訊；結果包含定位偏差。')


def print_result(cfg, result):
    print("\n位移結果（沿初始邊界法向，在影像中心截線量測）")
    print(f"  真實位移：{result['true_displacement']:+.6f} px")
    print(f"  估計位移：{result['displacement']:+.6f} px")
    print(f"  位移誤差：{result['position_error']:+.6f} px（估計 - 真實）")
    print(f"  絕對誤差：{abs(result['position_error']):.6f} px")
    print("\n角度變化（影像座標下，順時針為正）")
    print(f"  真實轉角：{cfg.delta_theta:+.6f} deg")
    print(f"  估計轉角：{result['angle']:+.6f} deg")
    print(f"  轉角誤差：{result['angle_error']:+.6f} deg（估計 - 真實）")
    print("\n邊界點的擬合殘差（點到擬合線的距離，並非位移誤差）")
    for j, fit in enumerate(result['fits']):
        print(f"  邊界 {j + 1}：{len(fit['points'])} 個點，"
              f"點到線的距離 RMSE = {fit['rmse']:.6f} px")
    if 'trial_position_errors' in result:
        print(f"\n重複 {len(result['trial_position_errors'])} 對影像的位移統計")
        print(f"  位移誤差 RMSE：{result['position_rmse']:.6f} px")
        print(f"  平均位移誤差：{result['position_bias']:+.6f} px")
        print(f"  位移誤差標準差：{result['position_std']:.6f} px")
        print(f"  最大絕對位移誤差 max_abs_error：{result['max_abs_error']:.6f} px")
        print(f"  多次位移取平均後的絕對誤差：{result['averaged_abs_error']:.6f} px")
        print(f"  轉角誤差 RMSE：{result['angle_rmse']:.6f} deg")
        print("  max_abs_error 是本批測試的最差值，並非所有可能誤差的上限。")
        print("  RMSE 描述單次量測誤差；取平均後的絕對誤差是本批平均位移與真實位移之差。")
        print("  上面單次結果是第 1 對影像；RMSE 使用所有影像對的估計 - 真實。")


def run_experiment(cfg, show=True, compare_strips=False, save_dir=None):
    """Run one condition directly from Python and return its measurement dict."""
    if min(cfg.width, cfg.height, cfg.supersample, cfg.strips, cfg.times) < 1:
        raise ValueError('Image dimensions and counts must be positive.')
    np.random.seed(cfg.seed)
    rng = np.random.default_rng(cfg.seed)
    result = run_pair(cfg, rng)
    if cfg.trials < 1:
        raise ValueError('trials must be >= 1.')
    errors = [(result['position_error'], result['angle_error'])]
    for _ in range(cfg.trials - 1):
        measurement = run_pair(cfg, rng)
        errors.append((measurement['position_error'], measurement['angle_error']))
    ep, ea = np.asarray(errors).T
    result.update(trial_position_errors=ep, trial_angle_errors=ea,
                  position_rmse=float(np.sqrt(np.mean(ep**2))),
                  position_bias=float(ep.mean()), position_std=float(ep.std()),
                  max_abs_error=float(np.max(np.abs(ep))),
                  averaged_abs_error=float(abs(np.mean(ep))),
                  angle_rmse=float(np.sqrt(np.mean(ea**2))))
    # Verify RMS from recorded errors and from normalized line equations.
    assert np.isclose(np.linalg.norm(ep)/np.sqrt(len(ep)), result['position_rmse'])
    assert np.isclose(result['position_rmse']**2, result['position_bias']**2 + result['position_std']**2)
    for fit in result['fits']:
        residual = fit['points'] @ fit['equation'][:2] + fit['equation'][2]
        assert np.isclose(np.sqrt(np.mean(residual**2)), fit['rmse'], atol=1e-10)
    with contextlib.redirect_stdout(io.StringIO()) as output:
        print_result(cfg, result)
    report = output.getvalue()
    print(report, end='')
    if save_dir:
        destination = Path(save_dir).expanduser().resolve()
        files_helper.add_folder(destination)
        Imgtool(result['initial_image']).save(destination / 'initial.png')
        Imgtool(result['image']).save(destination / 'target.png')
        Imgtool(result['edges']).save(destination / 'canny.png')
        files_helper.save_md(destination / 'result.md', report)
        files_helper.save_pkl(destination / 'audit.pkl', {
            'config': vars(cfg),
            'target_points': [f['points'] for f in result['fits']],
            'fitted_equations': [f['equation'] for f in result['fits']],
            'analytic_equations': result['truth'],
            'edge_point_residuals': [f['residual'] for f in result['fits']],
            'edge_point_rmse': [f['rmse'] for f in result['fits']],
            'trial_position_errors': ep,
            'trial_angle_errors': ea,
            'max_abs_error': result['max_abs_error'],
            'averaged_abs_error': result['averaged_abs_error'],
        })
        with (destination / 'trial_errors.csv').open('w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['pair', 'displacement_error_px', 'squared_error_px2', 'angle_error_deg'])
            writer.writerows((i+1, e, e*e, a) for i, (e, a) in enumerate(zip(ep, ea)))
        print(f'已輸出影像、Canny 與誤差文字至：{destination}')
    if compare_strips:
        sweep(cfg)
    if show or save_dir:
        make_verification_plot(cfg, result, show, save_dir)
    return result


def make_verification_plot(cfg, result, show=False, save_dir=None):
    import matplotlib.pyplot as plt
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes = plt.subplots(2, 3, figsize=(16, 9), layout='constrained')
    overview, zoom, residual_ax, rms_ax, edge_ax, trials_ax = axes.flat
    fig.suptitle(f"theta={cfg.theta:g} deg | length={cfg.line_length:g} px | "
                 f"strips={cfg.strips if cfg.mode == 'strips' else 0} | "
                 f"first-pair error={result['position_error']:+.6f} px", fontsize=14)
    center, tangent, normal, _, _ = geometry(cfg)
    _, _, _, _, truth0 = geometry(cfg)
    positions = np.linspace(-cfg.line_length/2, cfg.line_length/2, 200)
    middle = len(result['fits']) // 2
    for ax in (overview, zoom):
        ax.imshow(result['image'], cmap='gray', vmin=0, vmax=255)
    for j, (fit, truth) in enumerate(zip(result['fits'], result['truth'])):
        for eq, color, style, label in (
                (truth, '#00a676', '-', 'Analytic line'),
                (fit['equation'], '#ff5c5c', '--', 'Fitted line')):
            u = -(eq[:2] @ center + eq[2] + (eq[:2] @ tangent)*positions)/(eq[:2] @ normal)
            xy = center + positions[:,None]*tangent + u[:,None]*normal
            overview.plot(xy[:,0],xy[:,1],style,color=color,lw=1.3,label=label if j==0 else None)
            if j==middle:
                zoom.plot(xy[:,0],xy[:,1],style,color=color,lw=1.6,label=label)
        if j==middle:
            pts=fit['points']
            zoom.scatter(pts[:,0],pts[:,1],s=18,facecolors='none',edgecolors='#f4a300',label='Canny pixels')
        residual_ax.scatter(fit['s'],fit['residual'],s=4,alpha=.5)
    overview.set(title='Target image with analytic and fitted lines',
                 xlim=(0,cfg.width-1),ylim=(cfg.height-1,0),xlabel='x (px)',ylabel='y (px)')
    yy, xx = np.indices(result['image'].shape)
    roi_s = (xx-center[0])*tangent[0] + (yy-center[1])*tangent[1]
    overview.contour(xx, yy, roi_s, levels=[-cfg.line_length/2, cfg.line_length/2],
                     colors=['#00cfff'], linewidths=1.5)
    for j, fit in enumerate(result['fits']):
        color = plt.get_cmap('tab20')(j % 20)
        pts = fit['points']
        overview.scatter(pts[:,0], pts[:,1], s=2, color=color)
        mark = pts[np.argmax(fit['s'])]
        overview.text(mark[0]+5, mark[1], str(j+1), color=color, fontsize=8)
    overview.set_title('Cyan: actual ROI limits; colors: Canny groups\nGreen: analytic; red dashed: fitted')
    overview.legend(fontsize=8)
    eq=result['truth'][middle]
    u0=-(eq[:2] @ center+eq[2])/(eq[:2] @ normal)
    focal=center+u0*normal
    zoom.set(title=f'Edge {middle+1}: pixel-level zoom',
             xlim=(focal[0]-10,focal[0]+10),ylim=(focal[1]+10,focal[1]-10),
             xlabel='x (px)',ylabel='y (px)')
    zoom.legend(fontsize=8)
    zoom.set_aspect('equal')
    all_residual=np.concatenate([f['residual'] for f in result['fits']])
    pooled=np.sqrt(np.mean(all_residual**2))
    residual_ax.axhline(0,color='black',lw=.8)
    residual_ax.set(title=f'Point-to-line residuals: pooled RMS={pooled:.6f} px',
                    xlabel='Position along initial tangent (px)',ylabel='Signed perpendicular residual (px)')
    numbers=np.arange(1,len(result['fits'])+1)
    rms=np.array([f['rmse'] for f in result['fits']])
    rms_ax.bar(numbers,rms,color='#448aff')
    rms_ax.set(title='Point-to-line RMSE of each edge (first pair)',
               xlabel='Edge number',ylabel='Residual RMSE (px)',xticks=numbers)
    for x,y in zip(numbers,rms):
        rms_ax.text(x,y,f'{y:.4f}',ha='center',va='bottom',fontsize=7)
    rms_ax.set_ylim(0,max(rms.max()*1.25,.1))
    true_b0=-(truth0[:,:2] @ center+truth0[:,2])/(truth0[:,:2] @ normal)
    true_b1=-(result['truth'][:,:2] @ center+result['truth'][:,2])/(result['truth'][:,:2] @ normal)
    per_edge_error=result['edge_displacements']-(true_b1-true_b0)
    edge_ax.bar(numbers,per_edge_error,color='#ff9800')
    edge_ax.axhline(0,color='black',lw=.8)
    edge_ax.axhline(result['position_error'],color='#e53935',ls='--',label='Fused position error')
    edge_ax.set(title='Displacement error of each edge (first pair)',
                xlabel='Edge number',ylabel='Estimated - analytic displacement (px)',xticks=numbers)
    edge_ax.legend(fontsize=8)
    ep=result['trial_position_errors']
    trials_ax.plot(np.arange(1,len(ep)+1),ep,'o-',color='#6a1b9a',ms=4)
    trials_ax.axhline(0,color='black',lw=.8)
    for sign in (-1,1):
        trials_ax.axhline(sign*result['position_rmse'],color='#e53935',ls='--',
                          label='+/- displacement RMSE' if sign==1 else None)
    trials_ax.set(title=f"{len(ep)} pairs: displacement RMSE={result['position_rmse']:.6f} px",
                  xlabel='Image pair / trial',ylabel='Estimated - analytic displacement (px)')
    trials_ax.legend(fontsize=8)
    for ax in (residual_ax,rms_ax,edge_ax,trials_ax):
        ax.grid(alpha=.2)
    if save_dir:
        fig.savefig(Path(save_dir)/'verification.png',dpi=160)
    if show:
        plt.show()
    plt.close(fig)


def make_summary_plot(results, save_dir, show=False):
    import matplotlib.pyplot as plt
    plt.rcParams['axes.unicode_minus'] = False
    fig, axes=plt.subplots(1,2,figsize=(13,5),layout='constrained')
    grouped={}
    for name,cfg in TEST_CASES:
        # Separate every parameter except strip count, so unrelated conditions
        # are not pooled into one RMSE.
        key=tuple((k,repr(v)) for k,v in vars(cfg).items() if k!='strips')
        grouped.setdefault(key,[]).append((cfg,results[name]))
    for group in grouped.values():
        group=sorted(group,key=lambda p:p[0].strips)
        cfg=group[0][0]
        x=[c.strips for c,r in group]
        label=f'theta={cfg.theta:g}, length={cfg.line_length:g}, noise={cfg.noise_sigma:g}'
        axes[0].plot(x,[r['position_rmse'] for c,r in group],'o-',label=label)
        axes[1].plot(x,[r['angle_rmse'] for c,r in group],'o-',label=label)
    for ax,ylabel in zip(axes,('Displacement error RMSE (px)','Angle error RMSE (deg)')):
        ax.set(xlabel='Number of strips',ylabel=ylabel)
        ax.grid(alpha=.3)
        ax.legend(fontsize=8)
    fig.suptitle('Repeated noisy image pairs at each fixed geometry; pixel-phase bias included')
    if save_dir:
        directory=Path(save_dir).expanduser().resolve()
        files_helper.add_folder(directory)
        fig.savefig(directory/'summary.png',dpi=160)
    if show:
        plt.show()
    plt.close(fig)


# ==================== 在這裡修改實驗條件 ====================
BASE_CONFIG = Config(
    width=2040,
    height=1880,
    theta=8.0,
    delta_theta=0.0,
    dx=0.0,
    dy=0.37,
    mode="halfplane",     # "halfplane" 單條邊界；"strips" 多片特徵
    strips=3,
    thickness=20.0,
    gap=20.0,
    line_length=400.0,
    supersample=4,
    blur_size=7,
    blur_sigma=0.8,
    noise_sigma=1.0,
    canny_low=50,
    canny_high=150,
    times=8,
    p=0.02,
    trials=10,
    compare_counts=(1, 2, 4, 8),
    seed=42,
)

# 只要改下面清單中的數值，就會自動測試所有組合。
# 一個值表示固定條件；多個值表示逐一測試。
PARAMETERS = {
    "theta": [0.],      # 角度，deg
    "line_length": [ 400.0], # 擬合長度，px
    "mode": ["strips"],           # "halfplane" 或 "strips"
    "strips": [1, 3, 5,7, 9],          # 片數；只在 strips 模式生效
    "noise_sigma": [1.0],        # 灰階雜訊標準差
    "dx": [0.0],                 # 向右移動，px
    "dy": [0.37],                # 向下移動，px
    "delta_theta": [0.0],        # 移動前後的轉角，deg
    "thickness": [200.0],
}

# 自動建立 TEST_CASES，以下這段不需要修改。
parameter_names = list(PARAMETERS)
TEST_CASES = [
    (f"case_{i:03d}", replace(BASE_CONFIG, **dict(zip(parameter_names, values))))
    for i, values in enumerate(product(*PARAMETERS.values()), start=1)
]

SHOW_IMAGES = False      # True：每組開圖窗；False：只印結果
COMPARE_STRIPS = False   # 保持 False，就用 PARAMETERS 裡的 strips 清單
SAVE_DIR = str(Path(__file__).resolve().parent / "results")           # 自動存圖與 CSV；設成 None 即不存檔


def main():
    # Optional CLI overrides; pressing Run requires no command-line options.
    parser = argparse.ArgumentParser()
    parser.add_argument('--sweep', action='store_true')
    parser.add_argument('--no-show', action='store_true')
    parser.add_argument('--save-dir', default=SAVE_DIR)
    args = parser.parse_args()
    results = {}
    print(f"準備執行 {len(TEST_CASES)} 組參數組合。")
    for name, cfg in TEST_CASES:
        print(f"\n測試條件：{name}")
        print(f"  初始角度={cfg.theta} deg，擬合長度={cfg.line_length} px，"
              f"影像雜訊={cfg.noise_sigma}，模式={cfg.mode}，片數={cfg.strips}")
        destination = Path(args.save_dir) / name if args.save_dir else None
        results[name] = run_experiment(
            cfg,
            show=SHOW_IMAGES and not args.no_show,
            compare_strips=COMPARE_STRIPS or args.sweep,
            save_dir=destination,
        )
    print("\n所有測試結果（有號誤差；越接近 0 越好）")
    print("case      theta(deg) length(px) strips position_error(px) angle_error(deg) displacement_RMSE(px) max_abs_error(px) averaged_abs_error(px)")
    for name, cfg in TEST_CASES:
        r = results[name]
        print(f"{name:9s} {cfg.theta:10.3f} {cfg.line_length:10.1f} {cfg.strips:6d} "
              f"{r['position_error']:+18.6f} {r['angle_error']:+16.6f} {r['position_rmse']:21.6f} "
              f"{r['max_abs_error']:17.6f} {r['averaged_abs_error']:22.6f}")
    if args.save_dir or (SHOW_IMAGES and not args.no_show):
        make_summary_plot(results,args.save_dir,show=SHOW_IMAGES and not args.no_show)
    return results


if __name__ == '__main__':
    results = main()  # 可在 IDE 執行後查看 results["case_001"]["position_error"]

