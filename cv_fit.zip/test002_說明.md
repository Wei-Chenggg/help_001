# test002.py 計算說明：從影像邊緣到亞像素位移

本文件依目前的 `test002.py`、`toolbox/poly_fitting_helper.py` 與 `toolbox/image_helper.py` 實作整理。目的在於把演算法概念、數學公式與程式變數對照起來。這是原始碼的計算說明，沒有執行實驗，也沒有把推導值當成程式實測結果。

## 1. 這支程式到底在量什麼

程式先建立一張「初始影像」，再建立一張具有已知平移與旋轉的「目標影像」。兩張影像分別經過 Canny 邊緣偵測與直線擬合，接著比較相同邊界的直線截距與角度，得到估計位移與估計轉角。因為合成影像的真實幾何已知，所以可以計算估計值與真實值的差。

這裡的位移是「在通過影像中心、沿初始邊界法向的截線上，邊界交點移動多少」，單位為 px。它不是完整的二維平移向量，也不是直接讀取 `dy`。

可以先用這一串流程理解整支程式：

```text
BASE_CONFIG + PARAMETERS
    → 每組 Config
    → geometry：建立真實幾何
    → render：生成初始／目標影像
    → detect：Canny → 座標投影 → ROI → 分組 → 各邊界直線擬合
    → run_pair：對應邊界截距相減 → 多邊界平均
    → run_experiment：重複影像對 → 計算定位誤差統計
    → print_result / 驗證圖 / CSV / audit.pkl
```

## 2. 先認識變數與座標

影像座標以左上角為起點，`x` 向右增加，`y` 向下增加。角度從向右的方向起算，所以正角度在畫面上呈現順時針方向。

| 程式名稱 | 數學記號 | 意義 |
|---|---|---|
| `center` | c | 固定的影像中心 |
| `theta` | θ₀ | 初始邊界切線角度 |
| `delta_theta` | δ | 目標相對初始的轉角 |
| `tangent` | t₀ | 初始邊界的單位切向量 |
| `normal` | n₀ | 初始邊界的單位法向量 |
| `shift` | d = (dx, dy) | 目標圖形的平移向量 |
| `offsets` | oⱼ | 各邊界相對圖形中心的法向偏移 |
| `pts` | pᵢ = (xᵢ, yᵢ) | Canny 偵測到的邊緣像素位置 |
| `s` | sᵢ | 點相對影像中心的切向座標 |
| `u` | uᵢ | 點相對影像中心的法向座標 |
| `a` | aⱼ | 局部座標中擬合直線的斜率 |
| `b` | bⱼ | 局部座標中擬合直線的截距 |
| `equation` | (A, B, C) | 正規化的影像座標直線方程式 |

`geometry()` 會依 `target` 回傳初始或目標方向；但 `detect()` 固定呼叫 `geometry(cfg)`，因此分析兩張影像時都使用同一組初始 `tangent` 與 `normal`。後面的截距相減，就是建立在這個共用座標系上。

## 3. geometry()：建立沒有影像誤差的真實邊界

### 3.1 中心與方向

程式用像素中心座標定義影像中心：

```python
center = np.array([(cfg.width - 1) / 2, (cfg.height - 1) / 2])
theta = np.deg2rad(cfg.theta + (cfg.delta_theta if target else 0))
tangent = np.array([np.cos(theta), np.sin(theta)])
normal = np.array([-np.sin(theta), np.cos(theta)])
```

也就是：

```text
c = ((width − 1)/2, (height − 1)/2)
t = (cos θ, sin θ)
n = (−sin θ, cos θ)
```

`t` 與 `n` 互相垂直，且長度都是 1。因此與它們做內積，得到的投影仍以 px 為單位。初始角度是 θ₀；目標角度是 θ₀ + δ。

### 3.2 單一邊界與多條帶

`halfplane` 只有一條邊界，`offsets = [0]`。邊界一側為白色，另一側為黑色。

`strips` 則建立多條黑色條帶。一片條帶有兩條邊界，所以 `strips=m` 會產生 `2m` 條邊界。條帶中心的位置是：

```text
第 k 片中心 = (k − (m − 1)/2) × (thickness + gap)
k = 0, 1, ..., m − 1
每片兩條邊界 = 條帶中心 ± thickness/2
```

對應程式：

```python
centers = (np.arange(cfg.strips) - (cfg.strips - 1) / 2)
centers = centers * (cfg.thickness + cfg.gap)
offsets = np.sort(np.ravel(centers[:, None] +
                          np.array([-cfg.thickness/2, cfg.thickness/2])))
```

例如目前 `thickness=200`、`gap=20`，若有三片，條帶中心是 `−220、0、220`，邊界偏移排序後是 `−320、−120、−100、100、120、320`。兩片之間的白色間隔是 20 px，每片黑色本身的厚度是 200 px。

### 3.3 真實直線方程式

對於法向偏移 oⱼ，真實邊界滿足：

```text
n · (p − c − d) = oⱼ
n · p − n · (c + d) − oⱼ = 0
```

寫成 `A*x + B*y + C = 0`：

```text
A = nₓ
B = nᵧ
C = −n · (c + d) − oⱼ
```

這對應 `geometry()` 中的 `equations`。因為 n 是單位向量，`A²+B²=1`，點代入方程式後的數值就是有號垂直距離。

目標邊界實際上是先繞固定的影像中心改變方向，再把圖形中心移到 `c+d`；每條邊界的 oⱼ 保持相同。

## 4. render()：把連續幾何變成灰階像素

### 4.1 超取樣如何表示不到一個像素的移動

`supersample=4` 表示每個原始像素用 `4×4=16` 個子取樣點近似面積覆蓋率。它用來生成測試影像，並不是把 Canny 點座標放大四倍，也不是直接提供精確的亞像素邊緣。

```python
x = (np.arange(cfg.width * ss) + 0.5) / ss - 0.5
y = (np.arange(cfg.height * ss) + 0.5) / ss - 0.5
```

原始像素中心是整數。例如中心在 `x=0` 的像素，四個水平子取樣位置是 `−0.375、−0.125、0.125、0.375`。每個子取樣點依幾何判斷黑或白，再對同一像素內的 16 個值取平均：

```python
image = image.reshape(cfg.height, ss, cfg.width, ss).mean(axis=(1, 3))
```

若其中 8 個點是白色，該像素平均灰階就是 127.5。邊界小幅移動時，部分像素的覆蓋率會改變，因此灰階影像能反映小於 1 px 的位移。這是有限子取樣近似，並非連續面積的精確積分。

### 4.2 黑白判斷

`render()` 中的 `u` 是每個子取樣點相對於當前圖形中心、沿當前法向的投影：

```python
u = normal[0] * (x[None, :] - center[0] - shift[0]) + \
    normal[1] * (y[:, None] - center[1] - shift[1])
```

`halfplane` 在 `u<0` 時給 255，否則給 0。`strips` 在任一條帶的 `lo ≤ u < hi` 範圍內給 0，其餘給 255。

請留意：這裡的 `u` 使用當前圖形方向與平移後的中心；`detect()` 中的 `u` 則使用固定的初始方向與固定影像中心。兩者名稱相同，但用途與參考座標不同。

### 4.3 灰階量化、模糊與雜訊的順序

面積平均後先 `np.rint()` 四捨五入，再經 `cvt_cv2_img(bound='clip', mode='gray')` 成為 0～255 的 uint8 灰階圖。若 `blur_sigma>0`，呼叫 `Imgtool.smooth()`，其內部使用 `cv2.GaussianBlur`。目前核大小為 `7×7`，sigma 為 0.8 px。

接著對模糊後影像的每個像素加入獨立高斯雜訊：

```text
noise ~ Normal(0, noise_sigma²)
最終影像 = uint8(clip(round(模糊後影像 + noise), 0, 255))
```

目前 `noise_sigma=1` 是灰階強度的標準差，不是位置偏移 1 px。由於最終還要量化與裁切，輸出的像素雜訊不會處處維持理想的零均值高斯分布，尤其原本接近 0 或 255 的區域。

## 5. detect()：從整數邊緣點取得各條直線

### 5.1 Canny 輸出什麼

```python
edges = Imgtool(image).canny(low=cfg.canny_low, high=cfg.canny_high)
ys, xs = np.nonzero(edges)
pts = np.column_stack((xs, ys)).astype(float)
```

`Imgtool.canny()` 內部轉灰階後呼叫 `cv2.Canny(gray, int(low), int(high))`，回傳值為 0 或 255 的邊緣圖，本函式不額外做前置模糊。`np.nonzero()` 先回傳列 y、再回傳欄 x，所以程式刻意重組成 `(x,y)`。

這些點的位置仍是整數像素中心。`.astype(float)` 只是轉成浮點資料型別，沒有做灰階插值，也沒有把每個 Canny 點修正成亞像素座標。

### 5.2 為什麼先轉成 s、u

```python
relative = pts - center
s, u = relative @ tangent, relative @ normal
```

對任一點 p：

```text
s = (p − c) · t₀
u = (p − c) · n₀
p = c + s*t₀ + u*n₀
```

如此一來，原本可能接近垂直的影像直線，在局部座標中會接近 `u=常數`，可以穩定使用 `u=a*s+b` 表示。初始邊界的理想 a 為 0；即使初始角度是 120°，也不必直接擬合容易受方向影響的 `y=m*x+b`。

目前程式已知合成影像的初始角度，直接拿它建立座標系。若拿來處理未知方向的實拍影像，如何取得這個初始角度仍需要另外定義。

### 5.3 ROI 的實際意思

```python
keep = np.abs(s) <= cfg.line_length / 2
```

`line_length=400` 代表保留 `−200 ≤ s ≤ 200` 的點，即沿初始切向取 400 px 的範圍。它不是以每條線的端點截取 400 點，也不是一個 400×400 的方框；此處沒有另外限定法向 u 的範圍。

### 5.4 多條邊界如何分組

```python
order = np.argsort(u)
split = np.flatnonzero(np.diff(u[order]) > 3.0) + 1
groups = np.split(order, split)
```

把所有留下的點依 u 排序，相鄰投影值若相差超過 3 px，就在該位置切開。每一群被當成一條邊界。這裡沒有用真實 oⱼ 把點分配給「最近的真實線」，但有使用 `len(offsets)` 檢查偵測群數是否符合預期。

每一群還必須至少有 20 個點，且其切向跨度 `max(s)−min(s)` 不小於 `line_length×0.8`；目前即至少 320 px。群數不符、點太少或跨度不足時，程式直接拋出錯誤。

此分組方法適合間距充足、近乎平行的合成邊界。旋轉較大時，每條線的 u 範圍會變寬，相鄰邊界可能在 u 投影上重疊；雜點也可能造成額外群組。這不是一般影像的連通元件分群或自動線段偵測。

## 6. Poly_Fitting：直線係數到底怎麼求

### 6.1 test002.py 呼叫的模型

```python
model = Poly_Fitting()
model.learn(s[idx], u[idx], order=[0, 1],
            times=cfg.times, p=cfg.p, rescale=True)
```

預設基底是「泰勒」，`order=[0,1]` 表示常數項和一次項。因此這裡只擬合直線，沒有二次曲線或更高階多項式：

```text
u ≈ a*s + b
```

### 6.2 rescale=True 做的是標準化

工具先使用該群全部點計算平均與標準差：

```text
zᵢ = (sᵢ − μs) / σs
vᵢ = (uᵢ − μu) / σu
```

若標準差為 0，工具改用 1，避免除以 0。接著建立設計矩陣：

```text
       [1  z₁]
A  =   [1  z₂]
       [ ... ]
       [1  zN]
```

以 `np.linalg.lstsq(A_sub, y_sub, rcond=None)` 求 `w=(w₀,w₁)`，最小化選中點的平方和：

```text
Σ [vᵢ − (w₀ + w₁*zᵢ)]²
```

`forward()` 再把預測轉回原單位：

```text
û(s) = μu + σu*[w₀ + w₁*(s−μs)/σs]
a = σu*w₁/σs
b = μu + σu*w₀ − a*μs
```

### 6.3 times 與 p 的實際作用

`times=1` 時使用全部點，此時 p 不影響取點。`times>1` 時，每次隨機、不重複地選取：

```text
n_keep = max(1, int(N*(1−p)))
```

個點來擬合，最後對每次得到的 w 取算術平均。目前 `times=8`、`p=0.02`，就是對同一條邊緣的點做八次隨機子集擬合，每次保留約 98% 的點。若 N=400，每次保留 392 點。

標準化參數由全部點算出，八次共用同一組參數。這是隨機子集係數平均，不會依殘差判斷離群點，不是 RANSAC，也不是八張新影像。

### 6.4 test002.py 怎麼把係數取出來

```python
b, y1 = model.forward(np.array([0.0, 1.0]))
a = y1 - b
```

因為 `û(0)=b`、`û(1)=a+b`，所以兩個預測相減就得到 a。這樣不必直接拆解工具內部已標準化的 `model.w`。

此方法最小化的是局部 u 方向的殘差平方和，不是同時調整 s、u 的正交距離擬合。後續回報雖然換算成垂直距離，但擬合本身仍是普通的直線最小平方法。

## 7. 擬合線如何轉回影像座標

局部直線為 `u=a*s+b`，代入 s、u 的定義：

```text
(p−c)·n₀ = a*(p−c)·t₀ + b
(n₀−a*t₀)·(p−c) − b = 0
```

對應程式：

```python
nf = normal - a * tangent
norm = np.linalg.norm(nf)
equation = np.r_[nf / norm, (-nf @ center - b) / norm]
```

因為 t₀、n₀ 正交且都是單位向量：

```text
norm = √(1+a²)
(A,B) = (n₀−a*t₀) / √(1+a²)
C = [−(n₀−a*t₀)·c−b] / √(1+a²)
```

這一步把 `(A,B)` 正規化到長度 1，讓 `A*x+B*y+C` 具有垂直距離的意義。正值方向由這組法向決定，不表示固定往上或往下。

直線方向的估計角度則是：

```python
angle = np.rad2deg(np.arctan(a)) + cfg.theta
```

局部切向量可以寫成 `t₀+a*n₀`，相對初始切向的角度為 `atan(a)`。這個表示法採用接近初始方向的角度分支，適合小轉角；直線方向本身有 180° 的等價性，程式沒有額外做大角度展開。

## 8. run_pair()：為什麼用截距相減量位移

### 8.1 b 的幾何意義

令 s=0，點的位置便是：

```text
p = c + u*n₀
```

這是一條通過影像中心、沿初始法向的截線。擬合邊界在這條截線上滿足 `u=b`，因此 b 就是交點相對中心的有號位置。

兩張圖都用相同的初始座標系擬合，所以同一條邊界的交點位移是：

```text
Δbⱼ = b目標,ⱼ − b初始,ⱼ
```

對應程式：

```python
edge_displacements = np.array([b['b']-a['b'] for a,b in zip(fits0, fits1)])
displacement = np.mean(edge_displacements)
```

這段中的 `a`、`b` 是兩張圖的邊界結果字典，和前面代表斜率／截距的 a、b 不是同一種用途。`fits0`、`fits1` 都依 u 分組順序排列，以相同索引配對，沒有額外做特徵匹配。

### 8.2 多邊界平均

若有 M 條邊界：

```text
估計位移 D̂ = (1/M) Σ Δbⱼ
估計轉角 δ̂ = (1/M) Σ (angle目標,ⱼ − angle初始,ⱼ)
```

每條邊界的權重相同，沒有依點數、殘差或信心分數加權。`strips=9` 時，平均的是 18 條邊界的結果。

## 9. 真實位移公式：包含旋轉時為什麼要除以 nt·n0

`run_pair()` 的真實位移計算為：

```python
true_displacement = nt @ np.array([cfg.dx, cfg.dy]) / (nt @ n0)
```

其中 n₀ 是初始法向，nt 是目標法向，d 是平移。以中心邊界 o=0 為例，目標邊界滿足：

```text
nt · (p−c−d) = 0
```

測量截線上 `p=c+u*n₀`，所以：

```text
nt · (u*n₀−d) = 0
u*(nt·n₀) = nt·d
D真實 = (nt·d)/(nt·n₀)
```

`nt·n₀=cos δ`。分母是因為量測方向固定為初始法向，目標線的法向可能已旋轉。當 δ 接近 ±90°，交點量測會變得不穩定，這種表示也不適合該情況；目前程式未另外處理此分母接近 0 的狀況。

### 9.1 多條邊界旋轉時，各條真實位移不完全相同

對偏移 oⱼ 的目標邊界：

```text
b目標真實,ⱼ = (nt·d + oⱼ)/(nt·n₀)
b初始真實,ⱼ = oⱼ
Δb真實,ⱼ = (nt·d)/(nt·n₀) + oⱼ*(1/(nt·n₀)−1)
```

有旋轉時，後面那一項會讓不同偏移的邊界產生不同交點位移。程式的 `offsets` 對稱排列，平均 oⱼ 為 0，因此對全部邊界等權平均後，這一項抵消，平均真實位移仍是 `(nt·d)/(nt·n₀)`。

這解釋了 `run_pair()` 為什麼能用中心邊界的公式對照多邊界平均，也解釋了驗證圖為什麼要另外計算每條線自己的真實位移。

### 9.2 目前 theta=120°、dy=0.37 的具體例子

目前 `delta_theta=0`，所以 nt=n₀，分母為 1：

```text
n₀ = (−sin120°, cos120°) ≈ (−0.8660254, −0.5)
d = (0, 0.37)
D真實 = n₀·d = −0.5*0.37 = −0.185 px
```

因此目前應對照的真實法向位移是 `−0.185 px`。雖然圖形在影像 y 方向向下移動 0.37 px，它投影到程式選定的初始法向後是負 0.185 px。負號是座標方向的結果。

對平行且無限延伸的直線邊界而言，沿切向的平移不會改變邊界所在直線。這支程式從這組平行邊界得到的是法向量測，不能單靠此結果同時解出 dx、dy。

## 10. 亞像素能力來自哪裡

Canny 點雖然位於整數像素上，但許多點一起擬合出的 a、b 是連續浮點數。斜線的整數邊緣點形成階梯狀分布，整體擬合可以得到小數截距；兩張圖的截距再相減，就能輸出小於 1 px 的估計位移。

因此「結果可以表示到小數」與「真實誤差很小」是兩件事。精度仍會受邊緣像素量化、方向、長度、模糊、雜訊、超取樣近似與像素相位影響。程式沒有對每個 Canny 點做亞像素灰階定位。

多邊界平均可以降低部分隨機波動，但不能保證消除共同偏差。目前條帶節距為 `thickness+gap=220 px`，整數節距可能使不同邊界的像素相位與量化偏差相關，因此不能直接假定邊界增加 M 倍，誤差必然下降到原本的 `1/√M`。

## 11. 三種容易混淆的誤差

### 11.1 點到擬合線的殘差：fit['rmse']

每個邊緣點的有號垂直殘差是：

```text
rᵢ = [uᵢ − (a*sᵢ+b)] / √(1+a²)
單條邊界殘差 RMSE = √[(1/N) Σ rᵢ²]
```

對應 `detect()`：

```python
rmse = np.sqrt(np.mean(((u[idx]-model.forward(s[idx]))/norm)**2))
```

它描述點是否貼近「這條擬合線」。如果擬合線整體偏離真實線，但點都很貼近它，殘差仍可能很小。因此它不能直接代表定位準確度。

### 11.2 一對影像的位移與角度誤差

```text
position_error = displacement − true_displacement
angle_error = angle − delta_theta
```

前者單位為 px，後者單位為 deg。它們都保留正負號；`abs(position_error)` 才是單次絕對位移誤差。

### 11.3 多對影像的誤差統計

令第 k 對影像的位移誤差為 eₖ，總共 K 對：

| 結果欄位 | 計算公式 | 解讀 |
|---|---|---|
| `trial_position_errors` | [e₁, ..., eK] | 所有影像對的有號位移誤差 |
| `position_rmse` | √mean(eₖ²) | 本批單次量測的整體誤差尺度 |
| `position_bias` | mean(eₖ) | 本批平均有號偏差 |
| `position_std` | √mean((eₖ−mean(e))²) | 本批誤差圍繞平均值的波動 |
| `max_abs_error` | max(abs(eₖ)) | 本批觀察到的最差絕對誤差 |
| `averaged_abs_error` | abs(mean(eₖ)) | 將本批估計位移平均後，相對真實位移的絕對誤差 |
| `angle_rmse` | √mean(angle_errorₖ²) | 本批轉角誤差的 RMSE |

`position_std` 使用 `np.std()` 預設的 `ddof=0`，分母為 K。這是本批資料的描述統計，不是使用 K−1 的樣本標準差。

每對影像的真實幾何相同，因此 `averaged_abs_error = abs(position_bias)`。它不是 `mean(abs(eₖ))`，也不是 RMSE；正負誤差在平均時可能抵消。

例如兩次誤差為 `+0.03、−0.01 px`，則平均偏差為 `+0.01 px`，標準差為 `0.02 px`，RMSE 約 `0.02236 px`，最大絕對誤差為 `0.03 px`，平均位移的絕對誤差為 `0.01 px`。這是說明公式的假設例子，不是目前程式的測試結果。

## 12. run_experiment()：times=8 與 trials=10 如何同時作用

`run_experiment()` 先產生第一對影像，保留其影像、擬合線、逐邊界位移等完整資料。其後再呼叫 `run_pair()` 共 `trials−1` 次，只收集各次的位移與角度誤差，最後組成 ep、ea 計算統計。

可以用三片條帶作例子：每張圖有六條邊界，每條邊界各擬合八次，一對影像有兩張圖，再重複十對。因此這組條件共有 `6×8×2×10=960` 次子集最小平方求解；最後統計的是十個「影像對位移誤差」，不是 960 個獨立量測。

`result['displacement']`、`result['position_error']`、`result['fits']` 等仍屬於第一對影像，不會被替換成十對的平均。`position_rmse`、`position_bias` 等才是全部十對的統計。因此總表中的 `position_error` 與 `displacement_RMSE` 描述不同層級。

### 12.1 隨機種子

```python
np.random.seed(cfg.seed)
rng = np.random.default_rng(cfg.seed)
```

`rng` 用來生成影像雜訊；NumPy 全域亂數用來選擇 `Poly_Fitting` 的擬合子集。在一組實驗內，亂數狀態持續前進，各次會使用新的雜訊與子集；每個新的測試組合開始時，都重新設 seed。

所以不同片數的測試組不是每次都換一個全新的 seed。由於目前影像尺寸相同，影像雜訊生成方式與抽取數量相同，各組會重用相同的亂數雜訊序列來搭配不同幾何，這有助於條件比較；但擬合點數與群數可能不同，子集選取不能視為逐一相同。

### 12.2 程式中的一致性檢查

程式用 assert 確認：

```text
position_rmse = ||ep|| / √K
position_rmse² = position_bias² + position_std²
由正規化線方程算出的點到線 RMSE = fit['rmse']
```

最後一項把每個點代入 `A*x+B*y+C` 後重算殘差。這些檢查能核對計算公式是否一致，但不等於證明偵測到正確邊界，或已達成特定定位精度。

## 13. 現在到底會跑哪些條件

`Config` 類中的數值是預設值；`BASE_CONFIG` 建立本次共用設定；最後 `PARAMETERS` 中的欄位再覆蓋 `BASE_CONFIG`。閱讀實際測試條件時，要看到最下面這一層。

`product(*PARAMETERS.values())` 取得參數清單的笛卡兒積，再用 `replace(BASE_CONFIG, ...)` 建立每組設定。現在只有 strips 有五個值，其餘清單只有一個值，所以一共五組。

| 條件 | 目前實際值 |
|---|---|
| 影像尺寸 | width=2040、height=1880 |
| 影像中心 | (1019.5, 939.5) |
| 初始角度 | theta=120° |
| 目標轉角 | delta_theta=0° |
| 平移 | dx=0、dy=0.37 px |
| 真實量測位移 | −0.185 px，沿初始法向 |
| 模式 | strips |
| 條帶厚度／間隔 | 200／20 px |
| 擬合切向範圍 | −200 ≤ s ≤ 200 px |
| 影像生成 | supersample=4、blur_size=7、blur_sigma=0.8 |
| 影像雜訊 | noise_sigma=1 灰階單位 |
| Canny 閾值 | low=50、high=150 |
| 每條邊界擬合 | times=8、p=0.02 |
| 每組影像對數 | trials=10 |

| 名稱 | strips | 邊界數 |
|---|---:|---:|
| case_001 | 1 | 2 |
| case_002 | 3 | 6 |
| case_003 | 5 | 10 |
| case_004 | 7 | 14 |
| case_005 | 9 | 18 |

`BASE_CONFIG.theta=8`、`mode='halfplane'`、`thickness=20` 都已被 PARAMETERS 覆蓋，不能用來解讀目前輸出的實驗條件。

`COMPARE_STRIPS=False`，且未加 `--sweep` 時，不執行 `sweep()`。`compare_counts=(1,2,4,8)` 是額外 sweep 用的清單，不是目前這五組的片數。

## 14. 驗證圖的六個區塊怎麼讀

`make_verification_plot()` 使用第一對影像的目標圖與擬合資料，加上全部影像對的位移誤差序列。

| 圖的位置 | 內容 | 計算來源 |
|---|---|---|
| 左上 | 全圖、真實線、擬合線、各群 Canny 點、ROI 界線 | `result['image']`、`truth`、`fits`；青色線是 s=±line_length/2 |
| 上中 | 一條邊界的像素級放大 | `middle=len(fits)//2`；不一定是幾何中心線 |
| 右上 | 點到擬合線的有號垂直殘差 | 每條線的 `s`、`residual` |
| 左下 | 每條邊界自己的殘差 RMSE | `fit['rmse']` |
| 下中 | 每條邊界的位移誤差 | `edge_displacements − (true_b1−true_b0)` |
| 右下 | 十對影像的位移誤差 | `trial_position_errors`；水平虛線為 ±position_rmse |

右上的 pooled RMS 是把所有目標邊界點殘差合併後求 RMS，點多的邊界影響比較大；它不是各條邊界 RMSE 的簡單平均，也不是定位誤差 RMSE。

下中的 `true_b0`、`true_b1` 是用每條解析線方程式算出 s=0 時的交點位置：

```text
b真實 = −[(A,B)·c+C] / [(A,B)·n₀]
逐邊界位移誤差 = Δb估計 − (b目標真實−b初始真實)
```

這會包含各條邊界受旋轉影響的不同真實交點位移。下中的紅色水平虛線則是第一對影像的多邊界平均位移誤差。

±RMSE 線只是誤差尺度的視覺參考，不是保證上下限，也不是信賴區間。

## 15. 輸出檔案保存了哪些計算

目前 `SAVE_DIR` 指向程式旁的 `results`，各組存到 `results/case_001` 等資料夾。

| 檔案 | 內容 |
|---|---|
| `initial.png` | 第一對影像的初始圖 |
| `target.png` | 第一對影像的目標圖 |
| `canny.png` | 第一對影像的目標 Canny 邊緣圖 |
| `result.md` | 單次量測與整批統計文字 |
| `trial_errors.csv` | 各影像對的位移誤差、平方位移誤差、角度誤差 |
| `audit.pkl` | Config、第一對目標點與擬合／真實方程式、殘差，以及各次誤差等 |
| `verification.png` | 六區塊驗證圖 |
| `results/summary.png` | 不同片數的位移 RMSE 與角度 RMSE 比較 |

`audit.pkl` 沒有保存全部十對的完整影像與逐邊界擬合資料，逐點資料主要是第一對的目標影像。

`trial_errors.csv` 的 `displacement_error_px` 是 `估計−真實`，不是估計位移本身；`squared_error_px2` 是它的平方。把這一欄平均後開根號，即可核對 `position_rmse`。

`make_summary_plot()` 將除了 strips 之外的所有 Config 欄位都相同的測試歸為同一組，再以片數為 x 軸畫 RMSE。它不會把不同角度、長度或雜訊條件混成同一個 RMSE。

## 16. 讀程式時最需要對準的幾件事

最核心的三行是 `s,u = relative @ tangent, relative @ normal`、`model.learn(s,u,order=[0,1],...)`，以及 `displacement=mean(b目標−b初始)`。前者定義量測座標，中間建立邊界直線，後者把直線的位置差轉成多邊界平均位移。

`geometry()` 的解析線用來生成影像和提供真實值；`detect()` 的擬合係數來自 Canny 點。它沒有拿真實線位置直接算出擬合結果，但會使用已知初始方向建立座標系，並用已知邊界數檢查群數。

直線截距可以是小數，不表示每個邊緣點已完成亞像素定位。`rescale=True` 是數值標準化，不是提高影像解析度。`times` 是同一組點的抽樣擬合次數，`trials` 是重新生成影像對的次數。

定位是否準確應看 `position_error` 與跨影像對的 `position_rmse` 等結果；點到線的 `rmse` 主要協助觀察擬合殘差。這支程式在固定幾何、固定像素相位下改變雜訊，並沒有掃描所有可能的邊界位置，因此十次的平均偏差或最大誤差不能視為所有實拍情況的保證。

最後，這份文件只能對照目前實作，無法判定它是否完整符合當初口述的所有演算法細節。若原始構想包含逐點灰階亞像素插值、依殘差排除離群點、正交距離擬合、依可靠度加權，或完整二維平移估計，目前程式並沒有實作這些步驟。
