from files_helper import *
import tkinter as tk
from tkinter import ttk
import sys
import os
import csv
import threading
import time
import numpy as np
from PIL import Image, ImageTk

from image_helper import Imgtool

config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "config"))
if config_path not in sys.path:
    sys.path.append(config_path)
FRAME_PADDING = 3
FRAME_EDGE_COLOR = "gray"


class TK_Entry:
    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.mode        = cfg["mode"] or "str"
        if self.mode.startswith("float"):
            self.mode_type   = "float"
            parts            = self.mode.split("_")
            self.float_round = int(parts[1]) if len(parts) > 1 else None
        elif self.mode == "int":
            self.mode_type   = "int"
            self.float_round = None
        else:
            self.mode_type   = "str"
            self.float_round = None
        self.row         = int(cfg["row"])       if cfg["row"]       else 0
        self.col         = int(cfg["col"])       if cfg["col"]       else 0
        self.row_spn     = int(cfg["row_spn"])   if cfg["row_spn"]   else 1
        self.col_spn     = int(cfg["col_spn"])   if cfg["col_spn"]   else 1
        self.bg_color     = cfg["bg_color"] or "lightcyan"
        self.fg_color     = cfg["fg_color"] or "black"
        self.tgr_bg_color = cfg.get("tgr_bg_color") or self.bg_color
        self.tgr_fg_color = cfg.get("tgr_fg_color") or "crimson"
        self.fontsize     = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth    = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"
        init_text = cfg["text"] or ""
        init_val  = self._parse(init_text)
        self._value = init_val if init_val is not None else self._default_value()
        self._text  = self._format(self._value)
        self.parent    = None
        self.widget    = None
        self.border    = None
        self.var       = None
        self._modified = False

    def value(self, new_value=None):
        if new_value is None:
            return self._value
        parsed = self._parse(str(new_value))
        if parsed is None:
            return self._value
        self._value = parsed
        self._text  = self._format(parsed)
        if self.widget is not None:
            self._restore_display()
        return self._value

    def text(self, new_text=None):
        if new_text is None:
            if self.widget is not None:
                return self.widget.get()
            return self._text
        s = str(new_text)
        self._text = s
        if self.widget is not None:
            self.widget.delete(0, "end")
            self.widget.insert(0, s)
        return s

    def _default_value(self):
        if self.mode_type == "int":
            return 0
        if self.mode_type == "float":
            return 0.0
        return ""

    def _parse(self, text: str):
        text = str(text).strip()
        if self.mode_type == "str":
            return text
        if self.mode_type == "int":
            try:
                return int(text)
            except ValueError:
                pass
            try:
                return int(float(text))
            except ValueError:
                return None
        if self.mode_type == "float":
            try:
                v = float(text)
                if self.float_round is not None:
                    v = round(v, self.float_round)
                return v
            except ValueError:
                return None
        return None

    def _format(self, value) -> str:
        if self.mode_type == "int":
            return str(int(value))
        if self.mode_type == "float":
            return str(value)
        return str(value)

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "mode":         self.mode,
            "mode_type":    self.mode_type,
            "float_round":  self.float_round,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "text":         self._text,
            "value":        self._value,
            "modified":     self._modified,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "tgr_bg_color": self.tgr_bg_color,
            "tgr_fg_color": self.tgr_fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
        }

    def _on_text_change(self, *args):
        if self.widget is None:
            return
        current  = self.widget.get()
        expected = self._format(self._value)
        modified = (current != expected)
        if modified != self._modified:
            self._modified = modified
            self._apply_style()

    def _apply_style(self):
        if self._modified:
            bg, fg = self.tgr_bg_color, self.tgr_fg_color
        else:
            bg, fg = self.bg_color, self.fg_color
        if self.widget is not None:
            self.widget.config(bg=bg, fg=fg)

    def _on_submit(self, event=None):
        raw    = self.widget.get()
        parsed = self._parse(raw)
        if parsed is None:
            self._restore_display()
            self._flash("red")
            return "break"
        self._value = parsed
        self._text  = self._format(parsed)
        self._restore_display()
        self._flash(self.tgr_bg_color)
        return "break"

    def _on_cancel(self, event=None):
        self._restore_display()
        return "break"

    def _restore_display(self):
        self.widget.delete(0, "end")
        self.widget.insert(0, self._text)

    def _flash(self, color: str, duration: int = 150):
        self.widget.config(bg=color)
        self.widget.after(duration, self._apply_style)

    def __repr__(self):
        return (
            f"<TK_Entry {self.name} parent={self.parent_name} "
            f"mode={self.mode} value={self._value!r} text={self._text!r} "
            f"modified={self._modified}>"
        )


class TK_Combo:
    """
    Tkinter 下拉選單控件（唯讀）。

    責任分工：
      - options(opts=None)        讀 / 寫選項列表
      - value()                   讀目前值（唯讀）
      - text()                    value() 的別名
      - set(value=None, index=None)  寫入目前值（安全校驗）
            set(index=k)      合法索引才套用
            set(value="X")    "X" 在選項內才套用
            其餘情況不改變目前值

    保證：
      - 唯一寫入途徑是 set()，且 set() 保證值一定落在選項內
      - options() 更新選項時會自動修正目前值（保留 / pending / 第一項 / 空）
      - 不存在「值不在選項內」的狀態

    不接受打字：
      - state="readonly" 讓鍵盤打字不進 field
      - <KeyPress> 攔截只放行導覽 / 進出 / 修飾 / Ctrl 組合鍵

    外觀：
      - 外框 tk.Frame(border_color)，內距 linewidth
      - field 底 / 箭頭底 = bg_color；文字 / 箭頭 = fg_color
      - 下拉展開時的選中項固定藍底白字

    CSV：
      - 沿用既有欄位：name / parent / page / row / col / row_spn / col_spn /
        text / bg_color / fg_color / fontsize / linewidth / border_color
      - type 填 "combo"
      - tgr_bg_color / tgr_fg_color 保留但 combo 不使用
      - text 為「pending 初始值」：等 options() 被呼叫後，若匹配選項才套用
      - mode 欄位忽略
    """
    _NAV_KEYS = frozenset({
        "Up", "Down", "Left", "Right",
        "Home", "End", "Prior", "Next",
        "Tab", "ISO_Left_Tab",
        "Return", "KP_Enter", "Escape",
    })
    _MOD_KEYS = frozenset({
        "Shift_L", "Shift_R",
        "Control_L", "Control_R",
        "Alt_L", "Alt_R",
        "Meta_L", "Meta_R",
        "Super_L", "Super_R",
    })

    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.mode        = cfg["mode"] or "str"       # 保留，不判斷
        self.row         = int(cfg["row"])       if cfg["row"]       else 0
        self.col         = int(cfg["col"])       if cfg["col"]       else 0
        self.row_spn     = int(cfg["row_spn"])   if cfg["row_spn"]   else 1
        self.col_spn     = int(cfg["col_spn"])   if cfg["col_spn"]   else 1
        self.bg_color     = cfg["bg_color"] or "white"
        self.fg_color     = cfg["fg_color"] or "black"
        # tgr_* 保留相容 CSV，但 combo 不使用
        self.tgr_bg_color = cfg.get("tgr_bg_color") or self.bg_color
        self.tgr_fg_color = cfg.get("tgr_fg_color") or self.fg_color
        self.fontsize     = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth    = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"

        self._options      = []                      # 選項列表（永遠是 list[str]）
        self._value        = ""                      # 目前值（永遠在選項內，或空）
        self._pending_text = (cfg["text"] or "").strip()   # CSV 初始值暫存
        self.parent   = None
        self.widget   = None
        self.border   = None
        self.var      = None
        self.on_change = None

    # ---------------------------------------------------------- options
    def options(self, options=None):
        """
        None  → 讀取目前選項（回傳副本 list）
        list  → 設定選項（自動轉 str）；並修正目前值使其落在新選項內
        """
        if options is None:
            return list(self._options)
        if not isinstance(options, (list, tuple)):
            raise TypeError("options() 需要 list / tuple，或 None")
        self._options = [str(o) for o in options]

        if self.widget is not None:
            try:
                self.widget["values"] = self._options
            except tk.TclError:
                pass

        # 修正目前值：確保值一定落在新選項內
        if self._options:
            if self._value in self._options:
                pass                                   # 保留現值
            elif self._pending_text in self._options:
                self._value = self._pending_text       # 套用 pending
            else:
                self._value = self._options[0]         # 取第一項
        else:
            self._value = ""                           # 空選項 → 空值
        self._pending_text = ""

        if self.var is not None:
            self.var.set(self._value)
        return list(self._options)

    def add_option(self, *items):
        """附加一個或多個選項（不重複）。"""
        changed = False
        for it in items:
            s = str(it)
            if s not in self._options:
                self._options.append(s)
                changed = True
        if changed:
            if self.widget is not None:
                self.widget["values"] = self._options
            # 若目前為空且剛才有加入選項 → 取第一項
            if self._value not in self._options and self._options:
                self._value = self._options[0]
                if self.var is not None:
                    self.var.set(self._value)
        return list(self._options)

    def clear_options(self):
        """清空選項並把目前值歸零。"""
        self._options = []
        self._value = ""
        self._pending_text = ""
        if self.widget is not None:
            self.widget["values"] = self._options
        if self.var is not None:
            self.var.set("")
        return self

    # ---------------------------------------------------------- value / text（唯讀）
    def value(self):
        """讀取目前值（唯讀）。"""
        return self._value

    def text(self):
        """value() 的別名，維持與 TK_Entry 一致的呼叫習慣。"""
        return self._value

    def index(self):
        """目前值在選項中的索引；空值或空選項 → -1。"""
        try:
            return self._options.index(self._value)
        except ValueError:
            return -1

    # ---------------------------------------------------------- set（安全寫入）
    def set(self, value=None, index=None):
        """
        寫入目前值（安全校驗）：
          - index 有值且合法 → 套用該索引的選項
          - 否則 value 與選項精確字串比對 → 相符才套用
          - 兩者皆不合法或皆 None → 不改變，回傳目前值
        回傳最終值。
        """
        if index is not None:
            try:
                idx = int(index)
            except (TypeError, ValueError):
                return self._value
            if 0 <= idx < len(self._options):
                self._value = self._options[idx]
                if self.var is not None:
                    self.var.set(self._value)
                self._fire_change()
            return self._value

        if value is not None:
            s = str(value)
            if s in self._options:
                changed = (s != self._value)
                self._value = s
                if self.var is not None:
                    self.var.set(self._value)
                if changed:
                    self._fire_change()
            return self._value

        return self._value

    # ---------------------------------------------------------- config
    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "mode":         self.mode,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "text":         self._value,
            "value":        self._value,
            "options":      list(self._options),
            "index":        self.index(),
            "readonly":     True,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
        }

    # ---------------------------------------------------------- 事件
    def _fire_change(self):
        if callable(self.on_change):
            try:
                self.on_change(self.name, self._value)
            except Exception as e:
                print(f"[TK_Combo {self.name}] on_change 錯誤: {e}")

    def _on_key(self, event):
        """
        鍵盤打字攔截：
          - 導覽 / 進出 / 修飾鍵 → 放行
          - Ctrl 組合鍵（複製等）→ 放行
          - 其他（字母、數字、標點、Backspace、Delete…）→ 吃掉
        """
        if event.keysym in self._NAV_KEYS:
            return None
        if event.keysym in self._MOD_KEYS:
            return None
        if event.state & 0x4:          # Ctrl 按下
            return None
        return "break"

    def _on_select(self, event=None):
        """下拉選擇 / Enter 後觸發。"""
        if self.widget is None:
            return
        new_val = self.var.get()
        changed = (new_val != self._value)
        self._value = new_val
        if changed:
            self._fire_change()

    # ---------------------------------------------------------- 樣式
    def _apply_style(self):
        if self.widget is None:
            return
        bg, fg = self.bg_color, self.fg_color
        try:
            style = ttk.Style()
            sname = f"TKCombo{id(self)}.TCombobox"
            style.configure(
                sname,
                fieldbackground=bg,       # field 底色
                background=bg,            # 箭頭底
                foreground=fg,            # 文字
                arrowcolor=fg,            # 箭頭
                bordercolor=self.border_color,
                lightcolor=bg,
                darkcolor=bg,
                troughcolor=bg,
                selectbackground="#4a90d9",   # 下拉選中項：藍底
                selectforeground="white",     # 下拉選中項：白字
                padding=0,
            )
            style.map(
                sname,
                fieldbackground=[("readonly", bg), ("!disabled", bg), ("active", bg)],
                foreground=[("readonly", fg), ("!disabled", fg), ("active", fg)],
                background=[("readonly", bg), ("active", bg)],
                arrowcolor=[("readonly", fg), ("active", fg)],
            )
            self.widget.configure(style=sname)
        except tk.TclError:
            pass

    def __repr__(self):
        return (f"<TK_Combo {self.name} parent={self.parent_name} "
                f"value={self._value!r} idx={self.index()} "
                f"options={self._options}>")


class TK_Button:
    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.mode        = cfg["mode"] or "binary"
        self.row         = int(cfg["row"])       if cfg["row"]       else 0
        self.col         = int(cfg["col"])       if cfg["col"]       else 0
        self.row_spn     = int(cfg["row_spn"])   if cfg["row_spn"]   else 1
        self.col_spn     = int(cfg["col_spn"])   if cfg["col_spn"]   else 1
        self.text        = cfg["text"] or self.name
        self.bg_color     = cfg["bg_color"] or "white"
        self.fg_color     = cfg["fg_color"] or "black"
        self.tgr_bg_color = cfg.get("tgr_bg_color") or self.bg_color
        self.tgr_fg_color = cfg.get("tgr_fg_color") or self.fg_color
        self.fontsize     = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth    = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"
        self.single_pulse_ms = 200
        self.parent = None
        self.widget = None
        self.border = None
        self.state  = False
        self.on_click = None       # 額外掛鉤：呼叫簽名 f(btn)

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "mode":         self.mode,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "text":         self.text,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "tgr_bg_color": self.tgr_bg_color,
            "tgr_fg_color": self.tgr_fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
            "state":        self.state,
        }

    def is_on(self) -> bool:
        return self.state

    def is_off(self) -> bool:
        return not self.state

    def read(self) -> bool:
        return self.state

    def on(self):
        self.state = True
        self._refresh()

    def off(self):
        self.state = False
        self._refresh()

    def toggle(self):
        if self.state:
            self.off()
        else:
            self.on()

    def style(self, bg=None, fg=None, text=None):
        if bg is not None:
            self.bg_color = bg
        if fg is not None:
            self.fg_color = fg
        if text is not None:
            self.text = str(text)
        self._refresh()
        return self

    def _refresh(self):
        if self.widget is None:
            return
        if self.state:
            bg, fg = self.tgr_bg_color, self.tgr_fg_color
        else:
            bg, fg = self.bg_color, self.fg_color
        self.widget.config(
            bg=bg, fg=fg,
            activebackground=bg,
            activeforeground=fg,
            text=self.text,
        )

    def _on_click(self):
        if self.mode == "binary":
            self.toggle()
        elif self.mode == "single":
            self.state = True
            if self.widget is not None:
                self.widget.after(self.single_pulse_ms, self._clear_single)
        else:
            self.toggle()
        if callable(self.on_click):
            try:
                self.on_click(self)
            except Exception as e:
                print(f"[TK_Button {self.name}] on_click 錯誤: {e}")

    def _clear_single(self):
        self.state = False

    def __repr__(self):
        return (
            f"<TK_Button {self.name} parent={self.parent_name} "
            f"mode={self.mode} state={'on' if self.state else 'off'}>"
        )


class TK_Label:
    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.mode        = cfg["mode"] or "single"
        self.row         = int(cfg["row"])       if cfg["row"]       else 0
        self.col         = int(cfg["col"])       if cfg["col"]       else 0
        self.row_spn     = int(cfg["row_spn"])   if cfg["row_spn"]   else 1
        self.col_spn     = int(cfg["col_spn"])   if cfg["col_spn"]   else 1
        self._text       = cfg["text"] or self.name
        self.bg_color     = cfg["bg_color"] or "white"
        self.fg_color     = cfg["fg_color"] or "black"
        self.tgr_bg_color = cfg.get("tgr_bg_color") or self.bg_color
        self.tgr_fg_color = cfg.get("tgr_fg_color") or self.fg_color
        self.fontsize     = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth    = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"
        self.parent = None
        self.widget = None
        self.border = None

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "mode":         self.mode,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "text":         self._text,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "tgr_bg_color": self.tgr_bg_color,
            "tgr_fg_color": self.tgr_fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
        }

    def text(self, new_text=None):
        if new_text is None:
            return self._text
        self._text = str(new_text)
        self._refresh()
        return self._text

    def style(self, bg=None, fg=None, text=None):
        if bg is not None:
            self.bg_color = bg
        if fg is not None:
            self.fg_color = fg
        if text is not None:
            self._text = str(text)
        self._refresh()
        return self

    def _refresh(self):
        if self.widget is None:
            return
        self.widget.config(bg=self.bg_color, fg=self.fg_color, text=self._text)

    def __repr__(self):
        return (
            f"<TK_Label {self.name} parent={self.parent_name} "
            f"mode={self.mode} text={self._text!r}>"
        )


class TK_ScrollText:
    """
    Tkinter 唯讀 / 可編輯滾動文字區。

    重點行為：
      - 唯讀（未填 edit）時 widget 仍保持 state="normal"，
        因此滑鼠拖曳選取、Ctrl+C、Ctrl+A、滑輪、拖捲軸全部可用；
        但打字 / 貼上 / 剪下 / 中鍵粘貼被守門函式攔截。
      - write() / append() 可指定單次 bg / fg，內部以 Text tag 實現。
      - write_async() 執行緒安全，可從任何子執行緒呼叫。
    """
    _NAV_KEYS = frozenset({
        "Up", "Down", "Left", "Right",
        "Home", "End", "Prior", "Next",
        "Shift_L", "Shift_R",
        "Control_L", "Control_R",
        "Alt_L", "Alt_R",
        "Meta_L", "Meta_R",
        "Super_L", "Super_R",
    })

    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.mode        = cfg["mode"] or ""
        self.row         = int(cfg["row"])       if cfg["row"]       else 0
        self.col         = int(cfg["col"])       if cfg["col"]       else 0
        self.row_spn     = int(cfg["row_spn"])   if cfg["row_spn"]   else 1
        self.col_spn     = int(cfg["col_spn"])   if cfg["col_spn"]   else 1
        self.bg_color     = cfg["bg_color"] or "white"
        self.fg_color     = cfg["fg_color"] or "black"
        self.tgr_bg_color = cfg.get("tgr_bg_color") or self.bg_color
        self.tgr_fg_color = cfg.get("tgr_fg_color") or self.fg_color
        self.fontsize     = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth    = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"
        self.editable   = False
        self.wrap       = "word"
        self.vscroll    = "auto"
        self.autoscroll = True
        self.max_lines  = 8000
        self.parent = None
        self.widget = None
        self.border = None
        self.sbar   = None
        self._text          = cfg["text"] or ""
        self._line_count    = self._text.count("\n")
        self._pending_text  = None
        self._pending_lines = []
        self._pending_limit = 20000
        self._pending_lock  = threading.Lock()
        self._dropped       = 0
        self._pump_running  = False
        self._pump_interval = 20
        self._user_scroll   = False
        self._tag_cache     = {}          # (bg, fg) → tag 名稱
        self._parse_mode(self.mode)

    def _parse_mode(self, raw):
        for item in str(raw).split(";"):
            item = item.strip().lower()
            if not item:
                continue
            if item == "edit":
                self.editable = True
                continue
            if "=" not in item:
                continue
            key, val = [s.strip() for s in item.split("=", 1)]
            if key == "wrap" and val in ("word", "char", "none"):
                self.wrap = val
            elif key == "vscroll" and val in ("auto", "always", "off"):
                self.vscroll = val
            elif key == "autoscroll" and val in ("on", "off"):
                self.autoscroll = val == "on"
            elif key == "maxlines" and val.isdigit():
                self.max_lines = int(val)

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "mode":         self.mode,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "tgr_bg_color": self.tgr_bg_color,
            "tgr_fg_color": self.tgr_fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
            "editable":     self.editable,
            "wrap":         self.wrap,
            "vscroll":      self.vscroll,
            "autoscroll":   self.autoscroll,
            "max_lines":    self.max_lines,
            "line_count":   self.line_count(),
            "pending":      self.pending(),
            "dropped":      self._dropped,
        }

    # ---------------------------------------------------------------- mount
    def mount(self, container):
        self.border = tk.Frame(container, bg=self.border_color)
        self.border.grid_columnconfigure(0, weight=1)
        self.border.grid_rowconfigure(0, weight=1)
        self.widget = tk.Text(
            self.border, wrap=self.wrap,
            bg=self.bg_color, fg=self.fg_color,
            font=("Arial", self.fontsize),
            bd=0, relief="flat", highlightthickness=0,
            insertbackground=self.fg_color, undo=False,
        )
        self.sbar = tk.Scrollbar(self.border, orient="vertical", command=self.widget.yview)
        self.widget.configure(yscrollcommand=self.sbar.set)
        self.widget.grid(row=0, column=0, sticky="nsew",
                         padx=self.linewidth, pady=self.linewidth)
        self.border.grid(row=self.row, column=self.col,
                         rowspan=self.row_spn, columnspan=self.col_spn,
                         sticky="nsew", padx=1, pady=1)

        # --- 使用者捲動偵測 ---
        self.widget.bind("<MouseWheel>", self._on_user_scroll, add="+")
        self.widget.bind("<Button-4>",   self._on_user_scroll, add="+")
        self.widget.bind("<Button-5>",   self._on_user_scroll, add="+")
        self.widget.bind("<Key>",        self._on_user_scroll, add="+")

        # --- 唯讀守門（editable=True 時全部放行） ---
        self.widget.bind("<KeyPress>",   self._on_key_guard,   add="+")
        self.widget.bind("<<Paste>>",    self._on_paste_guard, add="+")
        self.widget.bind("<Control-v>",  self._on_paste_guard, add="+")
        self.widget.bind("<Control-x>",  self._on_paste_guard, add="+")
        self.widget.bind("<Button-2>",   self._on_paste_guard, add="+")   # X11 中鍵粘貼

        # --- 唯讀視覺：隱藏游標、不搶焦點 ---
        if not self.editable:
            self.widget.configure(insertwidth=0, takefocus=0)

        self._apply_state()
        self._set_content(self._text)
        self._text = ""
        self._trim()
        self._apply_vscroll()
        self._scroll_end(True)
        self._start_pump()
        return self

    # ---------------------------------------------------------------- 寫入 API
    def write(self, text="", autoscroll=None, bg=None, fg=None):
        """插入一行（自動前置換行）。可指定單次 bg / fg。"""
        self._edit(lambda: self._insert_raw(str(text), True, bg, fg))
        self._after_write(autoscroll)
        return self

    def append(self, text="", autoscroll=None, bg=None, fg=None):
        """接續插入（不補前置換行）。可指定單次 bg / fg。"""
        self._edit(lambda: self._insert_raw(str(text), False, bg, fg))
        self._after_write(autoscroll)
        return self

    def set(self, text="", autoscroll=None):
        self._set_content(text)
        self._user_scroll = False
        self._after_write(autoscroll)
        return self

    def clear(self):
        return self.set("")

    def read(self):
        return "\n".join(self._lines())

    def read_last(self, n=1):
        n = int(n)
        if n <= 0:
            return []
        return self._lines()[-n:]

    def line_count(self):
        return len(self._lines())

    def set_maxlines(self, n):
        self.max_lines = int(n)
        self._trim()
        return self

    def set_autoscroll(self, on=True):
        self.autoscroll = bool(on)
        return self

    def scroll_to_end(self):
        self._user_scroll = False
        self._scroll_end(True)
        return self

    def pending(self):
        with self._pending_lock:
            return len(self._pending_lines) + (1 if self._pending_text is not None else 0)

    # ---------------------------------------------------------------- 執行緒安全 API
    def write_async(self, text="", bg=None, fg=None):
        """執行緒安全。只入佇列不碰 tk 物件；行不丟、順序不亂。"""
        self._queue(str(text), True, bg, fg)

    def set_async(self, text=""):
        """執行緒安全。單槽緩衝，由主執行緒 _pump() 換掉全部內容。"""
        with self._pending_lock:
            self._pending_text = str(text)

    def _queue(self, text, newline, bg=None, fg=None):
        with self._pending_lock:
            if len(self._pending_lines) >= self._pending_limit:
                self._pending_lines.pop(0)
                self._dropped += 1
            self._pending_lines.append((text, newline, bg, fg))

    def _start_pump(self):
        if self._pump_running or self.widget is None:
            return
        self._pump_running = True
        self.widget.after(self._pump_interval, self._pump)

    def _pump(self):
        if not self._pump_running or self.widget is None:
            return
        with self._pending_lock:
            text  = self._pending_text
            items = self._pending_lines
            self._pending_text  = None
            self._pending_lines = []
        if text is not None:
            self._set_content(text)
            self._user_scroll = False
        if items:
            def _job():
                for t, n, bg, fg in items:
                    self._insert_raw(t, n, bg, fg)
            self._edit(_job)
        if text is not None or items:
            self._after_write()
        self.widget.after(self._pump_interval, self._pump)

    # ---------------------------------------------------------------- 唯讀守門
    def _on_key_guard(self, event):
        """
        唯讀時：允許導覽 / 修飾鍵 / Ctrl+C / Ctrl+A / Ctrl+Insert；
                其餘（字母、數字、標點、Enter、Backspace、Delete…）吃掉。
        editable=True 時全部放行。
        """
        if self.editable:
            return None
        ks = event.keysym
        # 修飾 / 導覽鍵放行
        if ks in self._NAV_KEYS:
            return None
        # Shift + 方向鍵（擴選）放行
        if (event.state & 0x1) and ks in ("Up", "Down", "Left", "Right", "Home", "End"):
            return None
        # Ctrl 組合鍵：只放行複製 / 全選 / Insert
        if event.state & 0x4:
            if ks.lower() in ("c", "a", "insert"):
                return None
            return "break"
        return "break"

    def _on_paste_guard(self, event=None):
        if self.editable:
            return None
        return "break"

    # ---------------------------------------------------------------- 內部：tag
    def _make_tag(self, bg, fg):
        """為 (bg, fg) 取得 / 建立唯一的 Text tag。widget 不存在時回傳 None。"""
        if self.widget is None:
            return None
        key = (bg, fg)
        tag = self._tag_cache.get(key)
        if tag is not None:
            return tag
        tag = f"__c{len(self._tag_cache)}"
        kw = {}
        if bg is not None:
            kw["background"] = bg
        if fg is not None:
            kw["foreground"] = fg
        self.widget.tag_configure(tag, **kw)
        self._tag_cache[key] = tag
        return tag

    # ---------------------------------------------------------------- 內部：內容
    def _body(self):
        if self.widget is None:
            return self._text
        return self.widget.get("1.0", "end-1c")

    def _lines(self):
        lines = self._body().split("\n")
        if lines and not lines[-1]:
            lines.pop()
        return lines

    def _insert_raw(self, text, newline, bg=None, fg=None):
        if self.widget is None:
            pre = "\n" if (newline and self._text and not self._text.endswith("\n")) else ""
            payload = pre + text + ("\n" if newline else "")
            self._text += payload
            self._line_count += payload.count("\n")
            return
        pre = ""
        if newline and self.widget.index("end-1c") != "1.0":
            if self.widget.get("end-2c", "end-1c") != "\n":
                pre = "\n"
        payload = pre + text + ("\n" if newline else "")
        tag = self._make_tag(bg, fg) if (bg is not None or fg is not None) else None
        if tag is not None:
            self.widget.insert("end-1c", payload, (tag,))
        else:
            self.widget.insert("end-1c", payload)
        self._line_count += payload.count("\n")

    def _set_content(self, text):
        text = str(text)
        if self.widget is None:
            self._text = text
            self._line_count = text.count("\n")
            return
        def _job():
            self.widget.delete("1.0", "end")
            if text:
                self.widget.insert("1.0", text)
        self._edit(_job)
        self._line_count = text.count("\n")

    def _after_write(self, autoscroll=None):
        if autoscroll is not None:
            self.autoscroll = bool(autoscroll)
        self._trim()
        if self._at_end():
            self._user_scroll = False
        if self.autoscroll and not self._user_scroll:
            self._scroll_end(True)
        self._apply_vscroll()

    def _trim(self):
        if self.widget is None or self.max_lines <= 0:
            return
        if self._line_count < self.max_lines:
            return
        total = self.line_count()
        drop = total - self.max_lines
        if drop > 0:
            self._edit(lambda: self.widget.delete("1.0", f"{drop + 1}.0"))
            self._line_count = self.max_lines
        else:
            self._line_count = total

    # ---------------------------------------------------------------- 內部：狀態
    def _edit(self, func):
        """
        widget 永遠保持 state="normal"，這裡只負責執行 func。
        唯讀保護交由 _on_key_guard / _on_paste_guard 處理。
        """
        if self.widget is None:
            func()
            return
        func()

    def _apply_state(self):
        if self.widget is None:
            return
        # 永遠 normal：讓選取 / 複製 / 捲動可用
        self.widget.configure(state="normal")

    def _apply_vscroll(self):
        if self.sbar is None:
            return
        if self.vscroll == "off":
            self.sbar.grid_remove()
            return
        if self.vscroll == "auto":
            low, high = self.widget.yview()
            if low <= 0.0 and high >= 1.0:
                self.sbar.grid_remove()
                return
        self.sbar.grid(row=0, column=1, sticky="ns",
                       padx=self.linewidth, pady=self.linewidth)

    def _at_end(self):
        if self.widget is None:
            return True
        return self.widget.yview()[1] >= 0.999

    def _scroll_end(self, force=False):
        if self.widget is None:
            return
        if not force and not self.autoscroll:
            return
        self.widget.see("end-1c")

    def _on_user_scroll(self, event=None):
        self._user_scroll = True

    def __repr__(self):
        return (
            f"<TK_ScrollText {self.name} parent={self.parent_name} "
            f"lines={self.line_count()} editable={self.editable} "
            f"wrap={self.wrap} vscroll={self.vscroll} max={self.max_lines}>"
        )

class TK_PageBtn:
    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        raw = cfg["mode"] or ""
        if "#" in raw:
            tgt, pid = raw.split("#", 1)
            self.target_frame = tgt.strip()
            pid = pid.strip()
            if pid.lower().startswith("page"):
                pid = pid[4:]
            self.page_id = pid
        else:
            self.target_frame = ""
            self.page_id = ""
        self.page_id_ctrl = (cfg.get("page") or "").strip()
        self.row     = int(cfg["row"])     if cfg["row"]     else 0
        self.col     = int(cfg["col"])     if cfg["col"]     else 0
        self.row_spn = int(cfg["row_spn"]) if cfg["row_spn"] else 1
        self.col_spn = int(cfg["col_spn"]) if cfg["col_spn"] else 1
        self.text        = cfg["text"] or self.name
        self.bg_color    = cfg["bg_color"] or "white"
        self.fg_color    = cfg["fg_color"] or "black"
        self.tgr_bg_color = cfg.get("tgr_bg_color") or self.bg_color
        self.tgr_fg_color = cfg.get("tgr_fg_color") or self.fg_color
        self.fontsize    = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth   = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"
        self.parent  = None
        self.widget  = None
        self.border  = None
        self._helper = None
        self._active = False

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id_ctrl,
            "type":         self.type,
            "mode":         f"{self.target_frame}#{self.page_id}",
            "target_frame": self.target_frame,
            "page_id":      self.page_id,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "text":         self.text,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "tgr_bg_color": self.tgr_bg_color,
            "tgr_fg_color": self.tgr_fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
            "active":       self._active,
        }

    def is_active(self) -> bool:
        return self._active

    def activate(self):
        helper = self._helper
        if helper is None:
            return
        group = helper.page_groups.get(self.target_frame, [])
        for pb in group:
            pb._active = (pb is self)
            pb._set_visual(pb is self)
        target = helper.frames.get(self.target_frame)
        if target is not None:
            target.show_page(self.page_id)

    def _set_visual(self, active: bool):
        if self.widget is None:
            return
        if active:
            self.widget.config(
                bg=self.tgr_bg_color, fg=self.tgr_fg_color,
                activebackground=self.tgr_bg_color,
                activeforeground=self.tgr_fg_color,
            )
        else:
            self.widget.config(
                bg=self.bg_color, fg=self.fg_color,
                activebackground=self.bg_color,
                activeforeground=self.fg_color,
            )

    def _on_click(self):
        self.activate()

    def __repr__(self):
        state = "active" if self._active else "inactive"
        return (f"<TK_PageBtn {self.name} parent={self.parent_name} "
                f"target={self.target_frame} page={self.page_id} {state}>")

class TK_Canvas:
    """
    Tkinter 畫布控件，內建一個 Imgtool 實例。

    基本用法：
        cav.set((400, 300))
        cav.set("path/to/img.png", fit=True)
        cav.set(np.ndarray)
        cav.set(Imgtool(...))
        cav.im          # 取得內部 Imgtool
        cav.get()       # 同上
        cav.clear()     # 清空
        cav.render()    # 手動觸發重繪

    跨執行緒用法（子執行緒持續刷新）：
        cav.set_async(im, fit=True)   # 任何執行緒都可呼叫
        主執行緒由 _pump() 定時取最新一張渲染

    滑鼠互動旗標：
        cav.enable_wheel_zoom  = True
        cav.enable_drag_pan    = True
        cav.enable_mouse_bound = True
        cav.set_flags(wheel_zoom=True, drag_pan=True, mouse_bound=True)

    座標讀取：
        cav.canvas_to_raw(x, y)
        cav.raw_to_canvas(rx, ry)
        cav.mouse_canvas / mouse_raw            受 bound 影響
        cav.mouse_canvas_real / mouse_raw_real  永遠真實
        cav.is_in_image()
    """
    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.row         = int(cfg["row"])       if cfg["row"]       else 0
        self.col         = int(cfg["col"])       if cfg["col"]       else 0
        self.row_spn     = int(cfg["row_spn"])   if cfg["row_spn"]   else 1
        self.col_spn     = int(cfg["col_spn"])   if cfg["col_spn"]   else 1
        self.bg_color    = cfg["bg_color"] or "white"
        self.linewidth   = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"
        self.parent    = None
        self.widget    = None
        self.border    = None
        self._im       = None
        self._photo    = None
        self._fit      = False
        self._item_id  = None
        self._enable_wheel_zoom = False
        self._enable_drag_pan   = False
        self._zoom     = 1.0
        self._pan_x    = 0.0
        self._pan_y    = 0.0
        self._drag_start = None
        self._render_info  = None
        self._mouse_canvas = None
        self._mouse_raw    = None
        self._bound_mouse  = False

        # === 跨執行緒更新（新增）===
        self._pending_im    = None
        self._pending_fit   = None
        self._pending_lock  = threading.Lock()
        self._pump_running  = False
        self._pump_interval = 20        # ms，上限約 50Hz

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "bg_color":     self.bg_color,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
            "has_image":    self._im is not None,
            "fit":          self._fit,
            "zoom":         self._zoom,
            "pan_x":        self._pan_x,
            "pan_y":        self._pan_y,
            "wheel_zoom":   self._enable_wheel_zoom,
            "drag_pan":     self._enable_drag_pan,
            "mouse_bound":  self._bound_mouse,
            "mouse_canvas": self._mouse_canvas,
            "mouse_raw":    self._mouse_raw,
        }

    def set(self, img=None, fit=None):
        if img is not None:
            self._im = img if isinstance(img, Imgtool) else Imgtool(img)
        if fit is not None:
            self._fit = bool(fit)
        self._request_render()
        return self

    # ======================================================
    #  跨執行緒入口（新增）
    # ======================================================
    def set_async(self, im=None, fit=None):
        """
        執行緒安全。可從任何子執行緒呼叫。
        只把影像放進單槽緩衝，不碰任何 tk 物件。
        主執行緒的 _pump() 會取「最新一張」渲染，舊幀自動被丟棄。
        """
        if im is None and fit is None:
            return
        with self._pending_lock:
            self._pending_im  = im
            self._pending_fit = fit

    def _start_pump(self):
        """由主執行緒在 _create_canvas 時呼叫一次。"""
        if self._pump_running:
            return
        self._pump_running = True
        self.widget.after(self._pump_interval, self._pump)

    def _pump(self):
        """主執行緒的定時迴圈：把緩衝裡最新一張畫出來。"""
        if not self._pump_running or self.widget is None:
            return

        # 取最新（並清空緩衝）
        with self._pending_lock:
            im  = self._pending_im
            fit = self._pending_fit
            self._pending_im  = None
            self._pending_fit = None

        if im is not None or fit is not None:
            if im is not None:
                self._im = im if isinstance(im, Imgtool) else Imgtool(im)
            if fit is not None:
                self._fit = bool(fit)
            self._render()          # 已在主執行緒，直接同步呼叫

        self.widget.after(self._pump_interval, self._pump)

    # ======================================================

    def get(self):
        return self._im

    @property
    def im(self):
        return self._im

    def clear(self):
        self._im = None
        self._render_info = None
        self._request_render()
        return self

    def render(self):
        self._request_render()
        return self

    @property
    def enable_wheel_zoom(self) -> bool:
        return self._enable_wheel_zoom

    @enable_wheel_zoom.setter
    def enable_wheel_zoom(self, v):
        self._enable_wheel_zoom = bool(v)

    @property
    def enable_drag_pan(self) -> bool:
        return self._enable_drag_pan

    @enable_drag_pan.setter
    def enable_drag_pan(self, v):
        self._enable_drag_pan = bool(v)
        if not self._enable_drag_pan:
            self._drag_start = None
            if self.widget is not None:
                try:
                    self.widget.config(cursor="")
                except tk.TclError:
                    pass

    @property
    def enable_mouse_bound(self) -> bool:
        return self._bound_mouse

    @enable_mouse_bound.setter
    def enable_mouse_bound(self, v):
        self._bound_mouse = bool(v)

    def set_flags(self, wheel_zoom=None, drag_pan=None, mouse_bound=None):
        if wheel_zoom is not None:
            self.enable_wheel_zoom = wheel_zoom
        if drag_pan is not None:
            self.enable_drag_pan = drag_pan
        if mouse_bound is not None:
            self.enable_mouse_bound = mouse_bound
        return self

    def reset_view(self):
        self._zoom  = 1.0
        self._pan_x = 0.0
        self._pan_y = 0.0
        self._request_render()
        return self

    @property
    def view(self) -> dict:
        return {
            "zoom":  self._zoom,
            "pan_x": self._pan_x,
            "pan_y": self._pan_y,
            "wheel": self._enable_wheel_zoom,
            "drag":  self._enable_drag_pan,
            "bound": self._bound_mouse,
        }

    def canvas_to_raw(self, x, y):
        info = self._render_info
        if info is None or info["img_w"] == 0 or info["img_h"] == 0:
            return None
        sx = info["disp_w"] / info["img_w"]
        sy = info["disp_h"] / info["img_h"]
        if sx == 0 or sy == 0:
            return None
        rx = (x - info["cx"]) / sx + info["img_w"] / 2.0
        ry = (y - info["cy"]) / sy + info["img_h"] / 2.0
        return (rx, ry)

    def raw_to_canvas(self, rx, ry):
        info = self._render_info
        if info is None or info["img_w"] == 0 or info["img_h"] == 0:
            return None
        sx = info["disp_w"] / info["img_w"]
        sy = info["disp_h"] / info["img_h"]
        x = (rx - info["img_w"] / 2.0) * sx + info["cx"]
        y = (ry - info["img_h"] / 2.0) * sy + info["cy"]
        return (x, y)

    @property
    def mouse_canvas(self):
        if self._mouse_canvas is None:
            return None
        if not self._bound_mouse or self.widget is None:
            return self._mouse_canvas
        cw = self.widget.winfo_width()
        ch = self.widget.winfo_height()
        if cw <= 1 or ch <= 1:
            return self._mouse_canvas
        x, y = self._mouse_canvas
        return (max(0, min(x, cw - 1)), max(0, min(y, ch - 1)))

    @property
    def mouse_raw(self):
        if self._mouse_raw is None:
            return None
        if not self._bound_mouse or self._im is None:
            return self._mouse_raw
        ih, iw = self._im.get().shape[:2]
        rx, ry = self._mouse_raw
        return (max(0.0, min(rx, iw - 1.0)),
                max(0.0, min(ry, ih - 1.0)))

    @property
    def mouse_canvas_real(self):
        return self._mouse_canvas

    @property
    def mouse_raw_real(self):
        return self._mouse_raw

    def is_in_image(self):
        if self._mouse_raw is None or self._im is None:
            return False
        rx, ry = self._mouse_raw
        ih, iw = self._im.get().shape[:2]
        return 0 <= rx < iw and 0 <= ry < ih

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        im = self.__dict__.get("_im")
        if im is None:
            raise AttributeError(
                f"TK_Canvas('{self.__dict__.get('name', '?')}') 尚未 set() 影像，"
                f"無法呼叫 '{name}'"
            )
        attr = getattr(im, name)
        if callable(attr):
            def _proxy(*args, **kwargs):
                result = attr(*args, **kwargs)
                self._request_render()
                return self if result is im else result
            return _proxy
        return attr

    def _on_wheel(self, event):
        if not self._enable_wheel_zoom:
            return
        if self._im is None or self.widget is None:
            return
        if getattr(event, "num", None) == 4:
            steps = 1.0
        elif getattr(event, "num", None) == 5:
            steps = -1.0
        elif hasattr(event, "delta") and event.delta != 0:
            steps = event.delta / 120.0 if abs(event.delta) >= 120 else event.delta
        else:
            return
        factor = 1.1 ** steps
        self._apply_zoom(factor, event.x, event.y)

    def _apply_zoom(self, factor: float, mx: int, my: int):
        cw = self.widget.winfo_width()
        ch = self.widget.winfo_height()
        old = self._zoom
        new = max(0.05, min(50.0, old * factor))
        if new == old:
            return
        real = new / old
        cx = cw / 2.0 + self._pan_x
        cy = ch / 2.0 + self._pan_y
        self._pan_x = mx - (mx - cx) * real - cw / 2.0
        self._pan_y = my - (my - cy) * real - ch / 2.0
        self._zoom  = new
        self._request_render()

    def _on_drag_start(self, event):
        if not self._enable_drag_pan:
            return
        self._drag_start = (event.x, event.y, self._pan_x, self._pan_y)
        if self.widget is not None:
            self.widget.config(cursor="fleur")

    def _on_drag_move(self, event):
        if not self._enable_drag_pan or self._drag_start is None:
            return
        x0, y0, px0, py0 = self._drag_start
        self._pan_x = px0 + (event.x - x0)
        self._pan_y = py0 + (event.y - y0)
        self._request_render()

    def _on_drag_end(self, event):
        self._drag_start = None
        if self.widget is not None:
            try:
                self.widget.config(cursor="")
            except tk.TclError:
                pass

    def _on_motion(self, event):
        self._mouse_canvas = (event.x, event.y)
        self._mouse_raw = self.canvas_to_raw(event.x, event.y)

    def _on_leave(self, event):
        self._mouse_canvas = None
        self._mouse_raw = None

    def _request_render(self):
        if self.widget is None:
            return
        try:
            self.widget.after(0, self._render)
        except tk.TclError:
            pass

    def _render(self):
        if self.widget is None:
            return
        self.widget.delete("all")
        self._photo   = None
        self._item_id = None
        if self._im is None:
            self._render_info = None
            return
        cw = self.widget.winfo_width()
        ch = self.widget.winfo_height()
        if cw <= 1 or ch <= 1:
            return
        arr = self._im.get()
        ih, iw = arr.shape[:2]
        if iw <= 0 or ih <= 0:
            self._render_info = None
            return
        if self._fit:
            base = min(cw / iw, ch / ih)
        else:
            base = 1.0
        total  = base * self._zoom
        cx = cw // 2 + int(self._pan_x)
        cy = ch // 2 + int(self._pan_y)
        self._render_info = {
            "cx":     cx,
            "cy":     cy,
            "disp_w": iw * total,
            "disp_h": ih * total,
            "img_w":  iw,
            "img_h":  ih,
        }
        rx0 = iw / 2.0 - cx / total
        ry0 = ih / 2.0 - cy / total
        rx1 = iw / 2.0 + (cw - cx) / total
        ry1 = ih / 2.0 + (ch - cy) / total
        x0 = max(0, int(rx0))
        y0 = max(0, int(ry0))
        x1 = min(iw, int(rx1) + 1)
        y1 = min(ih, int(ry1) + 1)
        if x1 <= x0 or y1 <= y0:
            return
        roi = arr[y0:y1, x0:x1]
        pil_img = Imgtool._bgr_to_pil(np.ascontiguousarray(roi))
        disp_cw = max(1, int((x1 - x0) * total + 0.5))
        disp_ch = max(1, int((y1 - y0) * total + 0.5))
        if (disp_cw, disp_ch) != (x1 - x0, y1 - y0):
            pil_img = pil_img.resize((disp_cw, disp_ch), Image.LANCZOS)
        dx = int((x0 - iw / 2.0) * total + cx + 0.5)
        dy = int((y0 - ih / 2.0) * total + cy + 0.5)
        self._photo = ImageTk.PhotoImage(pil_img)
        self._item_id = self.widget.create_image(
            dx, dy, anchor="nw", image=self._photo
        )

    def __repr__(self):
        has = "yes" if self._im is not None else "no"
        mouse_c = f"{self._mouse_canvas}" if self._mouse_canvas else "-"
        mouse_r = (f"({self._mouse_raw[0]:.1f},{self._mouse_raw[1]:.1f})"
                   if self._mouse_raw else "-")
        return (f"<TK_Canvas {self.name} parent={self.parent_name} "
                f"img={has} fit={self._fit} "
                f"zoom={self._zoom:.2f} pan=({self._pan_x:+.0f},{self._pan_y:+.0f}) "
                f"wheel={'on' if self._enable_wheel_zoom else 'off'} "
                f"drag={'on' if self._enable_drag_pan else 'off'} "
                f"bound={'on' if self._bound_mouse else 'off'} "
                f"mouse_c={mouse_c} mouse_r={mouse_r}>")

class TK_Figure:
    """
    Tkinter + matplotlib 圖表控件。

    內部物件：
      self.fig     : matplotlib.figure.Figure
      self.ax      : 主 Axes（預設 111）
      self.canvas  : FigureCanvasTkAgg
      self.widget  : tk.Canvas（由 FigureCanvasTkAgg 提供，已 pack 進 border）

    高階繪圖（自動重繪）：
      fig.plot(x, y, ...)         → ax.plot
      fig.scatter(x, y, ...)      → ax.scatter
      fig.bar(x, h, ...)          → ax.bar
      fig.hist(data, ...)         → ax.hist
      fig.clear(keep_axes=True)   → 清空繪圖元素

    屬性代理：
      fig.set_title('x')  / set_xlabel / legend / grid / ...
        呼叫完會自動重繪；若原方法回傳 ax（支援鏈式），則改回傳 self
      fig.lines / fig.collections / ...
        直接讀取 ax 的屬性

    低階使用：
      fig.ax.plot(...)   # 不自動重繪
      fig.draw()

    CSV：
      - type  填 "figure"
      - mode  可填 "6x4"（寬x高，吋）；留空預設 5x4
      - text / tgr_* 不使用
      - bg_color 同時套用到 Figure 與 Axes 底色
    """
    _DEFAULT_FIGSIZE = (5.0, 4.0)
    _DEFAULT_DPI     = 100

    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.type        = cfg["type"]
        self.page_id     = (cfg.get("page") or "").strip()
        self.row     = int(cfg["row"])     if cfg["row"]     else 0
        self.col     = int(cfg["col"])     if cfg["col"]     else 0
        self.row_spn = int(cfg["row_spn"]) if cfg["row_spn"] else 1
        self.col_spn = int(cfg["col_spn"]) if cfg["col_spn"] else 1

        self.bg_color     = cfg["bg_color"] or "white"
        self.fg_color     = cfg["fg_color"] or "black"
        self.fontsize     = int(cfg["fontsize"])  if cfg["fontsize"]  else 10
        self.linewidth    = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.border_color = cfg.get("border_color") or "black"

        # mode 當作 figsize 解析（"6x4"）
        self.figsize = self._parse_figsize(cfg.get("mode"))
        self.dpi     = self._DEFAULT_DPI
        self.toolbar = False          # 需要導覽列時設 True

        # matplotlib 物件（由 _create_figure 建立）
        self.fig    = None
        self.ax     = None
        self.canvas = None

        # tkinter 物件
        self.parent          = None
        self.widget          = None
        self.border          = None
        self._toolbar_widget = None

    # ------------------------------------------------------------ helpers
    @staticmethod
    def _parse_figsize(spec):
        if not spec:
            return TK_Figure._DEFAULT_FIGSIZE
        s = str(spec).strip().lower()
        if "x" in s:
            try:
                w, h = s.split("x", 1)
                return (float(w), float(h))
            except ValueError:
                pass
        return TK_Figure._DEFAULT_FIGSIZE

    @property
    def config(self) -> dict:
        return {
            "name":         self.name,
            "parent":       self.parent_name,
            "page":         self.page_id,
            "type":         self.type,
            "mode":         f"{self.figsize[0]:g}x{self.figsize[1]:g}",
            "row":          self.row,
            "col":          self.col,
            "row_spn":      self.row_spn,
            "col_spn":      self.col_spn,
            "bg_color":     self.bg_color,
            "fg_color":     self.fg_color,
            "fontsize":     self.fontsize,
            "linewidth":    self.linewidth,
            "border_color": self.border_color,
            "figsize":      self.figsize,
            "dpi":          self.dpi,
            "has_axes":     self.ax is not None,
        }

    # ------------------------------------------------------------ 繪圖 API
    def plot(self, *args, **kwargs):
        """包裝 ax.plot，自動重繪。回傳 matplotlib 的 Line2D 列表。"""
        if self.ax is None:
            raise RuntimeError(f"TK_Figure('{self.name}') 尚未建立 axes")
        result = self.ax.plot(*args, **kwargs)
        self.draw()
        return result

    def scatter(self, *args, **kwargs):
        """包裝 ax.scatter，自動重繪。回傳 PathCollection。"""
        if self.ax is None:
            raise RuntimeError(f"TK_Figure('{self.name}') 尚未建立 axes")
        result = self.ax.scatter(*args, **kwargs)
        self.draw()
        return result

    def bar(self, *args, **kwargs):
        """包裝 ax.bar，自動重繪。回傳 BarContainer。"""
        if self.ax is None:
            raise RuntimeError(f"TK_Figure('{self.name}') 尚未建立 axes")
        result = self.ax.bar(*args, **kwargs)
        self.draw()
        return result

    def barh(self, *args, **kwargs):
        """包裝 ax.barh，自動重繪。回傳 BarContainer。"""
        if self.ax is None:
            raise RuntimeError(f"TK_Figure('{self.name}') 尚未建立 axes")
        result = self.ax.barh(*args, **kwargs)
        self.draw()
        return result

    def hist(self, *args, **kwargs):
        """包裝 ax.hist，自動重繪。"""
        if self.ax is None:
            raise RuntimeError(f"TK_Figure('{self.name}') 尚未建立 axes")
        result = self.ax.hist(*args, **kwargs)
        self.draw()
        return result

    def clear(self, keep_axes=True):
        """
        清除繪圖：
          keep_axes=True  → 只清 ax 內容，保留座標軸物件
          keep_axes=False → 整張 Figure 重來，重新產生 111 axes
        """
        if self.fig is None:
            return self
        if keep_axes and self.ax is not None:
            self.ax.clear()
            self.ax.set_facecolor(self.bg_color)
        else:
            self.fig.clear()
            self.ax = self.fig.add_subplot(111)
            self.ax.set_facecolor(self.bg_color)
        self.draw()
        return self

    def draw(self):
        """觸發非同步重繪（draw_idle）；不阻塞 UI。"""
        if self.canvas is not None:
            try:
                self.canvas.draw_idle()
            except Exception:
                pass
        return self

    render = draw          # 與 TK_Canvas 一致的別名

    def set_bg(self, color):
        """同時更新 Figure / Axes / Tk 外框底色。"""
        self.bg_color = color
        if self.fig is not None:
            self.fig.set_facecolor(color)
        if self.ax is not None:
            self.ax.set_facecolor(color)
        if self.widget is not None:
            try:
                self.widget.configure(bg=color)
            except tk.TclError:
                pass
        self.draw()
        return self

    def get_ax(self):
        """取得原生 Axes（不觸發代理）。"""
        return self.ax

    def get_fig(self):
        """取得原生 Figure。"""
        return self.fig

    # ------------------------------------------------------------ ax 代理
    def __getattr__(self, name):
        # 保護：內部屬性不走代理，避免建構期無限遞迴
        if name.startswith("_"):
            raise AttributeError(name)
        ax = self.__dict__.get("ax")
        if ax is None:
            raise AttributeError(
                f"TK_Figure('{self.__dict__.get('name','?')}') 尚未建立 axes，"
                f"無法存取 '{name}'"
            )
        attr = getattr(ax, name)
        if callable(attr):
            def _proxy(*args, **kwargs):
                result = attr(*args, **kwargs)
                self.draw()
                # 支援鏈式：ax.set_xlabel(...).set_ylabel(...)
                if result is ax:
                    return self
                return result
            return _proxy
        return attr

    def __repr__(self):
        has = "yes" if self.ax is not None else "no"
        return (f"<TK_Figure {self.name} parent={self.parent_name} "
                f"figsize={self.figsize} dpi={self.dpi} ax={has}>")


class TK_Frame:
    def __init__(self, cfg: dict):
        self.name        = cfg["name"]
        self.parent_name = cfg["parent"]
        self.parent_page = (cfg.get("parent_page") or "").strip()
        self.align       = cfg["align"]
        self.w           = float(cfg["w"]) if cfg["w"] else 1.0
        self.h           = float(cfg["h"]) if cfg["h"] else 1.0
        self.pages       = cfg["pages"]
        self.title       = cfg["title"]
        self.grids       = cfg["grids"]
        self.bg_color    = cfg["bg_color"] or "white"
        self.linewidth   = int(cfg["linewidth"]) if cfg["linewidth"] else 1
        self.padding     = FRAME_PADDING
        self.parent      = None
        self.children    = []
        self.widget      = None
        self.title_label = None
        self.content     = None
        self.page_containers = {}
        self.current_page    = None

    @property
    def config(self) -> dict:
        return {
            "name":        self.name,
            "parent":      self.parent_name,
            "parent_page": self.parent_page,
            "align":       self.align,
            "w":           self.w,
            "h":           self.h,
            "pages":       self.pages,
            "title":       self.title,
            "grids":       self.grids,
            "bg_color":    self.bg_color,
            "linewidth":   self.linewidth,
            "padding":     self.padding,
            "current_page": self.current_page,
        }

    def _parse_grids(self):
        s = str(self.grids).strip().lower()
        if not s or "x" not in s:
            return (1, 1)
        r, c = s.split("x")
        return (int(c), int(r))

    def get_page_container(self, page_id):
        page_id = str(page_id)
        if page_id in self.page_containers:
            return self.page_containers[page_id]
        cols, rows = self._parse_grids()
        pc = tk.Frame(self.content, bg=self.bg_color)
        pc.grid(row=0, column=0,
                columnspan=cols, rowspan=rows,
                sticky="nsew")
        for c in range(cols):
            pc.grid_columnconfigure(c, weight=1, minsize=1, uniform="col")
        for r in range(rows):
            pc.grid_rowconfigure(r, weight=1, minsize=1, uniform="row")
        self.page_containers[page_id] = pc
        if self.current_page is None:
            self.current_page = page_id
        else:
            pc.lower()
        return pc

    def show_page(self, page_id):
        page_id = str(page_id)
        pc = self.get_page_container(page_id)
        pc.tkraise()
        self.current_page = page_id

    def effective_master(self, root):
        if self.parent is None:
            return root
        if self.parent_page:
            return self.parent.get_page_container(self.parent_page)
        return self.parent.content

    def __repr__(self):
        return f"<TK_Frame {self.name} parent={self.parent_name}>"


class TK_Helper:
    def __init__(self, size="800x600", loc=(10, 10), title="TKinter", verbose=True):
        self.root = tk.Tk()
        self.root.title(title)
        self.root.geometry(f"{size}+{loc[0]}+{loc[1]}")
        self.frames = {}
        self.ctrls  = {}
        self.page_groups = {}
        self._child_frames = {}
        self._child_ctrls  = {}
        self.verbose = verbose
        self.buffer = []
        self.buffer_lock = threading.Lock()
    def _write(self, cmd):
        with self.buffer_lock :
            self.buffer.append(cmd)
    def interact(self, clear=True):
        with self.buffer_lock :
            ret = self.buffer.copy()
            if clear :
                self.buffer = []
        return ret
    def set_config(self, topmost=False, resizable=None, bg=None):
        self.root.attributes("-topmost", topmost)
        if resizable is not None:
            self.root.resizable(resizable[0], resizable[1])
        if bg is not None:
            self.root.configure(bg=bg)

    def load_frames_config(self, fpath):
        with open(fpath, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        for row in rows:
            row = {k: (v.strip() if isinstance(v, str) else v) for k, v in row.items()}
            if not (row.get("name") or "").strip():
                continue
            frame = TK_Frame(row)
            self.frames[frame.name] = frame
        for frame in self.frames.values():
            if frame.parent_name in self.frames:
                frame.parent = self.frames[frame.parent_name]
                frame.parent.children.append(frame)
                self._child_frames.setdefault(frame.parent_name, []).append(frame.name)
        pending = list(self.frames.values())
        while pending:
            progressed = False
            for f in list(pending):
                if f.parent_name != "root" and f.parent is None:
                    continue
                if f.parent is not None and f.parent.content is None:
                    continue
                master = f.effective_master(self.root)
                self._create_widget(f, master)
                pending.remove(f)
                progressed = True
            if not progressed:
                raise RuntimeError(
                    f"無法解析 frame 的父子關係: {[f.name for f in pending]}"
                )
        self._layout()

    def _create_widget(self, frame: TK_Frame, master):
        frame.widget = tk.Frame(
            master, bg=frame.bg_color,
            highlightthickness=frame.linewidth,
            highlightbackground=FRAME_EDGE_COLOR,
        )
        if frame.title:
            frame.title_label = tk.Label(
                frame.widget, text=frame.title,
                bg=frame.bg_color, fg="black",
                anchor="w", padx=4,
            )
            frame.title_label.pack(side="top", fill="x")
        frame.content = tk.Frame(frame.widget, bg=frame.bg_color)
        frame.content.pack(side="top", fill="both", expand=True,
                           padx=frame.padding, pady=frame.padding)
        cols, rows = frame._parse_grids()
        for c in range(cols):
            frame.content.grid_columnconfigure(c, weight=1, minsize=1, uniform="col")
        for r in range(rows):
            frame.content.grid_rowconfigure(r, weight=1, minsize=1, uniform="row")

    def load_ctrl_config(self, fpath):
        with open(fpath, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        for row in rows:
            row = {k: (v.strip() if isinstance(v, str) else v) for k, v in row.items()}
            ctype = (row.get("type") or "").lower()
            if not ctype:
                continue
            if ctype == "button":
                ctrl = TK_Button(row)
            elif ctype == "entry":
                ctrl = TK_Entry(row)
            elif ctype == "combo":
                ctrl = TK_Combo(row)
            elif ctype == "page":
                ctrl = TK_PageBtn(row)
            elif ctype == "canvas":
                ctrl = TK_Canvas(row)
            elif ctype == "figure":
                ctrl = TK_Figure(row)
            elif ctype == "label":
                ctrl = TK_Label(row)
            elif ctype in ("text", "scrolltext"):
                ctrl = TK_ScrollText(row)
            else:
                continue
            self.ctrls[ctrl.name] = ctrl
        for ctrl in self.ctrls.values():
            if ctrl.parent_name not in self.frames:
                continue
            ctrl.parent = self.frames[ctrl.parent_name]
            self._child_ctrls.setdefault(ctrl.parent_name, []).append(ctrl.name)
            self._check_grid_bounds(ctrl.parent, ctrl)
            if isinstance(ctrl, TK_PageBtn):
                ctrl._helper = self
                self.page_groups.setdefault(ctrl.target_frame, []).append(ctrl)
                self._create_page_button(ctrl)
            elif isinstance(ctrl, TK_Button):
                self._create_button(ctrl)
            elif isinstance(ctrl, TK_Entry):
                self._create_entry(ctrl)
            elif isinstance(ctrl, TK_Combo):
                self._create_combo(ctrl)
            elif isinstance(ctrl, TK_Canvas):
                self._create_canvas(ctrl)
            elif isinstance(ctrl, TK_Figure):
                self._create_figure(ctrl)
            elif isinstance(ctrl, TK_Label):
                self._create_label(ctrl)
            elif isinstance(ctrl, TK_ScrollText):
                self._create_scrolltext(ctrl)
        self._sync_page_buttons()
        self._finalize_grids()
        self._validate_layout()
        self._dump_layout()

    def _check_grid_bounds(self, parent_frame: TK_Frame, ctrl):
        cols, rows = parent_frame._parse_grids()
        if (ctrl.col + ctrl.col_spn > cols) or (ctrl.row + ctrl.row_spn > rows):
            if self.verbose:
                print(f"[警告] ctrl '{ctrl.name}' 在 frame '{parent_frame.name}' 中 "
                      f"(row={ctrl.row}, col={ctrl.col}, "
                      f"span={ctrl.row_spn}x{ctrl.col_spn}) "
                      f"超出 grids={parent_frame.grids} (cols={cols}, rows={rows})")
            new_col = min(ctrl.col, cols - 1)
            new_row = min(ctrl.row, rows - 1)
            ctrl.col_spn = max(1, min(ctrl.col_spn, cols - new_col))
            ctrl.row_spn = max(1, min(ctrl.row_spn, rows - new_row))
            ctrl.col = new_col
            ctrl.row = new_row
            if self.verbose:
                print(f"         → 自動調整為 "
                      f"(row={ctrl.row}, col={ctrl.col}, "
                      f"span={ctrl.row_spn}x{ctrl.col_spn})")

    def _validate_layout(self):
        if not self.verbose:
            return
        all_parents = sorted(set(self._child_frames) | set(self._child_ctrls))
        for parent_name in all_parents:
            fs = self._child_frames.get(parent_name, [])
            cs = self._child_ctrls.get(parent_name, [])
            frame = self.frames.get(parent_name)
            if fs and cs:
                print(f"[錯誤] frame '{parent_name}' 同時有子 frame {fs} 與 ctrl {cs}！"
                      f"frame 用 place、ctrl 用 grid，兩者佈局方式不同，不應混用。")
            if frame is not None:
                cols, rows = frame._parse_grids()
                if cols == 1 and rows == 1 and cs:
                    print(f"[提醒] frame '{parent_name}' 的 grids 是 1x1，"
                          f"依設計應只用來放子 frame（place 佈局），"
                          f"但裡面有 ctrl {cs}。請確認是否配置錯誤。")

    def _dump_layout(self):
        if not self.verbose:
            return
        # print("=" * 72, "FRAMES")
        for name, f in self.frames.items():
            cf = self._child_frames.get(name, [])
            cc = self._child_ctrls.get(name, [])
            # print(f"  {name:12s} parent={f.parent_name:10s} "
                  # f"ppage={str(f.parent_page):4s} align={str(f.align):6s} "
                  # f"grids={str(f.grids):6s} pages={sorted(f.page_containers.keys())} "
                  # f"current={f.current_page}")
            # if cf:
                # print(f"      ├─ child frames : {cf}")
            # if cc:
                # print(f"      └─ child ctrls  : {cc}")
        # print("=" * 72, "CTRLS")
        for name, c in self.ctrls.items():
            page = getattr(c, "page_id_ctrl", None) or getattr(c, "page_id", "")
            extra = ""
            if isinstance(c, TK_Canvas):
                extra = (f" zoom={c._zoom:.2f}"
                         f" pan=({c._pan_x:+.0f},{c._pan_y:+.0f})"
                         f" wheel={'on' if c._enable_wheel_zoom else 'off'}"
                         f" drag={'on' if c._enable_drag_pan else 'off'}"
                         f" bound={'on' if c._bound_mouse else 'off'}")
            elif isinstance(c, TK_Combo):
                extra = (f" value={c._value!r}"
                         f" idx={c.index()}"
                         f" options={c._options}")
            elif isinstance(c, TK_Figure):
                extra = (f" figsize={c.figsize}"
                         f" ax={'yes' if c.ax is not None else 'no'}")
            # print(f"  {name:10s} {type(c).__name__:12s} parent={c.parent_name:10s} "
                  # f"page={str(page):6s} row={c.row} col={c.col} "
                  # f"span={c.row_spn}x{c.col_spn}{extra}")
        # print("=" * 72, "PAGE GROUPS")
        # for tgt, group in self.page_groups.items():
            # print(f"  target={tgt}")
            # for pb in group:
                # print(f"     {pb.name:8s} -> page={pb.page_id:6s} active={pb._active}")
        # print("=" * 72)

    def _resolve_container(self, frame, page_id):
        if not page_id:
            return frame.content
        return frame.get_page_container(page_id)

    def _add_grid_placeholders(self, parent, cols, rows):
        occupied = set()
        for child in parent.winfo_children():
            info = child.grid_info()
            if not info:
                continue
            c0 = int(info.get("column", 0))
            r0 = int(info.get("row", 0))
            cs = int(info.get("columnspan", 1))
            rs = int(info.get("rowspan", 1))
            for cc in range(c0, c0 + cs):
                for rr in range(r0, r0 + rs):
                    occupied.add((cc, rr))
        bg = parent.cget("bg")
        for r in range(rows):
            for c in range(cols):
                if (c, r) in occupied:
                    continue
                ph = tk.Frame(parent, width=1, height=1, bg=bg,
                              highlightthickness=0, bd=0)
                ph.grid(row=r, column=c, sticky="nsew")
                ph.lower()

    def _finalize_grids(self):
        for frame in self.frames.values():
            cols, rows = frame._parse_grids()
            for pc in frame.page_containers.values():
                self._add_grid_placeholders(pc, cols, rows)
            self._add_grid_placeholders(frame.content, cols, rows)

    def _create_page_button(self, pb: TK_PageBtn):
        container = self._resolve_container(pb.parent, pb.page_id_ctrl)
        pb.border = tk.Frame(container, bg=pb.border_color)
        pb.widget = tk.Button(
            pb.border, text=pb.text,
            bg=pb.bg_color, fg=pb.fg_color,
            font=("Arial", pb.fontsize),
            bd=0, relief="flat", highlightthickness=0,
            activebackground=pb.bg_color, activeforeground=pb.fg_color,
            command=pb._on_click,
        )
        pb.widget.pack(fill="both", expand=True,
                       padx=pb.linewidth, pady=pb.linewidth)
        pb.border.grid(row=pb.row, column=pb.col,
                       rowspan=pb.row_spn, columnspan=pb.col_spn,
                       sticky="nsew", padx=1, pady=1)

    def _sync_page_buttons(self):
        for target_name, group in self.page_groups.items():
            if not group:
                continue
            target = self.frames.get(target_name)
            if target is None:
                continue
            matched = None
            for pb in group:
                if pb.page_id == str(target.current_page):
                    matched = pb
                    break
            if matched is None:
                matched = group[0]
            for pb in group:
                pb._active = (pb is matched)
                pb._set_visual(pb is matched)
            target.show_page(matched.page_id)

    def _on_btn_click(self, btn: TK_Button):
        btn._on_click()
        self._write(btn.name)
    def _create_button(self, btn: TK_Button):
        container = self._resolve_container(btn.parent, btn.page_id)
        btn.border = tk.Frame(container, bg=btn.border_color)
        btn.widget = tk.Button(
            btn.border, text=btn.text,
            bg=btn.bg_color, fg=btn.fg_color,
            font=("Arial", btn.fontsize),
            bd=0, relief="flat", highlightthickness=0,
            activebackground=btn.bg_color, activeforeground=btn.fg_color,
            command=lambda b=btn: self._on_btn_click(b),
        )
        btn.widget.pack(fill="both", expand=True,
                        padx=btn.linewidth, pady=btn.linewidth)
        btn.border.grid(row=btn.row, column=btn.col,
                        rowspan=btn.row_spn, columnspan=btn.col_spn,
                        sticky="nsew", padx=1, pady=1)

    def _create_label(self, lb: TK_Label):
        container = self._resolve_container(lb.parent, lb.page_id)
        lb.border = tk.Frame(container, bg=lb.border_color)
        lb.widget = tk.Label(
            lb.border, text=lb._text,
            bg=lb.bg_color, fg=lb.fg_color,
            font=("Arial", lb.fontsize),
            bd=0, relief="flat", highlightthickness=0,
        )
        lb.widget.pack(fill="both", expand=True,
                       padx=lb.linewidth, pady=lb.linewidth)
        lb.border.grid(row=lb.row, column=lb.col,
                       rowspan=lb.row_spn, columnspan=lb.col_spn,
                       sticky="nsew", padx=1, pady=1)

    def _create_scrolltext(self, st: TK_ScrollText):
        container = self._resolve_container(st.parent, st.page_id)
        st.mount(container)

    def _on_entry_submit(self, entry: TK_Entry):
        ret = entry._on_submit()
        self._write(entry.name)
        return ret
    def _create_entry(self, entry: TK_Entry):
        container = self._resolve_container(entry.parent, entry.page_id)
        entry.border = tk.Frame(container, bg=entry.border_color)
        entry.var = tk.StringVar()
        entry.var.set(entry._text)
        entry.widget = tk.Entry(
            entry.border, textvariable=entry.var,
            bg=entry.bg_color, fg=entry.fg_color,
            font=("Arial", entry.fontsize),
            bd=0, relief="flat", highlightthickness=0,
            insertbackground=entry.fg_color,
        )
        entry.widget.pack(fill="both", expand=True,
                          padx=entry.linewidth, pady=entry.linewidth)
        entry.widget.bind("<Return>", lambda e, x=entry: self._on_entry_submit(x))
        entry.widget.bind("<Escape>", entry._on_cancel)
        entry.var.trace_add("write", entry._on_text_change)
        entry.border.grid(row=entry.row, column=entry.col,
                          rowspan=entry.row_spn, columnspan=entry.col_spn,
                          sticky="nsew", padx=1, pady=1)

    def _on_combo_pick(self, cb: TK_Combo):
        cb._on_select()
        self._write(cb.name)
    def _create_combo(self, cb: TK_Combo):
        container = self._resolve_container(cb.parent, cb.page_id)
        cb.border = tk.Frame(container, bg=cb.border_color)
        cb.var = tk.StringVar(value=cb._value)
        cb.widget = ttk.Combobox(
            cb.border,
            textvariable=cb.var,
            values=cb._options,
            font=("Arial", cb.fontsize),
            state="readonly",        # 唯讀，不接受打字
            justify="left",
        )
        cb.widget.pack(fill="both", expand=True,
                       padx=cb.linewidth, pady=cb.linewidth)
        cb.widget.bind("<<ComboboxSelected>>", lambda e, c=cb: self._on_combo_pick(c))
        cb.widget.bind("<Return>",             lambda e, c=cb: self._on_combo_pick(c))
        cb.widget.bind("<KeyPress>",           cb._on_key)   # 保險攔截
        cb.border.grid(row=cb.row, column=cb.col,
                       rowspan=cb.row_spn, columnspan=cb.col_spn,
                       sticky="nsew", padx=1, pady=1)
        cb._apply_style()
        # 首次建立後，套用 pending（若有）
        if cb._pending_text and cb._options and cb._pending_text in cb._options:
            cb.set(value=cb._pending_text)

    def _create_canvas(self, cv: TK_Canvas):
        container = self._resolve_container(cv.parent, cv.page_id)
        cv.border = tk.Frame(container, bg=cv.border_color)
        cv.widget = tk.Canvas(cv.border, bg=cv.bg_color,
                              highlightthickness=0, bd=0)
        cv.widget.pack(fill="both", expand=True,
                       padx=cv.linewidth, pady=cv.linewidth)
        cv.widget.bind("<Configure>", lambda e, c=cv: c._render())
        cv.widget.bind("<MouseWheel>",  lambda e, c=cv: c._on_wheel(e))
        cv.widget.bind("<Button-4>",    lambda e, c=cv: c._on_wheel(e))
        cv.widget.bind("<Button-5>",    lambda e, c=cv: c._on_wheel(e))
        cv.widget.bind("<ButtonPress-2>",   lambda e, c=cv: c._on_drag_start(e))
        cv.widget.bind("<B2-Motion>",       lambda e, c=cv: c._on_drag_move(e))
        cv.widget.bind("<ButtonRelease-2>", lambda e, c=cv: c._on_drag_end(e))
        cv.widget.bind("<ButtonPress-3>",   lambda e, c=cv: c._on_drag_start(e))
        cv.widget.bind("<B3-Motion>",       lambda e, c=cv: c._on_drag_move(e))
        cv.widget.bind("<ButtonRelease-3>", lambda e, c=cv: c._on_drag_end(e))
        cv.widget.bind("<Motion>",  lambda e, c=cv: c._on_motion(e))
        cv.widget.bind("<Leave>",   lambda e, c=cv: c._on_leave(e))
        cv.border.grid(row=cv.row, column=cv.col,
                       rowspan=cv.row_spn, columnspan=cv.col_spn,
                       sticky="nsew", padx=1, pady=1)

        cv._start_pump()      # ★ 新增：在主執行緒啟動定時器

    def _create_figure(self, fg: TK_Figure):
        # 延遲載入：沒用到 figure 的程式不需負擔 matplotlib 啟動成本
        import matplotlib
        import matplotlib.figure          # 顯式載入 figure 子模組
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        try:
            from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
        except ImportError:
            NavigationToolbar2Tk = None

        container = self._resolve_container(fg.parent, fg.page_id)
        fg.border = tk.Frame(container, bg=fg.border_color)

        # 直接建 Figure，不經過 pyplot，避免與 tkinter 後端衝突
        fg.fig = matplotlib.figure.Figure(
            figsize=fg.figsize,
            dpi=fg.dpi,
            facecolor=fg.bg_color,
        )
        fg.ax = fg.fig.add_subplot(111)
        fg.ax.set_facecolor(fg.bg_color)

        fg.canvas = FigureCanvasTkAgg(fg.fig, master=fg.border)
        fg.widget = fg.canvas.get_tk_widget()
        fg.widget.configure(bg=fg.bg_color, highlightthickness=0, bd=0)
        fg.widget.pack(fill="both", expand=True,
                       padx=fg.linewidth, pady=fg.linewidth)

        if fg.toolbar and NavigationToolbar2Tk is not None:
            fg._toolbar_widget = NavigationToolbar2Tk(
                fg.canvas, fg.border, pack_toolbar=False
            )
            fg._toolbar_widget.update()
            fg._toolbar_widget.pack(side="bottom", fill="x")

        fg.border.grid(row=fg.row, column=fg.col,
                       rowspan=fg.row_spn, columnspan=fg.col_spn,
                       sticky="nsew", padx=1, pady=1)

        # 首次繪製，讓 axes 的底色 / tick 就定位
        fg.canvas.draw_idle()

    def _layout(self):
        groups = {}
        for f in self.frames.values():
            if f.parent is None:
                if f.parent_name == "root":
                    f.widget.pack(fill="both", expand=True)
                continue
            master = f.effective_master(self.root)
            groups.setdefault(master, []).append(f)

        for master, siblings in groups.items():
            aligns = set(s.align for s in siblings)
            if aligns.issubset({"left", "right"}):
                offset = 0.0
                for s in siblings:
                    s.widget.place(relx=offset, rely=0.0,
                                   relwidth=s.w, relheight=s.h)
                    offset += s.w
            elif aligns.issubset({"top", "bottom"}):
                offset = 0.0
                for s in siblings:
                    s.widget.place(relx=0.0, rely=offset,
                                   relwidth=s.w, relheight=s.h)
                    offset += s.h
            else:
                offset = 0.0
                for s in siblings:
                    s.widget.place(relx=0.0, rely=offset,
                                   relwidth=s.w, relheight=s.h)
                    offset += s.h

    def run(self):
        self.root.mainloop()


# ======================================== [Demo] ========================================
if __name__ == "__main__":
    helper = TK_Helper(size="1000x700", loc=(10, 10),
                       title="TK_Helper Demo (Combo / Canvas / Figure / Bar)",
                       verbose=True)
    helper.set_config(topmost=False, resizable=(True, True), bg="white")

    frames_csv = os.path.join(config_path, "ui_frames_layout_config.csv")
    ctrls_csv  = os.path.join(config_path, "ui_ctrls_layout_config.csv")

    helper.load_frames_config(frames_csv)
    helper.load_ctrl_config(ctrls_csv)


    # ------------------------------------------------------------------
    # 2) TK_Canvas Demo：載入圖片 / 或用合成圖
    # ------------------------------------------------------------------
    def go():
        def _run():
            cv = helper.ctrls.get("cav_1")
            cv.set_flags(wheel_zoom=True, drag_pan=True, mouse_bound=True)

            stop = threading.Event()
            helper._stream_stop = stop        # 讓 on_close 能通知停止

            fps  = 0.0
            beta = 0.9
            W, H = 480, 360
            mid  = H // 2
            amp  = 120
            xs   = np.arange(W)
            phase = 0.0

            t_prev = time.time()

            while not stop.is_set():
                t_start = time.time()

                im  = Imgtool((W, H))
                arr = im.img
                arr[:] = 245                       # 白底

                # 中線
                arr[mid, :] = (200, 200, 200)

                # 正弦波（BGR：crimson ≈ (60, 20, 220)）
                y  = mid - amp * np.sin(2 * np.pi * xs / W * 2.0 + phase)
                yi = np.clip(y.astype(int), 0, H - 1)
                y2  = mid - amp * np.sin(9 * np.pi * xs / W * 2.0 + phase)
                yi2 = np.clip(y2.astype(int), 0, H - 1)
                arr[yi, xs] = (60, 20, 220)
                arr[yi2, xs] = (120, 80, 60)

                raw = cv.mouse_raw
                cav = cv.mouse_canvas
                raw_s = f"({raw[0]:.1f}, {raw[1]:.1f})" if raw else "-"
                cav_s = f"({cav[0]}, {cav[1]})" if cav else "-"

                im.auto_text(f"sin wave, fps={fps:.1f}", color="black", fontsize=6)
                im.auto_text(f"raw_xy {raw_s}", color="crimson", fontsize=6)
                im.auto_text(f"cav_xy {cav_s}", color="steelblue", fontsize=6)

                cv.set_async(im, fit=True)         # ★ 執行緒安全入口

                # ---- 量測 ----
                t_now   = time.time()
                render  = t_now - t_start          # 本輪繪製工時
                loop_dt = t_now - t_prev           # 距上一幀開始的真實間隔
                t_prev  = t_now

                if loop_dt > 0:
                    inst_fps = 1.0 / loop_dt
                    fps = fps * beta + inst_fps * (1.0 - beta)

                print(f"render={render*1000:5.1f}ms  "
                      f"loop={loop_dt*1000:5.1f}ms  "
                      f"fps={fps:5.1f}")

                phase += 0.1
                time.sleep(0.03)

        thd = threading.Thread(target=_run, daemon=True)
        thd.start()

        fg = helper.ctrls.get("fig_1")
        xs = np.linspace(0.0, 2.0 * np.pi, 200)
        line, = fg.ax.plot(xs, np.sin(xs), color="crimson")
        fg.ax.set_xlim(0.0, 2.0 * np.pi)
        fg.ax.set_ylim(-1.2, 1.2)
        fg.draw()
        phase = [0.0]

        def _tick():
            phase[0] += 0.15
            line.set_data(xs, np.sin(xs + phase[0]))
            fg.draw()
            try:
                helper.root.after(50, _tick)
            except tk.TclError:
                pass

        _tick()
    helper.root.after(2000, go)

    def on_close():
        if getattr(helper, "_stream_stop", None):
            helper._stream_stop.set()
        helper.root.destroy()

    helper.root.protocol("WM_DELETE_WINDOW", on_close)
    helper.run()