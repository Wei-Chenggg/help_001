import math
import numpy as np
import cv2
from image_helper import Imgtool

class Image_Painter:
    STYLE_KEYS = ("hot_color", "hot_width", "grip_color", "grip_px",
                  "jig_color", "preview_color", "preview_width",
                  "hud_color", "hud_font",
                  "snap", "snap_px", "snap_color")
    def __init__(self):
        self.ctrls = {}
        self.modes = ["3p-circle","2p-circle","tshape","line","rect", "cen-rect"]
        self.need = {"3p-circle": 3, "2p-circle": 2, "tshape": 3, "line": 2, "rect": 2, "cen-rect": 2}
        self.cur_mode = self.modes[0]
        self.pts = []
        self.id = 0
        self.rev = 0
        self.jig_rev = 0
        self.base_rev = 0
        self.base = None
        self._view = ()
        self.layers = {"mark": {"visible": True, "color": "crimson", "width": 2, "grip": True}}
        self.cur_layer = "mark"
        self.hot_color = "lime"
        self.hot_width = 3
        self.grip_color = "silver"
        self.grip_px = 3
        self.jig_color = "steelblue"
        self.preview_color = "gold"
        self.preview_width = 1
        self.hud_color = "black"
        self.hud_font = 3
        self.snap = True
        self.snap_px = 20.0
        self.snap_color = "cyan"
        self.allow_mark = True
        self.hot = ()
        self._bufs = []
        self._bi = 0
        self._last = None
        self._ov = None
        self._mask = None
        self._ov_key = None
        self._colors = {}
        self._ctool = Imgtool(np.zeros((2, 2, 3), np.uint8))
    def mode(self, value="next"):
        if value == "next":
            self.cur_mode = self.modes[(self.modes.index(self.cur_mode) + 1) % len(self.modes)]
        elif value in self.modes:
            self.cur_mode = value
        self.pts = []
        self.jig_rev += 1
        return self.cur_mode
    def mark(self, pts, ):
        if pts is None or not self.allow_mark : return None
        if len(pts) == 2 and not hasattr(pts[0], "__len__") : pts = [pts]
        self.pts.extend([self._snap(p) for p in pts])
        self.jig_rev += 1
        n = self.need[self.cur_mode]
        if len(self.pts) < n : return None
        shot = self.pts[:n]
        self.pts = []
        shape = self._shape(shot)
        if shape is None : return None
        shape["type"] = self.cur_mode
        shape["layer"] = self.cur_layer
        self.ctrls[self._next_id()] = shape
        self._view = tuple(self.ctrls.items())
        self.rev += 1
        return shape
    def _shape(self, shot):
        t = self.cur_mode
        if t == "3p-circle":
            cen, r = self._circle_3p(shot[0], shot[1], shot[2])
            return None if cen is None else {"cen": cen, "r": r}
        if t == "2p-circle":
            cen, r = self._circle_2p(shot[0], shot[1])
            return {"cen": cen, "r": r}
        if t == "tshape":
            p4 = self._foot(shot[0], shot[1], shot[2])
            return None if p4 is None else {"p1": shot[0], "p2": shot[1], "p3": shot[2], "p4": p4}
        if t == "cen-rect":
            return {"cen": shot[0], "p2": shot[1]}
        return {"p1": shot[0], "p2": shot[1]}
    def dist(self, pt, pid=None):
        if pid is None:
            return min([self._shape_dist(s, pt) for _, s in self._view], default=float("inf"))
        s = self.ctrls.get(pid)
        return float("inf") if s is None else self._shape_dist(s, pt)
    def pick(self, pt, tol=8.0):
        out = []
        for pid, s in self._view:
            d = self._shape_dist(s, pt)
            if d <= tol : out.append((pid, d))
        out.sort(key=lambda v: v[1])
        return out
    def key_points(self, pid):
        s = self.ctrls.get(pid)
        return [] if s is None else self._key_pts(s)
    def _key_pts(self, s):
        t = s["type"]
        if t in ("3p-circle", "2p-circle"):
            cx, cy = s["cen"]
            r = s["r"]
            return [(cx, cy), (cx + r, cy), (cx - r, cy), (cx, cy + r), (cx, cy - r)]
        if t == "tshape":
            return [s["p1"], s["p2"], s["p3"], s["p4"]]
        if t == "cen-rect":
            cx, cy = s["cen"]
            return self._rect_pts(2 * cx - s["p2"][0], 2 * cy - s["p2"][1],
                                  s["p2"][0], s["p2"][1])
        if t == "rect":
            return self._rect_pts(s["p1"][0], s["p1"][1], s["p2"][0], s["p2"][1])
        return [s["p1"], s["p2"],
                ((s["p1"][0] + s["p2"][0]) / 2.0, (s["p1"][1] + s["p2"][1]) / 2.0)]
    @staticmethod
    def _rect_pts(x0, y0, x1, y1):
        if x0 > x1 : x0, x1 = x1, x0
        if y0 > y1 : y0, y1 = y1, y0
        mx, my = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        return [(x0, y0), (x1, y0), (x0, y1), (x1, y1),
                (mx, y0), (mx, y1), (x0, my), (x1, my)]
    def _shape_dist(self, s, pt):
        px, py = float(pt[0]), float(pt[1])
        best = float("inf")
        for x, y in self._key_pts(s):
            dx, dy = px - x, py - y
            d = dx * dx + dy * dy
            if d < best : best = d
        return math.sqrt(best)
    @staticmethod
    def _circle_2p(p1, p2):
        cen = ((p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0)
        return cen, math.hypot(p2[0] - p1[0], p2[1] - p1[1]) / 2.0
    @staticmethod
    def _circle_3p(p1, p2, p3):
        ax, ay = p1; bx, by = p2; cx, cy = p3
        d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
        if abs(d) < 1e-9 : return None, None
        a2 = ax * ax + ay * ay; b2 = bx * bx + by * by; c2 = cx * cx + cy * cy
        ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
        uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
        return (ux, uy), math.hypot(ax - ux, ay - uy)
    @staticmethod
    def _foot(p1, p2, p3):
        dx, dy = p2[0] - p1[0], p2[1] - p1[1]
        den = dx * dx + dy * dy
        if den < 1e-9 : return None
        t = ((p3[0] - p1[0]) * dx + (p3[1] - p1[1]) * dy) / den
        return (p1[0] + t * dx, p1[1] + t * dy)
    def _next_id(self,):
        ret = self.id
        self.id += 1
        return ret
    def set(self, img, copy=True):
        arr = img.get() if hasattr(img, "get") else img
        if self.base is None or self.base.shape != arr.shape:
            self._bufs = []
        self.base = np.array(arr, copy=True) if copy else arr
        self.base_rev += 1
        self._last = None
        return self
    def clear(self):
        self.ctrls = {}
        self._view = ()
        self.pts = []
        self.id = 0
        self.rev += 1
        self.jig_rev += 1
        self._last = None
        return self
    def layer(self, name, **style):
        lay = self.layers.get(name)
        if lay is None:
            lay = {"visible": True, "color": "crimson", "width": 2, "grip": True}
            self.layers[name] = lay
        lay.update(style)
        self.rev += 1
        self._last = None
        return lay
    def style(self, color=None, width=None, grip=None, **kw):
        for lay in self.layers.values():
            if color is not None : lay["color"] = color
            if width is not None : lay["width"] = width
            if grip is not None : lay["grip"] = bool(grip)
        for k, v in kw.items():
            if k not in self.STYLE_KEYS:
                raise KeyError(f"Image_Painter.style: 未知的樣式 '{k}'，可用: {self.STYLE_KEYS}")
            setattr(self, k, v)
        self._last = None
        return self
    def _style_key(self):
        return (tuple((n, l.get("color"), l.get("width"), l.get("grip"), l.get("visible"))
                      for n, l in self.layers.items()),
                self.cur_layer,
                tuple(repr(getattr(self, k)) for k in self.STYLE_KEYS))
    def plot(self, img=None, hot=None, mouse=None, hud=None, grip=None):
        self.hot = tuple(hot) if hot else ()
        if img is None:
            if self.base is None : return None
            key = (self.base_rev, self.rev, self.jig_rev,
                   tuple(hot) if hot else (), tuple(mouse) if mouse else None,
                   tuple(tuple(h) for h in hud) if hud else (), grip, self._style_key())
            if self._last is not None and self._last[0] == key : return self._last[1]
            if not self._bufs:
                self._bufs = [np.empty(self.base.shape, np.uint8) for _ in range(3)]
            img = self._bufs[self._bi]
            self._bi = (self._bi + 1) % len(self._bufs)
            np.copyto(img, self.base)
            self._last = (key, img)
        ov, mask = self._overlay(img.shape, grip)
        cv2.copyTo(ov, mask, img)
        self._dynamic(img, hot, mouse, hud)
        return img
    def _bgr(self, c):
        if isinstance(c, (tuple, list)) : return tuple(int(v) for v in c)
        bgr = self._colors.get(c)
        if bgr is None:
            bgr = tuple(int(v) for v in self._ctool._fit_color(c))
            self._colors[c] = bgr
        return bgr
    def _overlay(self, shape, grip=None):
        key = (self.rev, shape, grip, self._style_key())
        if self._ov is not None and self._ov_key == key : return self._ov, self._mask
        ov = np.zeros(shape, np.uint8)
        mask = np.zeros(shape[:2], np.uint8)
        gc = self._bgr(self.grip_color)
        for s in [v for _, v in self._view]:
            lay = self.layers.get(s.get("layer")) or self.layers[self.cur_layer]
            if not lay.get("visible", True) : continue
            g = lay.get("grip", True) if grip is None else grip
            self._draw_shape(ov, mask, s, self._bgr(lay.get("color", "crimson")),
                             lay.get("width", 2), g, gc)
        self._ov = ov
        self._mask = mask
        self._ov_key = key
        return ov, mask
    def _draw_shape(self, ov, mask, s, color, width, grip, grip_color=None):
        gc = grip_color or self._bgr(self.grip_color)
        w = int(width)
        t = s["type"]
        if t in ("3p-circle", "2p-circle"):
            c = (int(s["cen"][0]), int(s["cen"][1]))
            r = int(s["r"])
            cv2.circle(ov, c, r, color, w)
            if mask is not None : cv2.circle(mask, c, r, 255, w)
        elif t == "tshape":
            for a, b in ((s["p1"], s["p2"]), (s["p3"], s["p4"])):
                pa = (int(a[0]), int(a[1]))
                pb = (int(b[0]), int(b[1]))
                cv2.line(ov, pa, pb, color, w)
                if mask is not None : cv2.line(mask, pa, pb, 255, w)
        elif t == "cen-rect":
            p0 = (int(2 * s["cen"][0] - s["p2"][0]), int(2 * s["cen"][1] - s["p2"][1]))
            p1 = (int(s["p2"][0]), int(s["p2"][1]))
            cv2.rectangle(ov, p0, p1, color, w)
            if mask is not None : cv2.rectangle(mask, p0, p1, 255, w)
        elif t == "rect":
            p0 = (int(s["p1"][0]), int(s["p1"][1]))
            p1 = (int(s["p2"][0]), int(s["p2"][1]))
            cv2.rectangle(ov, p0, p1, color, w)
            if mask is not None : cv2.rectangle(mask, p0, p1, 255, w)
        else:
            pa = (int(s["p1"][0]), int(s["p1"][1]))
            pb = (int(s["p2"][0]), int(s["p2"][1]))
            cv2.line(ov, pa, pb, color, w)
            if mask is not None : cv2.line(mask, pa, pb, 255, w)
        if not grip : return
        g = self.grip_px
        for x, y in self._key_pts(s):
            p0 = (int(x - g), int(y - g))
            p1 = (int(x + g), int(y + g))
            cv2.rectangle(ov, p0, p1, gc, -1)
            if mask is not None : cv2.rectangle(mask, p0, p1, 255, -1)
    def _snap(self, pt):
        px, py = float(pt[0]), float(pt[1])
        if not self.snap or not self.hot : return (px, py)
        best = None
        bd = float(self.snap_px)
        for pid in self.hot:
            for x, y in self.key_points(pid):
                d = math.hypot(px - x, py - y)
                if d <= bd:
                    bd = d
                    best = (float(x), float(y))
        return (px, py) if best is None else best
    def _preview(self, pt):
        if len(self.pts) != self.need[self.cur_mode] - 1 : return None
        s = self._shape(self.pts + [self._snap(pt)])
        if s is None : return None
        s["type"] = self.cur_mode
        s["layer"] = self.cur_layer
        return s
    def _dynamic(self, img, hot, mouse, hud):
        if not hot and not self.pts and not hud : return
        for pid in (hot or ()):
            s = self.ctrls.get(pid)
            if s is None : continue
            hc = self._bgr(self.hot_color)
            self._draw_shape(img, None, s, hc, self.hot_width, True, hc)
        if self.pts:
            jc = self._bgr(self.jig_color)
            for x, y in self.pts:
                cv2.circle(img, (int(x), int(y)), 4, jc, 2)
            if mouse:
                pc = self._bgr(self.preview_color)
                sm = self._snap(mouse)
                snapped = (sm[0] != float(mouse[0]) or sm[1] != float(mouse[1]))
                pv = self._preview(mouse)
                if pv is not None:
                    self._draw_shape(img, None, pv, pc, self.preview_width, False)
                else:
                    cv2.line(img, (int(self.pts[-1][0]), int(self.pts[-1][1])),
                             (int(sm[0]), int(sm[1])), jc, 1)
                cv2.circle(img, (int(sm[0]), int(sm[1])), 5,
                           self._bgr(self.snap_color) if snapped else pc, 2 if snapped else 1)
        if hud:
            im = Imgtool(img, copy=False)
            for text, corner in hud:
                im.auto_text(str(text), corner=corner, color=self.hud_color,
                             fontsize=self.hud_font)
    def help(self):
        modes = "  ".join(self.modes)
        lay = self.layers.get(self.cur_layer, {})
        txt = f"""\
Image_Painter ── 快速說明（座標 = 原始影像座標 image px；底圖 3 通道 BGR，painter 不寫底圖）
================================================================
p.set(frame)                        抽換底圖（camera grab / ndarray / Imgtool）
p.mode("rect")                      換形狀（"next" 循環）；模式：{modes}
p.mark((x, y))                      餵點；點數夠了自動 commit 並回傳 shape，否則 None
p.pick((x, y), tol=12)              hover 查詢 → [(pid, dist), ...] 由近到遠
p.plot(hot=[...], mouse=(x, y), hud=[("fps=30", "top-left")])
                                    合成並回傳要顯示的圖（img=None 時用底圖）
p.key_points(pid) / p.dist(pt)      關鍵點清單 / 到最近關鍵點的距離
p.style(color=, width=, hot_color=, ...)   一次改全部外觀
p.layer("roi", color=, width=, grip=)      新增或調整圖層（順序 = 疊圖順序）
p.allow_mark = False                擋住新的 mark（不清既有資料）
p.snap = False                      關閉磁吸（吸到 hot 的關鍵點，snap_px 是上限）
p.clear()                           清空所有 marks 與待畫點
p.help()                            這份說明

snap={self.snap}  allow_mark={self.allow_mark}
圖層 {self.cur_layer}：color={lay.get('color')} width={lay.get('width')} grip={lay.get('grip')}
"""
        print(txt)
        return txt


# ======================================== [測試] ========================================
if __name__ == '__main__':
    import tkinter as tk

    W, H = 900, 600
    APERTURE = 8.0
    painter = Image_Painter()
    painter.help()
    