import numpy as np
from files_helper import *
from image_helper import Imgtool

class Simu_Camera:
    def __init__(self, img_size=(600,400), freq=0.005, speed=0.05):
        self.img_size = img_size
        self.freq = freq
        self.speed = speed
        self.cnts = 0
    def get(self, ):
        w, h = self.img_size
        img = Imgtool(self.img_size)
        phase = self.cnts * self.speed
        fx = self.freq * (1.0 + 0.5 * np.sin(phase))
        fy = self.freq * (1.0 + 0.5 * np.cos(phase))
        wave1 = (0.5 + 0.5 * np.sin(2 * np.pi * fx * np.arange(w) + phase))[None, :, None]
        wave2 = (0.5 + 0.5 * np.sin(2 * np.pi * fy * np.arange(h) - phase))[:, None, None]
        img.load((img.get() * wave1 * wave2).astype(np.uint8))
        self.cnts += 1
        if self.cnts > 1000:
            self.cnts = 0
        return img
