import os
import pickle
import numpy as np
import cv2
from PIL import ImageGrab
def _to_gray(img):
    if img.ndim == 2:
        return np.ascontiguousarray(img.astype(np.uint8))
    ch = img.shape[2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY if ch == 4 else cv2.COLOR_BGR2GRAY)
    return np.ascontiguousarray(gray)
def cvt_cv2_img(img, mode='color'):
    if img is None : return None
    if img.dtype != np.uint8 :
        img = np.clip(img, 0, 255).astype(np.uint8)
    key = str(mode).lower()
    if key in ('gray', 'grey', 'g') : return _to_gray(img)
    if key in ('in', 'keep', 'none') : return np.ascontiguousarray(img)
    if img.ndim == 2 : return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    if img.shape[2] == 4 : return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
    return np.ascontiguousarray(img)
def get_screen_image(box=None, xy=None, size=(30,30)):
    # 一律回傳 BGR uint8；box=(x1, y1, x2, y2) 直接截該區，xy 給點則截該點周圍 size
    if box is not None:
        x_l, x_r = min(box[0], box[2]), max(box[0], box[2])
        y_l, y_r = min(box[1], box[3]), max(box[1], box[3])
        if (x_l - x_r) * (y_l - y_r) == 0: return None
        img_rgb = np.array(ImageGrab.grab((x_l, y_l, x_r, y_r)))
        return cvt_cv2_img(cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR), 'color')
    if xy is None:
        img_rgb = np.array(ImageGrab.grab())
        return cvt_cv2_img(cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR), 'color')
    x, y = int(xy[0]), int(xy[1])
    w, h = int(size[0]), int(size[1])
    half_w = w // 2; half_h = h // 2
    x_l, x_r = x - half_w, x + (w - half_w)
    y_l, y_r = y - half_h, y + (h - half_h)
    x_l = max(x_l, 0); y_l = max(y_l, 0)
    if (x_l - x_r) * (y_l - y_r) == 0: return None
    img_rgb = np.array(ImageGrab.grab((x_l, y_l, x_r, y_r)))
    return cvt_cv2_img(cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR), 'color')

class Match_Vision_Helper:
    def __init__(self, ):
        self.data = {}
        self.last_score = 0.0
    def load(self, fpath="./tm.pkl", method="append"):
        # method="append" 併入既有 self.data；method="new" 先清空再載入
        if os.path.exists(fpath):
            with open(fpath, "rb") as f:
                data = pickle.load(f)
            if str(method).lower() == "new" : self.data = {}
            self.data.update(data)
        return self
    def save(self, fpath="./tm.pkl"):
        parent = os.path.dirname(os.path.abspath(fpath))
        if parent : os.makedirs(parent, exist_ok=True)
        with open(fpath, "wb") as f:
            pickle.dump(self.data, f)
        return self
    def build(self, name, pts, img=None):
        # pts = (pt1, pt2, pt3)：pt1/pt2 為 bbox 左上/右下角，pt3 為目標點（可在 bbox 內外）
        # 只給 2 點時，offset 取 bbox 中心；img 省略則即時截全螢幕
        pts = [(int(p[0]), int(p[1])) for p in pts]
        if len(pts) < 2:
            raise ValueError(f"Match_Vision_Helper.build: pts 至少 2 點, 收到 {len(pts)}")
        img = get_screen_image() if img is None else self._to_bgr(img)
        pt1, pt2 = pts[0], pts[1]
        x_l, x_r = min(pt1[0], pt2[0]), max(pt1[0], pt2[0])
        y_l, y_r = min(pt1[1], pt2[1]), max(pt1[1], pt2[1])
        tm = np.ascontiguousarray(img[y_l:y_r, x_l:x_r])
        if tm.size == 0:
            raise ValueError("Match_Vision_Helper.build: bbox 是空的")
        pt3 = pts[2] if len(pts) > 2 else (x_l + tm.shape[1] // 2, y_l + tm.shape[0] // 2)
        self.data[str(name)] = {"tm": tm, "offset": (pt3[0] - x_l, pt3[1] - y_l)}
        return self.data[str(name)]
    def find(self, name, score=0.7, scene=None):
        # 回傳目標點 (x, y)；找不到回傳 None，比對分數存於 self.last_score
        key = str(name)
        if key not in self.data:
            raise KeyError(f"Match_Vision_Helper: unknown name = {name}")
        self.last_score = 0.0
        tm = self.data[key]["tm"]
        scene = get_screen_image() if scene is None else scene
        gray_s = self._to_gray(scene)
        gray_t = _to_gray(tm)
        if gray_t.shape[0] > gray_s.shape[0] or gray_t.shape[1] > gray_s.shape[1]:
            return None
        res = cv2.matchTemplate(gray_s, gray_t, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if not np.isfinite(max_val):
            return None
        self.last_score = float(max_val)
        if max_val < float(score):
            return None
        off = self.data[key]["offset"]
        return (int(max_loc[0] + off[0]), int(max_loc[1] + off[1]))
    def _to_bgr(self, img):
        if hasattr(img, "img") : img = img.img
        if isinstance(img, (str, os.PathLike)):
            with open(img, "rb") as f:
                buf = np.frombuffer(f.read(), dtype=np.uint8)
            img = cv2.imdecode(buf, cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError("Match_Vision_Helper: 影像無法讀取")
        return cvt_cv2_img(img, 'color')
    def _to_gray(self, img):
        return _to_gray(self._to_bgr(img))
