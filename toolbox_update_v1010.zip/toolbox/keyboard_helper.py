import sys
import time
import threading
from pynput import *
from pynput import mouse, keyboard
import ctypes
import string

MOD_NAMES = {    'ctrl': 'ctrl', 'alt': 'alt', 'shift': 'shift',
                'ctrl_r': 'ctrl_r', 'alt_r': 'alt_r', 'shift_r': 'shift_r', }
JOIN_TABLE = {    'ctrl': [('ctrl_r', 'ctrl_r'), ('ctrl', 'ctrl')],
                'alt': [('alt_r', 'alt_r'), ('alt', 'alt')],
                'shift': [('shift_r', 'shift_r'), ('shift', 'shift')], }
CHAR_BY_VK = {vk: chr(vk) for vk in range(48, 58)}
PRINTABLE_BY_VK = {ord(ch): ch for ch in string.printable}
KEY_TABLE = {    'Key.alt': 'alt', 'Key.alt_l': 'alt', 'Key.alt_r': 'alt_r', 'Key.alt_gr': 'alt_gr',
            'Key.ctrl': 'ctrl', 'Key.ctrl_l': 'ctrl', 'Key.ctrl_r': 'ctrl_r',
            'Key.shift': 'shift', 'Key.shift_l': 'shift', 'Key.shift_r': 'shift_r',
            'Key.cmd': 'cmd', 'Key.cmd_l': 'cmd', 'Key.cmd_r': 'cmd_r',
            'Key.esc': 'esc', 'Key.enter': 'enter', 'Key.tab': 'tab', 'Key.space': 'space',
            'Key.backspace': 'backspace', 'Key.delete': 'delete', 'Key.insert': 'insert',
            'Key.home': 'home', 'Key.end': 'end', 'Key.page_up': 'page_up', 'Key.page_down': 'page_down',
            'Key.up': 'up', 'Key.down': 'down', 'Key.left': 'left', 'Key.right': 'right',
            'Key.caps_lock': 'caps_lock', 'Key.num_lock': 'num_lock', 'Key.scroll_lock': 'scroll_lock',
            'Key.pause': 'pause', 'Key.print_screen': 'print_screen', 'Key.menu': 'menu',
            'Key.media_play_pause': 'media_play_pause', 'Key.media_stop': 'media_stop',
            'Key.media_volume_mute': 'media_volume_mute', 'Key.media_volume_down': 'media_volume_down',
            'Key.media_volume_up': 'media_volume_up', 'Key.media_previous': 'media_previous',
            'Key.media_next': 'media_next', }
KEY_TABLE.update({'Key.f{}'.format(i): 'f{}'.format(i) for i in range(1, 25)})
VK_TABLE = {    96: 'numpad_0', 97: 'numpad_1', 98: 'numpad_2', 99: 'numpad_3', 100: 'numpad_4',
            101: 'numpad_5', 102: 'numpad_6', 103: 'numpad_7', 104: 'numpad_8', 105: 'numpad_9',
            106: 'numpad_multiply', 107: 'numpad_add', 109: 'numpad_subtract', 110: 'numpad_decimal',
            111: 'numpad_divide', 13: 'enter', }
SHIFT_TABLE = {    '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7',
                '*': '8', '(': '9', ')': '0', '_': '-', '+': '=', '{': '[', '}': ']',
                '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/', '~': '`', }
MOUSE_TABLE = {    mouse.Button.left: 'mlc', mouse.Button.middle: 'mmc', mouse.Button.right: 'mrc',
                mouse.Button.x1: 'ms1c', mouse.Button.x2: 'ms2c', }
SCROLL_TABLE = {    'mwu': (0, 1), 'mwd': (0, -1), 'mwl': (-1, 0), 'mwr': (1, 0), }
CLICK_TABLE = {name: btn for btn, name in MOUSE_TABLE.items()}
BUFFER_MAX = 100

class Keyboard_Helper:
    def __init__(self):
        self.keyboard_ctrl = keyboard.Controller()
        self.mouse_ctrl = mouse.Controller()
        self.buffer = []
        self.pressed_mod = set()
        self.buffer_lock = threading.Lock()
        self.moving = False
    def _write(self, cmd):
        with self.buffer_lock :
            self.buffer.append(cmd)
            if len(self.buffer) > BUFFER_MAX : del self.buffer[0:len(self.buffer) - BUFFER_MAX]
    def _read(self, clear=True):
        with self.buffer_lock :
            ret = self.buffer.copy()
            if clear : self.buffer = []
        return ret
    def interact(self, clear=True):
        if clear and self.moving : return []
        return self._read(clear)
    def get_key_name(self, key):
        vk = getattr(key, 'vk', None)
        if vk in VK_TABLE : return VK_TABLE[vk]
        key_str = str(key)
        if key_str in KEY_TABLE : return KEY_TABLE[key_str]
        if key_str.startswith('Key.') : return key_str[4:]
        char = getattr(key, 'char', None)
        base = PRINTABLE_BY_VK.get(vk) if char is None or char in SHIFT_TABLE else None
        if base is None : base = char
        if base is None : base = CHAR_BY_VK.get(vk)
        if base is None : return key_str
        return base.lower()
    def click(self, value="mlc", times=1, delay=0.05):
        if value in SCROLL_TABLE :
            for _ in range(times):
                self.mouse_ctrl.scroll(*SCROLL_TABLE[value])
                time.sleep(0.01)
            time.sleep(delay)
            return
        if value in CLICK_TABLE :
            for _ in range(times):
                self.mouse_ctrl.click(CLICK_TABLE[value])
                time.sleep(0.01)
            time.sleep(delay)
            return
        keys = []
        for name in value.split('+'):
            keys.append(getattr(keyboard.Key, name) if hasattr(keyboard.Key, name) else name)
        for _ in range(times):
            for key in keys: self.keyboard_ctrl.press(key)
            for key in reversed(keys): self.keyboard_ctrl.release(key)
            time.sleep(0.01)
        time.sleep(delay)
    def typing(self, words, delay=0.0):
        self.keyboard_ctrl.type(words)
        time.sleep(delay)
    
    def pos(self,):
        return tuple(self.mouse_ctrl.position)
    def move(self, xy, ct=0.0, delay=0.1):
        tx, ty = tuple(xy)
        self.moving = True
        try:
            sx, sy = self.mouse_ctrl.position
            if 'esc' in self.interact(clear=False) : return False
            if ct > 0.0:
                steps = max(int(ct / 0.01), 1)
                dx = (tx - sx) / steps
                dy = (ty - sy) / steps
                cx, cy = float(sx), float(sy)
                t0 = time.perf_counter()
                for i in range(steps):
                    if 'esc' in self.interact(clear=False) :
                        print('esc stop move - 目前位置 ({}, {})'.format(int(round(cx)), int(round(cy))))
                        return False
                    cx, cy = cx + dx, cy + dy
                    self.mouse_ctrl.position = (int(round(cx)), int(round(cy)))
                    target = t0 + (i + 1) * ct / steps
                    rest = target - time.perf_counter()
                    if rest > 0.0 :
                        if rest > 0.002 : time.sleep(rest - 0.001)
                        while time.perf_counter() < target : pass
            self.mouse_ctrl.position = (tx, ty)
            time.sleep(delay)
            return True
        finally:
            self.moving = False
    def run_main_loop(self,):
        def _keyboard_run():
            with keyboard.Listener(on_press=self.keyboard_on_press, on_release=self.keyboard_on_release) as self.keyboard_listener:
                self.keyboard_listener.join()
        def _mouse_run():
            with mouse.Listener(on_click=self.mouse_on_click, on_move=self.mouse_on_move, on_scroll=self.mouse_on_scroll) as self.mouse_listener:
                self.mouse_listener.join()
        self.threads = {}
        self.threads['keyboard'] = threading.Thread(target=_keyboard_run, args=())
        self.threads['keyboard'].daemon = True
        self.threads['keyboard'].start()
        self.threads['mouse'] = threading.Thread(target=_mouse_run, args=())
        self.threads['mouse'].daemon = True
        self.threads['mouse'].start()
    def keyboard_on_press(self, key):
        key_name = self.get_key_name(key)
        if key_name in MOD_NAMES :
            self.pressed_mod.add(key_name)
            return
        if self.pressed_mod :
            mods = [label for _, items in JOIN_TABLE.items() for name, label in items if name in self.pressed_mod]
            key_name = '+'.join(mods + [key_name])
        self._write(key_name)
    def keyboard_on_release(self, key):
        key_name = self.get_key_name(key)
        if key_name in MOD_NAMES : self.pressed_mod.discard(key_name)
    def mouse_on_click(self, x, y, button, pressed):
        if not pressed : return
        btn_name = MOUSE_TABLE.get(button)
        if btn_name is None : return
        self._write(btn_name)
    def mouse_on_move(self, x, y):
        pass
    def mouse_on_scroll(self, x, y, dx, dy):
        if dy > 0 : self._write('mwu')
        elif dy < 0 : self._write('mwd')
        if dx > 0 : self._write('mwr')
        elif dx < 0 : self._write('mwl')

def _demo_click_hello(kb):
    print('[q] click 連續登打 hello')
    for ch in 'hello':
        kb.click(ch, delay=0.05)
    time.sleep(0.5)
    print('[q] sleep(0.5) -> click alt+a')
    kb.click('ctrl+a')

def _demo_move_corner(kb):
    sx, sy = kb.pos()
    t0 = time.perf_counter()
    done = kb.move((0, 0), ct=4.0)
    ex, ey = kb.pos()
    state = 'done' if done else 'STOPPED by esc'
    print('[w] move (0, 0) ct=4.0 : ({}, {}) -> ({}, {}) in {:.2f}s | {}'.format(sx, sy, ex, ey, time.perf_counter() - t0, state))

if __name__ == '__main__' :
    kb = Keyboard_Helper()
    kb.run_main_loop()
    time.sleep(0.5)
    kb.interact()
    print('=== Keyboard_Helper demo ===')
    print('press q   : click 連續登打 hello -> sleep(0.5) -> click alt+a')
    print('press w   : 緩慢移動到左上角 (0, 0), ct=4.0')
    print('press esc : 中斷移動 (不用 suppress, 不會吃掉按鍵)')
    print('ctrl+c    : quit')
    sys.stdout.flush()
    try:
        while True:
            # print(kb.pos())
            for cmd in kb.interact():
                if cmd == 'q' : _demo_click_hello(kb)
                elif cmd == 'w' : _demo_move_corner(kb)
                else : print('[interact] {}'.format(cmd))
                sys.stdout.flush()
            time.sleep(0.02)
    except KeyboardInterrupt:
        print('bye')
