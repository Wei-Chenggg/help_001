import os, time, uuid
from files_helper import *
from datetime import datetime
from deepseek_harness import DeepSeekHarness
from openai import OpenAI
import threading


def assem_context(context, reply, role="assistant"):
    """把一条回复追加进 context(messages 列表),返回同一个 context。"""
    context.append({"role": role, "content": reply})
    return context


try:
    API_KEY = load_pkl(r"D:\\261001.pkl")["api"]
except:
    API_KEY = ""

class Harness_DS_Agent:
    DEFAULT_MODEL, DEFAULT_PREFIX = "deepseek-v4-flash", "query-001"

    def __init__(self, api_key=API_KEY, api_key_pkl=r"D:\261001.pkl",
                 workspace=None, dsh_home=None, model=None, session_id=None,
                 init_pmpt=None):
        os.environ["DEEPSEEK_API_KEY"] = self.api_key = api_key or load_pkl(api_key_pkl)["api"]
        self.workspace = os.path.abspath(workspace or os.getcwd())
        self.dsh_home = os.path.abspath(dsh_home or os.path.join(self.workspace, ".dsh_home"))
        os.makedirs(self.dsh_home, exist_ok=True)
        self.model = model or self.DEFAULT_MODEL
        self.session_id = session_id or f"{self.DEFAULT_PREFIX}-{int(time.time()*1000)}-{uuid.uuid4().hex[:6]}"

        # init prompt 相關
        self.init_pmpt = init_pmpt
        self._init_sent = False

        self.context = []
        self.is_busy = False
        self.h = DeepSeekHarness(
            provider="deepseek-official", model=self.model,
            cwd=self.workspace, dsh_home=self.dsh_home, profile="sdk",
        ).__enter__()

    def close(self):
        if self.h is not None:
            self.h.__exit__(None, None, None)
            self.h = None

    def send(self, prompt, fpath=None):
        if self.is_busy:
            return
        self.is_busy = True

        # 首輪把 init_pmpt 併進 prompt，之後因為共用 session_id 會被 harness 記住
        total_prompt = prompt
        if self.init_pmpt and not self._init_sent:
            total_prompt = f"{self.init_pmpt}{SPLIT_LINE_PMPT}{prompt}"
            self._init_sent = True

        assem_context(self.context, total_prompt, "user")
        reply = self.h.run(total_prompt, session_id=self.session_id).final_response
        assem_context(self.context, reply, "assistant")

        if fpath:
            os.makedirs(os.path.dirname(os.path.abspath(fpath)), exist_ok=True)
            with open(fpath, "w", encoding="utf-8") as f:
                f.write(reply)

        self.is_busy = False
        return reply


MODEL_MAP = {
    "flash": "deepseek-v4-flash",
    "pro": "deepseek-v4-pro",
}



class Basic_DS_Agent:
    def __init__(self, api_key=API_KEY, model="flash",
                 base_url="https://api.deepseek.com", system_prompt=None):
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model = MODEL_MAP.get(model, "deepseek-chat")
        self.is_busy = False
        self.system_prompt = system_prompt
        self.clear()
    def _add_init_prompt(self, ):
        if self.system_prompt is not None:
            word1 = "-"* 10
            word2 = "後續回答務必遵守以下事項"
            pmpt = word1 + word2 + word1 + "\n" + self.system_prompt + "\n" + word1*3 + "\n"
            self.msg = assem_context(self.msg, pmpt, role="user")
    def send(self, prompt):
        if self.is_busy:
            return
        self.is_busy = True
        self.msg = assem_context(self.msg, prompt, role="user")
        reply = self.client.chat.completions.create(
            model=self.model, messages=self.msg
        ).choices[0].message.content
        self.msg = assem_context(self.msg, reply, role="assistant")
        self.is_busy = False
        return reply
    def clear(self,):
        self.msg = []
        self._add_init_prompt()
    
SPLIT_LINE_PMPT = "\n" + "-" * 20 + "\n"

class Chat_Steps_helper:
    def __init__(self):
        self.roles = {}
        self.buffer = {}

    def build_role(self, name, harness=False, init_pmpt=None):
        # if init_pmpt is not None:
            # init_pmpt = self._file_to_words(init_pmpt)
        if harness : 
            model = Harness_DS_Agent()
        else : 
            model = Basic_DS_Agent(system_prompt = init_pmpt)
        self.roles[name] = {"model": model, "name": name,
                            "init_pmpt": init_pmpt,}

    def _file_to_words(self, fpath):
        if fpath is None:
            return None
        fpath = os.fspath(fpath)
        ext = os.path.splitext(fpath)[1].lower()
        if ext == ".py":
            return load_py(fpath)
        if ext == ".csv":
            return load_csv(fpath)
        if ext == ".pkl":
            return load_pkl(fpath)
        return load_md(fpath)

    def send(self, id, name, prompt, recall_init_pmpt=False):
        self.buffer[id] = {"name": name, "reply": None, "running": True}
        def _run():
            total_prompt = prompt
            if recall_init_pmpt:
                prompt2 = self.roles[name]["init_pmpt"]
                total_prompt = prompt2 + SPLIT_LINE_PMPT + prompt
            reply = self.roles[name]["model"].send(total_prompt)
            self.buffer[id]["reply"] = reply
            self.buffer[id]["running"] = False

        threading.Thread(target=_run).start()

    def _wait_finish(self, timeout=300):
        start_time = time.time()
        while True:
            time.sleep(0.2)
            is_finish = True
            for id in self.buffer:
                if self.buffer[id]["running"]:
                    is_finish = False
            if time.time() - start_time > timeout:
                break
            if is_finish:
                break

    def get(self):
        self._wait_finish()
        result = self.buffer.copy()
        self.buffer = {}
        return result


if __name__ == "__main__":
    # 建立 helper 並 build 兩個角色
    helper = Chat_Steps_helper()
    helper.build_role("alice", harness=False)
    helper.build_role("bob", harness=False, init_pmpt="你是產品經理")

    # 併發送出
    helper.send("q1", "alice", "我們來討論")
    helper.send("q2", "bob", "我們來討論",)

    # 等待並取回
    result = helper.get()

    # 組輸出並寫入 txt（utf-8，避開 cp950）
    lines = ["-" * 50]
    for rid, item in result.items():
        lines.append(f"[{rid}] role={item['name']}  running={item['running']}")
        lines.append(str(item["reply"]))
        lines.append("-" * 50)
    text = "\n".join(lines)

    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chat_output.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(text)