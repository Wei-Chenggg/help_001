﻿# TK Helper 外部控制器接入指導書

> 依據本專案的 `tkinter_helper.py`、`image_helper.py`，以及
> `config/ui_frames_layout_config.csv`、`config/ui_ctrls_layout_config.csv` 整理。
> 適用版本：v1.0

---

## 0. 先講清楚：CSV 是兩份，不是一份

`TK_Helper` 只認兩支 Loader，兩份檔案的欄位**不共用**：

| 檔案 | Loader | 一行代表 | 佈局方式 |
|---|---|---|---|
| `config/ui_frames_layout_config.csv` | `load_frames_config(fpath)` | 一個 `TK_Frame`（容器） | `place()` 相對比例 |
| `config/ui_ctrls_layout_config.csv` | `load_ctrl_config(fpath)` | 一個控件（entry/button/combo/page/canvas/figure） | `grid()` 格線 |

呼叫順序**必須**是先 frames、後 ctrls（`load_ctrl_config` 會用 `self.frames` 找 parent）。任何控制器要接進來，就是往第二份 CSV 加一列，`type` 選定後行為即固定。

---

## 表一：Frames CSV 欄位規格（11 欄，BOM／UTF-8）

| 欄位 | 型別/格式 | 必填 | 預設 | 用途說明（約百字） |
|---|---|---|---|---|
| `name` | 唯一字串 | ✔ | — | 這個 frame 的身分證，其他 frame 的 `parent`、控件的 `parent`、page 按鈕的目標都靠它對接。全檔不可重複，重複時後者會覆蓋前者，父子關係會指向錯誤的物件而整個佈局錯亂。命名建議用 `fm_` 前綴，並且不要與任何控件 `name` 相同，否則頁面按鈕的目標解析會找不到對應 frame。 |
| `parent` | frame 名或 `root` | ✔ | — | 上層容器。填 `root` 表示直接掛在主視窗，會以 `pack(fill=both, expand=True)` 佔滿整個畫面，也是唯一的頂層入口。其他值必須是同一份 CSV 裡已存在的 frame 名；找不到時該 frame 不會有實際 parent，`_layout()` 會忽略它，於是連同它的子孫一起消失在畫面上，而且不會報錯，是最常見的「東西不見了」原因。 |
| `parent_page` | 頁面 id，可空 | ✘ | 空 | 父 frame 內部的「頁容器」編號。父 frame 如果有 `pages` 且被 page 按鈕切成多頁（例如 `1`／`2`），子 frame 要放在哪一頁就填在這裡；留空則放在父 frame 的預設 `content`，也就是永遠可見的那一層。填錯的頁號會即時新建一個空頁容器，畫面看起來正常但切頁時對不上按鈕，需要特別核對。 |
| `align` | `top`/`bottom`/`left`/`right` | ✔ | — | 同一個 master 底下兄弟 frame 的排列方向。全部是 `left`/`right` 時橫向依 `w` 累加偏移；全部是 `top`/`bottom` 時縱向依 `h` 累加。若混用橫與縱，程式會走 fallback 分支改成一律縱向堆疊，等於 `align` 失效，因此同一層請統一方向，否則版面會與預期完全不同且不易察覺原因。 |
| `w` | 0~1 浮點 | ✔ | 1.0 | 相對於 master 的寬度比例，只對 `left`/`right` 排列生效。同層兄弟的 `w` 總和建議等於 1.0，例如 0.2＋0.8；總和超過 1 時右邊會超出可視範圍被裁掉，總和小於 1 時右側留白。若填整數 1 會被當成 1.0 處理，效果是佔滿整個寬度，通常用在只放單一子 frame 的過渡層。 |
| `h` | 0~1 浮點 | ✔ | 1.0 | 相對於 master 的高度比例，只對 `top`/`bottom` 排列生效，規則與 `w` 相同：同層總和應為 1.0。實務上常見「左右分欄」的層一律填 1，由 `w` 決定；「上下分列」的層一律填 1，由 `h` 決定。填 0 會被視為空值而回退成 1.0，不會產生零高度，這點與直覺不同要留意。 |
| `pages` | 頁數整數 | ✔ | — | 保留欄位，程式碼實際未使用，只出現在 `config` 屬性輸出中。真正決定有哪些頁的是「控件 CSV 裡 page 按鈕的 `mode`」以及 `parent_page`，所以這裡填錯不會有任何後果，但為了日後維護可讀性，建議與實際頁數保持一致。若整欄留空，讀取時會是空字串，不影響建立流程。 |
| `title` | 字串，可空 | ✔ | 空 | frame 左上角的標題列文字（`tk.Label`，`anchor="w"`，`padx=4`）。有值時會 `pack(side="top", fill="x")` 佔掉一條高度，剩下的 `content` 才是放子 frame／控件的地方，因此會實質壓縮可用區域。留空則完全不建立標題列，內容區直接從頂端開始，這在講求精準格線對位的場景是必要的。 |
| `grids` | `RxC` 或 `CxR` 字串 | ✔ | — | 這個 frame 提供給「控件」使用的格線，格式為 `行x列`。解析時是把 `x` 前當 rows、後當 cols，再轉成 `(cols, rows)` 給 Tk 用。視覺上 `grids=10x10` 就是 10 行 10 列。只要在某個 frame 裡放控件，就必須讓 `row`、`col` 落在這個範圍內。格式不含 `x` 時會退化成 1x1，此時所有控件都會被擠到同一格，是最常見的覆蓋現象。 |
| `bg_color` | Tk 色名或 `#RRGGBB` | ✔ | white | frame 底色，會同時套用到外框、標題列與 `content` 三層，也是 `_add_grid_placeholders` 補空白格時取的底色。因此它同時決定「看起來的空白色」。顏色名稱不合法時 Tk 會在建立階段丟 `TclError` 讓程式直接中斷，所以請用標準色名或六碼十六進位，避免自創名稱或三碼縮寫。 |
| `linewidth` | 整數 | ✔ | 1 | 外框線寬，以 `highlightthickness` 實作，外框固定用灰色 `highlightbackground="gray"`，所以**不是**用這個欄位控制顏色。填 0 就沒有外框線，適合做無縫拼接的容器；填 2 以上會有明顯的灰色分隔感。這個欄位與控件 CSV 的同名欄位意義不同，控件的那個是「內距」，不要混淆。 |

---

## 表二：Controls CSV 欄位規格（16 欄，BOM／UTF-8）

> ⚠️ **鐵則**：欄位集合是「所有型別的聯集」。載入器對每一列都直接取用 `cfg["..."]`，所以標頭必須**同時**具備下表中所有 ❗ 標記的欄位，即使該型別用不到。少一欄會在建立階段丟 `KeyError`（例如 `bg_color`、`fg_color`、`fontsize`、`linewidth`），`text` 缺欄位元則會變成 `None` 而觸發 `AttributeError`。

| 欄位 | 格式 | 必填 | 預設 | 用途說明（約百字） |
|---|---|---|---|---|
| `name` | 唯一字串 | ✔ | — | 控件在 `helper.ctrls` 字典裡的鍵，外部程式就是用 `helper.ctrls["cav_1"]` 取得物件。全檔必須唯一，重複的列會被後面的覆蓋，前面的物件等於沒建立。建議沿用 `ety_ / btn_ / cbx_ / bpg_ / cav_ / fig_` 前綴，並確認不與任何 frame 的 `name` 撞名。 |
| `parent` | frame 名 | ✔ | — | 要放進哪個 frame。這個值必須精確命中 frames CSV 裡的 `name`，否則 `load_ctrl_config` 會直接 `continue` 把該控件**靜默丟棄**：既不報錯也不顯示，最容易被誤判為「程式沒讀到」。放入後會用父 frame 的 `grids` 做越界檢查，並自動把超出的 `row/col/span` 夾回合法範圍。 |
| `page` | 頁 id，可空 | ✔(可空值) | 空 | 指定放在父 frame 的哪一個頁容器；空字串代表 `content`（不分頁的固定層）。值必須與 page 按鈕 `mode` 中的 `#` 後半段一致，例如按鈕寫 `fm_right#page1`，控件就要填 `page1`。對 `page` 型按鈕本身而言，這個欄位是「它自己被放在哪一頁」，與它要切換的目標是兩件事，切勿填錯。 |
| `type` | `entry`/`button`/`combo`/`page`/`canvas`/`figure` | ✔ | — | 決定這一列要生成哪個類別，是整份 CSV 的分派中樞。字串會先 `lower()` 再比對，所以大小寫不拘。留空或填入未支援的值時，該列被無聲跳過。目前僅支援這六種，新增控制器型別時必須同步修改 `load_ctrl_config` 的 `elif` 鏈，光改 CSV 不會生效。 |
| `mode` | 依型別，見表三 | 各型別不同 | 各型別不同 | 語意隨 `type` 改變的複合欄位：entry 決定 str/int/float 與小數位、button 決定 binary 切換或 single 單脈衝、page 決定「目標 frame#頁」、figure 決定尺寸 `6x4`。combo 與 canvas 完全忽略此欄位，但仍必須存在。填錯格式時多數情況會走預設值而不報錯，是很容易被忽略的設定漏洞。 |
| `row` | 整數 0 起算 | ✔ | 0 | 在父 frame 格線中的列索引，從 0 開始。與 `col` 共同決定控件位置，採 Tk grid 的左上角錨定。超出 `grids` 宣告的行數時會被自動夾到最後一列並印出警告，這會導致多個控件疊在同一格互搶空間，畫面上看起來像「設定沒生效」，因此建議先算好格線再填。 |
| `col` | 整數 0 起算 | ✔ | 0 | 在父 frame 格線中的欄索引，從 0 開始。與 `row` 構成座標，同一格被多個控件佔用時後建立者會疊在上面。因為父 frame 的每一列每一欄都設了 `weight=1, uniform`，格線是等分的，所以 `grids=10x10` 搭配 `col=1, col_spn=5` 就等於佔據中間一半寬度，這種「比例式定位」是本架構的核心思維。 |
| `row_spn` | 整數 ≥1 | ✔ | 1 | 縱向跨列數。設 2 表示高度吃掉兩列，用來讓某個控件比同排其他控件高。與 `col_spn` 一起構成佔用矩形。若 `row + row_spn` 超出行數，會先被夾到合法值再套用，因此不會報錯但實際範圍可能小於預期。空白或 0 會被視為 1，不會產生零高度。 |
| `col_spn` | 整數 ≥1 | ✔ | 1 | 橫向跨欄數，是寬度控制的主要手段。範例 CSV 常用 `col_spn=5` 或 `6` 讓按鈕與輸入框橫向展開到與上方區塊同寬。同樣會被格線範圍夾制。設計版面時應先確定最上層 frame 的 `grids`，再往下推每個控件的 `col+col_spn`，避免靠自動夾制「碰運氣」。 |
| `text` | 字串，可空 | ✔ | 空／控件名 | 語意依型別而異：button/page 當按鈕文字（空值時回退為 `name`）；entry 當初始值並立即依 `mode` 解析（`float_4` 會立刻四捨五入）；combo 是「pending 初始值」，必須等程式呼叫 `options()` 後若剛好命中才會生效；canvas 與 figure 完全忽略。含逗號時務必用雙引號包住整格。 |
| `bg_color` | Tk 色名或 `#RRGGBB` | ✔ | white | 一般狀態底色。entry 是輸入框底、button 是未觸發底色、page 按鈕是未選中底色、combo 是 field 與箭頭底色、canvas 是畫布底色、figure 會同時套到 Figure 與 Axes 的 `facecolor`。這欄缺整欄會 `KeyError`；色名不合法會在建立時丟 `TclError` 中止。 |
| `fg_color` | Tk 色名或 `#RRGGBB` | ✔ | black | 一般狀態前景色：文字與游標（`insertbackground`）。button/page 也套用到 `activeforeground`；combo 同時作為文字與箭頭色。注意 figure 雖然會讀取此欄，但實際渲染由 matplotlib 決定，除非程式另行呼叫 `set_bg()`，否則這個值不會改變圖表上的文字顏色。 |
| `fontsize` | 整數 | ✔ | 10 | 字級，實作是 `font=("Arial", n)`。適用於 button、page、entry、combo。中文字在 Arial 下於 Windows 通常仍能顯示（系統字型替換），但字形不保證美觀，若大量使用中文標題建議改用其他字型。canvas 與 figure 不使用此欄，figure 的座標軸字級要由程式以 matplotlib API 自行指定。 |
| `linewidth` | 整數，可 0 | ✔ | 1 | 這裡是「內距」而非線寬：外框 `tk.Frame(bg=border_color)` 與內部控件之間的 `padx/pady`。填 0 讓控件貼滿外框，填 2 以上就會出現一圈實色邊條，顏色由 `border_color` 決定。因為外框本身也會 `padx=1, pady=1` 對外留 1 像素，所以視覺邊框總寬是 `linewidth + 1`。 |
| `tgr_bg_color` | Tk 色名，可空 | ✔(可空值) | 沿用 `bg_color` | 「觸發／變更」狀態底色。entry 表示內容被改動尚未確認，button 是 `on` 或單脈衝狀態，page 按鈕是選中狀態。combo、canvas、figure 保留相容但實際不使用（combo 每次重繪都會覆蓋為底色）。留空即自動沿用 `bg_color`，等於沒有變色效果，這是最保險的設定方式。 |
| `tgr_fg_color` | Tk 色名，可空 | ✔(可空值) | 沿用 `fg_color` | 觸發狀態的前景色，搭配 `tgr_bg_color` 使用。entry 的 `_apply_style` 會在文字與 `_value` 不同時套用，形成「已修改」的視覺提示；button 在 on 時套用。若只調底色不調前景，容易出現低對比導致文字看不清，建議兩者成對設定，例如 `pink` 配 `black`、`lightskyblue` 配 `black`。 |
| `border_color` | Tk 色名或 `#RRGGBB` | ✔(可空值) | black | 外框 `tk.Frame` 的底色，因為控件本身 `bd=0, highlightthickness=0`，所以整個控件的外緣顏色完全由這一欄決定。以 `linewidth` 為內距，`border_color` 就是那圈邊條的顏色。最外側另有 1 像素 `padx/pady` 的透明間隔，可用來在密集版面中製造視覺分離感。 |

---

## 表三：各型別的 `mode` 選項與生效範圍（這就是「有哪些選項可以選」）

| `type` | `mode` 可填 | 其他選項的生效情形 | 說明（約百字） |
|---|---|---|---|
| `entry` | 空／`str`／`int`／`float`／`float_N` | 用 `text`（初值）、`bg/fg/tgr_bg/tgr_fg`、`fontsize`、`linewidth`、`border_color` | 空與 `str` 同義，值一律存字串。`int` 解析失敗會退回 0。`float_N` 的 N 是小數位數，`N` 省略時不進位。`<Return>` 才提交並依型別重解析，`<Escape>` 還原；非法輸入會閃紅並保留原值。文字與已提交值不同時自動切換 `tgr_*` 顏色。 |
| `button` | `binary`／`single`／其他 | 用 `text`、`bg/fg/tgr_bg/tgr_fg`、`fontsize` | `binary` 每次點擊 `toggle()` 切換 on/off 並套 `tgr_*`。`single` 點擊後設 on，經 `single_pulse_ms`（程式常數 200ms）自動回 off，適合當「送一次命令」。其他值一律當 `binary`。狀態可用 `is_on()`、`read()` 讀，`on()/off()/toggle()` 寫，`on_click` 可外掛回呼。 |
| `combo` | 忽略（建議留空） | 用 `text`（pending 初值）、`bg/fg`、`fontsize`、`linewidth`、`border_color`；`tgr_*` 保留不用 | 建立時 `options` 為空、值為空；必須由程式呼叫 `options([...])` 才有選項，屆時才嘗試套用 `text`，不命中就取第一項。唯一寫入途徑是 `set(value=...)` 或 `set(index=...)`，不合法就不改值，因此「值不在選項內」這個狀態不存在。欄位 `state="readonly"`，不接受打字。 |
| `page` | `目標frame#頁id` | 用 `page`（自身所在頁）、`text`、`bg/fg/tgr_bg/tgr_fg`、`fontsize` | 例如 `fm_right#page2` 表示按下後讓 `fm_right` 切到 `page2`；`page` 前綴會自動去除，寫 `fm_right#2` 亦可。同一目標的多顆按鈕自動成組，`_sync_page_buttons()` 會讓「等於該 frame 當前頁」的那顆亮起，找不到就讓第一顆亮並主動切頁。`mode` 不含 `#` 時目標與頁皆為空，按了不會有反應。 |
| `canvas` | 忽略（建議留空） | 只用 `bg_color`、`linewidth`、`border_color`、`row/col/spn`；`text`、`fg`、`tgr_*`、`fontsize` 無效 | 內建一個 `Imgtool`，支援滑鼠滾輪縮放、中／右鍵拖曳平移、`<Motion>` 座標追蹤與三種滑鼠旗標。影像來源可為 `Imgtool`、路徑字串、BGR ndarray 或 `(w,h[,c])` 建立空圖。跨執行緒更新用 `set_async()`，由 20ms 的 `_pump` 在主執行緒取最新一幀渲染。 |
| `figure` | `寬x高`（吋），如 `6x4` | 只用 `bg_color`（Figure＋Axes 底色）、`linewidth`、`border_color`、`row/col/spn`；`text`、`tgr_*` 無效 | `mode` 不含 `x` 或留空時回退 5x4，`dpi` 固定 100，`figsize × dpi` 就是控件的請求像素尺寸，最終大小再由 grid 與視窗決定，所以請求過大容易被裁切。所有 `Axes` 方法可透過代理呼叫並自動重繪，回傳 `ax` 時改回傳 `self` 以支援鏈式寫法。 |

---

## 表四：完整範例（把上面的選項串成一份可用的 CSV）

以下 frame 段可直接取代 `config/ui_frames_layout_config.csv` 內容；控件段是「不同選項如何設定」的對照範例，`name` 皆唯一。

### A. frames CSV

| name | parent | parent_page | align | w | h | pages | title | grids | bg_color | linewidth |
|---|---|---|---|---|---|---|---|---|---|---|
| fm_main | root | 1 | top | 1 | 1 | 1 | main | 1x1 | white | 1 |
| fm_left | fm_main | 1 | left | 0.25 | 1 | 1 | left | 1x1 | white | 1 |
| fm_right | fm_main | 1 | left | 0.75 | 1 | 2 | right | 6x6 | white | 1 |
| fm_nav | fm_left | 1 | left | 1 | 0.1 | 1 | nav | 1x6 | white | 0 |
| fm_ctl | fm_left | 1 | top | 1 | 0.9 | 1 | ctrl | 10x10 | pink | 1 |

### B. controls CSV

| name | parent | page | type | mode | row | col | row_spn | col_spn | text | bg_color | fg_color | fontsize | linewidth | tgr_bg_color | tgr_fg_color | border_color |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ety_s | fm_ctl |  | entry | str | 0 | 0 | 1 | 4 | hello | lightcyan | black | 9 | 1 | lightcyan | crimson | black |
| ety_f | fm_ctl |  | entry | float_4 | 1 | 0 | 1 | 4 | 3.14159 | lightcyan | black | 9 | 1 | lightcyan | crimson | black |
| ety_i | fm_ctl |  | entry | int | 2 | 0 | 1 | 4 | 7 | lightcyan | black | 9 | 1 | lightcyan | crimson | black |
| btn_b | fm_ctl |  | button | binary | 3 | 0 | 1 | 2 | 鎖定 | white | black | 9 | 1 | pink | black | gray |
| btn_s | fm_ctl |  | button | single | 3 | 2 | 1 | 2 | 觸發 | white | black | 9 | 1 | pink | black | gray |
| cbx_1 | fm_ctl |  | combo |  | 4 | 0 | 1 | 4 | b | white | black | 9 | 1 | white | black | black |
| bpg_1 | fm_nav |  | page | fm_right#page1 | 0 | 0 | 1 | 1 | 主頁 | lightgrey | black | 9 | 1 | lightskyblue | black | black |
| bpg_2 | fm_nav |  | page | fm_right#page2 | 0 | 1 | 1 | 1 | 副頁 | lightgrey | black | 9 | 1 | lightskyblue | black | black |
| fig_1 | fm_right | page1 | figure | 6x4 | 0 | 0 | 3 | 3 |  | white | black | 9 | 1 |  |  | lightskyblue |
| cav_1 | fm_right | page2 | canvas |  | 0 | 0 | 3 | 3 |  | white | black | 9 | 1 |  |  | lightskyblue |
| lbl_cav | fm_right | page2 | button | single | 3 | 0 | 1 | 3 | 取滑鼠座標 | white | black | 9 | 1 | pink | black | gray |

### C. 對應的外部程式骨架

```python
helper = TK_Helper(size="1200x800", loc=(10, 10), title="Demo")
helper.set_config(topmost=False, resizable=(True, True), bg="white")
helper.load_frames_config("./config/ui_frames_layout_config.csv")
helper.load_ctrl_config("./config/ui_ctrls_layout_config.csv")
cv  = helper.ctrls["cav_1"]
fg  = helper.ctrls["fig_1"]
cv.set_flags(wheel_zoom=True, drag_pan=True, mouse_bound=True)
helper.run()