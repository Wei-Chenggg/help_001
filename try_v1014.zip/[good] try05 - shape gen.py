"""
Step 2：可組合的複雜形狀 renderer
"""
import numpy as np
import cv2
import matplotlib
import matplotlib.pyplot as plt
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False

from dataclasses import dataclass, field, replace
from typing import List, Dict, Any, Optional
from scipy.ndimage import gaussian_filter, label
from scipy.interpolate import RegularGridInterpolator


# =========================================================
# 1. Config（新增 theta_gt）
# =========================================================
@dataclass
class Config:
    width: int = 640
    height: int = 480
    theta_gt: float = 0.0      # 度；繞影像中心，CCW 為正（數學慣例）
    dx: float = 0.0
    dy: float = 0.0
    supersample: int = 4
    blur_size: int = 7
    blur_sigma: float = 0.8
    canny_low: int = 50
    canny_high: int = 150


# =========================================================
# 2. Shape：宣告式幾何
# =========================================================
@dataclass
class Shape:
    kind: str                         # circle / ring / rect / triangle / star / polygon
    cx: float
    cy: float
    angle: float = 0.0                # 度
    kwargs: Dict[str, Any] = field(default_factory=dict)

    # ---- 解析式光柵化 ----
    def rasterize(self, xx, yy) -> np.ndarray:
        # 把 (xx, yy) 反向旋轉到形狀的局部座標系
        t = np.deg2rad(-self.angle)
        c, s = np.cos(t), np.sin(t)
        dx = xx - self.cx
        dy = yy - self.cy
        u = c * dx - s * dy
        v = s * dx + c * dy

        k = self.kind
        p = self.kwargs

        if k == "circle":
            return (u * u + v * v) <= p["r"] ** 2

        if k == "ring":
            r2 = u * u + v * v
            return (r2 <= p["r_out"] ** 2) & (r2 >= p["r_in"] ** 2)

        if k == "rect":
            return (np.abs(u) <= p["w"] / 2.0) & (np.abs(v) <= p["h"] / 2.0)

        if k == "triangle":
            # 等邊三角形，內切半徑 = size/2，一個頂點指向 +y
            r_in = p["size"] / 2.0
            normals = [(0.0, 1.0),
                       (np.sqrt(3) / 2.0, -0.5),
                       (-np.sqrt(3) / 2.0, -0.5)]
            m = np.ones_like(u, dtype=bool)
            for nx, ny in normals:
                m &= (nx * u + ny * v) <= r_in
            return m

        if k == "star":
            rr = np.sqrt(u * u + v * v)
            ang = np.arctan2(v, u)
            period = 2.0 * np.pi / p["n_arm"]
            a = np.mod(ang + period / 2.0, period) - period / 2.0
            t_ = np.abs(a) / (period / 2.0)
            r_edge = p["r_out"] * (1.0 - t_) + p["r_in"] * t_
            return rr <= r_edge

        if k == "polygon":
            verts = np.asarray(p["verts"], dtype=float)     # (N, 2)
            N = len(verts)
            crosses = []
            for i in range(N):
                x1, y1 = verts[i]
                x2, y2 = verts[(i + 1) % N]
                cr = (x2 - x1) * (v - y1) - (y2 - y1) * (u - x1)
                crosses.append(cr)
            arr = np.stack(crosses, axis=0)
            return (arr >= 0).all(axis=0) | (arr <= 0).all(axis=0)

        raise ValueError(f"未知的 kind: {k}")


# =========================================================
# 3. 對形狀參數施加剛體變換（不動影像）
# =========================================================
def transform_shape(shape: Shape, theta_deg: float, dx: float, dy: float,
                    cx0: float, cy0: float) -> Shape:
    """繞 (cx0, cy0) 旋轉 theta_deg，再平移 (dx, dy)。"""
    t = np.deg2rad(theta_deg)
    c, s = np.cos(t), np.sin(t)

    rx = shape.cx - cx0
    ry = shape.cy - cy0
    nx = c * rx - s * ry
    ny = s * rx + c * ry

    return Shape(
        kind=shape.kind,
        cx=nx + cx0 + dx,
        cy=ny + cy0 + dy,
        angle=shape.angle + theta_deg,
        kwargs=dict(shape.kwargs),      # 淺拷貝即可（不修改）
    )


# =========================================================
# 4. 新 renderer
# =========================================================
def renderer(cfg: Config, shapes: List[Shape], target: bool = False) -> np.ndarray:
    ss = cfg.supersample
    W_ss = cfg.width * ss
    H_ss = cfg.height * ss

    x = (np.arange(W_ss) + 0.5) / ss - 0.5
    y = (np.arange(H_ss) + 0.5) / ss - 0.5
    xx, yy = np.meshgrid(x, y)

    canvas = np.zeros((H_ss, W_ss), dtype=np.float64)

    cx0 = cfg.width / 2.0
    cy0 = cfg.height / 2.0

    for s in shapes:
        if target:
            s = transform_shape(s, cfg.theta_gt, cfg.dx, cfg.dy, cx0, cy0)
        mask = s.rasterize(xx, yy)
        canvas[mask] = 255.0

    # 超採樣降採樣
    canvas = canvas.reshape(cfg.height, ss, cfg.width, ss).mean(axis=(1, 3))
    canvas = np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)

    # 模糊
    if cfg.blur_sigma > 0:
        canvas = gaussian_filter(
            canvas, sigma=cfg.blur_sigma,
            truncate=cfg.blur_size / 2.0 / cfg.blur_sigma,
        )
    return canvas


# =========================================================
# 5. 形狀庫（可直接玩）
# =========================================================
def shapes_simple_circle():
    """對照組：單圓，跟你原本的一樣。"""
    return [Shape("circle", 320, 240, kwargs=dict(r=150))]


def shapes_complex():
    """複雜組：5 個不同形狀分散在畫面上，用於展示 Go-ICP。"""
    return [
        Shape("star",     180, 150, angle=15,
              kwargs=dict(r_out=65, r_in=28, n_arm=5)),
        Shape("triangle", 460, 140, angle=-20,
              kwargs=dict(size=110)),
        Shape("ring",     180, 340, angle=0,
              kwargs=dict(r_out=58, r_in=36)),
        Shape("rect",     460, 340, angle=30,
              kwargs=dict(w=110, h=60)),
        Shape("circle",   320, 245, angle=0,
              kwargs=dict(r=22)),
    ]


def shapes_lshape():
    """L 形（凸性不同的多邊形，考驗 ICP 的局部極值）。"""
    return [
        Shape("polygon", 320, 240, angle=0,
              kwargs=dict(verts=[
                  (-90, -90), ( 30, -90), ( 30, -20),
                  ( 90, -20), ( 90,  90), (-90,  90),
              ])),
    ]


def shapes_many():
    """壓力測試：一堆小形狀。"""
    out = []
    rng = np.random.default_rng(0)
    for i in range(12):
        kind = ["circle", "rect", "triangle", "star", "ring"][i % 5]
        cx = 100 + (i % 4) * 140 + rng.uniform(-10, 10)
        cy = 100 + (i // 4) * 130 + rng.uniform(-10, 10)
        if kind == "circle":
            kw = dict(r=25)
        elif kind == "rect":
            kw = dict(w=55, h=40)
        elif kind == "triangle":
            kw = dict(size=55)
        elif kind == "star":
            kw = dict(r_out=35, r_in=15, n_arm=5)
        else:
            kw = dict(r_out=30, r_in=20)
        out.append(Shape(kind, cx, cy, angle=rng.uniform(-40, 40), kwargs=kw))
    return out


# =========================================================
# 6. 視覺化對照
# =========================================================
def show_pair(cfg: Config, shapes: List[Shape], title: str = ""):
    img_a = renderer(cfg, shapes, target=False)
    img_b = renderer(cfg, shapes, target=True)

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    axes[0].imshow(img_a, cmap="gray", vmin=0, vmax=255, interpolation="none")
    axes[0].set_title(f"A（原始）  {title}")
    axes[1].imshow(img_b, cmap="gray", vmin=0, vmax=255, interpolation="none")
    axes[1].set_title(
        f"B（θ={cfg.theta_gt:.1f}°, t=({cfg.dx:.1f}, {cfg.dy:.1f})）"
    )
    for ax in axes:
        ax.set_xlabel("x (px)")
        ax.set_ylabel("y (px)")
    plt.tight_layout()
    plt.show()
    return img_a, img_b


# =========================================================
# 7. Main
# =========================================================
if __name__ == "__main__":
    # ---------- 測試 1：單圓（跟原本行為對齊） ----------
    cfg1 = Config(dx=15.0, dy=-8.0, theta_gt=0.0)
    show_pair(cfg1, shapes_simple_circle(), title="單圓")

    # ---------- 測試 2：複雜形狀 + 旋轉 + 平移 ----------
    cfg2 = Config(theta_gt=25.0, dx=12.0, dy=-8.0)
    show_pair(cfg2, shapes_complex(), title="複雜形狀")

    # ---------- 測試 3：L 形（考驗局部極值） ----------
    cfg3 = Config(theta_gt=-30.0, dx=20.0, dy=15.0)
    show_pair(cfg3, shapes_lshape(), title="L 形")

    # ---------- 測試 4：多形狀壓力測試 ----------
    cfg4 = Config(theta_gt=40.0, dx=-10.0, dy=10.0)
    show_pair(cfg4, shapes_many(), title="多形狀")