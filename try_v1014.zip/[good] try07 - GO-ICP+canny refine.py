"""
複雜 shape 渲染 → Canny → 亞像素細化 → GoICP2D 配準 → 誤差統計
============================================================================
評測重點：
    Δθ  = θ_est − θ_gt           (deg)
    Δt  = t_est − t_gt           (px, 含 dx_err, dy_err, |Δt|)

修正：
    - 多起點 ICP（每 30 度一個種子）
    - eps_mse 收緊至 1e-8、eps_theta 收緊至 0.1 度
"""
import time
import heapq
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

import numpy as np
import cv2
import matplotlib
import matplotlib.pyplot as plt
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False

from matplotlib.patches import FancyArrowPatch
from scipy.ndimage import gaussian_filter, label
from scipy.interpolate import RegularGridInterpolator
from scipy.spatial import cKDTree


# =========================================================
# 0. 共用工具
# =========================================================
def rotation_matrix_2d(theta):
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s], [s, c]])


def _as_pts(pts, name="pts"):
    arr = np.asarray(pts, dtype=float)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError(f"{name} 必須是 (n,2)，收到 {arr.shape}")
    if len(arr) == 0:
        raise ValueError(f"{name} 不能是空點集")
    if not np.isfinite(arr).all():
        raise ValueError(f"{name} 包含 NaN 或 Inf")
    return arr


def _trim(sq, trim_k):
    if trim_k is None or int(trim_k) >= len(sq):
        return sq
    k = max(1, int(trim_k))
    return np.partition(sq, k - 1)[:k]


def _wrap_deg(x):
    """把角度差繞回 [-180, 180)。"""
    return (x + 180.0) % 360.0 - 180.0


def compute_errors(theta_est_deg, offset_est, theta_gt_deg, offset_gt):
    """計算估計與真值的誤差。"""
    theta_est_deg = float(theta_est_deg)
    offset_est = np.asarray(offset_est, dtype=float)
    offset_gt = np.asarray(offset_gt, dtype=float)

    diff_theta_deg = _wrap_deg(theta_est_deg - float(theta_gt_deg))
    dxy = offset_est - offset_gt
    return {
        "diff_theta_deg": float(diff_theta_deg),
        "dx_err": float(dxy[0]),
        "dy_err": float(dxy[1]),
        "displacement_err": float(np.linalg.norm(dxy)),
    }


# =========================================================
# 1. Config
# =========================================================
@dataclass
class Config:
    width: int = 1000
    height: int = 1000
    theta_gt: float = 0.0
    dx: float = 0.0
    dy: float = 0.0
    supersample: int = 3
    blur_size: int = 7
    blur_sigma: float = 0.8
    canny_low: int = 50
    canny_high: int = 150


# =========================================================
# 2. Shape
# =========================================================
@dataclass
class Shape:
    kind: str
    cx: float
    cy: float
    angle: float = 0.0
    kwargs: Dict[str, Any] = field(default_factory=dict)

    def rasterize(self, xx, yy):
        t = np.deg2rad(-self.angle)
        c, s = np.cos(t), np.sin(t)
        dx = xx - self.cx
        dy = yy - self.cy
        u = c * dx - s * dy
        v = s * dx + c * dy
        k, p = self.kind, self.kwargs

        if k == "circle":
            return (u * u + v * v) <= p["r"] ** 2
        if k == "ring":
            r2 = u * u + v * v
            return (r2 <= p["r_out"] ** 2) & (r2 >= p["r_in"] ** 2)
        if k == "rect":
            return (np.abs(u) <= p["w"] / 2.0) & (np.abs(v) <= p["h"] / 2.0)
        if k == "triangle":
            r_in = p["size"] / 2.0
            normals = [(0.0, 1.0),
                       (np.sqrt(3) / 2.0, -0.5),
                       (-np.sqrt(3) / 2.0, -0.5)]
            m = np.ones_like(u, dtype=bool)
            for nx, ny in normals:
                m &= (nx * u + ny * v) <= r_in
            return m
        if k == "star":
            rr = np.sqrt(u * u + v * v)
            ang = np.arctan2(v, u)
            period = 2.0 * np.pi / p["n_arm"]
            a = np.mod(ang + period / 2.0, period) - period / 2.0
            t_ = np.abs(a) / (period / 2.0)
            r_edge = p["r_out"] * (1.0 - t_) + p["r_in"] * t_
            return rr <= r_edge
        if k == "polygon":
            verts = np.asarray(p["verts"], dtype=float)
            N = len(verts)
            crosses = []
            for i in range(N):
                x1, y1 = verts[i]
                x2, y2 = verts[(i + 1) % N]
                cr = (x2 - x1) * (v - y1) - (y2 - y1) * (u - x1)
                crosses.append(cr)
            arr = np.stack(crosses, axis=0)
            return (arr >= 0).all(axis=0) | (arr <= 0).all(axis=0)
        raise ValueError(f"未知 kind: {k}")

    def transformed(self, theta_deg, dx, dy, cx0, cy0):
        t = np.deg2rad(theta_deg)
        c, s = np.cos(t), np.sin(t)
        rx, ry = self.cx - cx0, self.cy - cy0
        return Shape(
            kind=self.kind,
            cx=c * rx - s * ry + cx0 + dx,
            cy=s * rx + c * ry + cy0 + dy,
            angle=self.angle + theta_deg,
            kwargs=dict(self.kwargs),
        )

    # ---------- 形狀庫 ----------
    @classmethod
    def simple_circle(cls):
        return [cls("circle", 320, 240, kwargs=dict(r=150))]

    @classmethod
    def complex(cls):
        """原始 640×480 配置。"""
        return [
            cls("star",     180, 150, angle=15,
                kwargs=dict(r_out=65, r_in=28, n_arm=5)),
            cls("triangle", 460, 140, angle=-20,
                kwargs=dict(size=110)),
            cls("ring",     180, 340, angle=0,
                kwargs=dict(r_out=58, r_in=36)),
            cls("rect",     460, 340, angle=30,
                kwargs=dict(w=110, h=60)),
            cls("circle",   320, 245, angle=0,
                kwargs=dict(r=22)),
        ]

    @classmethod
    def lshape(cls):
        return [
            cls("polygon", 320, 240, angle=0,
                kwargs=dict(verts=[
                    (-90, -90), ( 30, -90), ( 30, -20),
                    ( 90, -20), ( 90,  90), (-90,  90),
                ])),
        ]

    # ---------- 自動縮放 ----------
    @classmethod
    def complex_for(cls, width, height, margin=0.1):
        """
        把 640×480 的 complex() 配置自動縮放並置中到給定尺寸。

        參數
        ----
        width, height : 目標圖尺寸
        margin        : 邊界保留比例（0.1 = 每邊留 10%）

        回傳
        ----
        List[Shape]：形狀清單，全部落在目標圖中央 80% 區域內，
                     且形狀本身尺寸按比例縮放。
        """
        base = cls.complex()

        # 原始配置的參考範圍
        cx0, cy0 = 320.0, 240.0
        base_w, base_h = 640.0, 480.0

        # 目標可視範圍（扣除 margin）
        usable_w = width * (1.0 - 2.0 * margin)
        usable_h = height * (1.0 - 2.0 * margin)

        # 等比例縮放係數（取小的，保證不超出）
        s = min(usable_w / base_w, usable_h / base_h)

        # 目標圖中心
        nx0, ny0 = width / 2.0, height / 2.0

        out = []
        for sh in base:
            new_cx = (sh.cx - cx0) * s + nx0
            new_cy = (sh.cy - cy0) * s + ny0

            new_kwargs = {}
            for k, v in sh.kwargs.items():
                if isinstance(v, (int, float)):
                    new_kwargs[k] = float(v) * s
                else:
                    # polygon verts 等序列，逐點縮放
                    try:
                        arr = np.asarray(v, dtype=float)
                        new_kwargs[k] = (arr * s).tolist()
                    except Exception:
                        new_kwargs[k] = v

            out.append(cls(
                kind=sh.kind,
                cx=new_cx,
                cy=new_cy,
                angle=sh.angle,
                kwargs=new_kwargs,
            ))
        return out


# =========================================================
# 3. Renderer
# =========================================================
def renderer(cfg: Config, shapes, target=False):
    ss = cfg.supersample
    W, H = cfg.width, cfg.height
    W_ss, H_ss = W * ss, H * ss

    x = (np.arange(W_ss) + 0.5) / ss - 0.5
    y = (np.arange(H_ss) + 0.5) / ss - 0.5
    xx, yy = np.meshgrid(x, y)

    mask_ss = np.zeros((H_ss, W_ss), dtype=bool)
    cx0, cy0 = W / 2.0, H / 2.0
    for s in shapes:
        if target:
            s = s.transformed(cfg.theta_gt, cfg.dx, cfg.dy, cx0, cy0)
        mask_ss |= s.rasterize(xx, yy)

    canvas = mask_ss.astype(np.float64) * 255.0
    canvas = canvas.reshape(H, ss, W, ss).mean(axis=(1, 3))

    if cfg.blur_sigma > 0:
        truncate = cfg.blur_size / 2.0 / cfg.blur_sigma
        canvas = gaussian_filter(canvas, sigma=cfg.blur_sigma, truncate=truncate)

    return np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)


# =========================================================
# 4. Canny
# =========================================================
def canny_points(img, low, high):
    edges = cv2.Canny(img.astype(np.uint8), low, high)
    ys, xs = np.nonzero(edges)
    return np.column_stack((xs, ys)).astype(np.float64)


# =========================================================
# 5. Subpixel refinement
# =========================================================
def refine_canny_point(img, x, y, kernel=7, upsample=8, eta=0.02,
                       pick="centroid"):
    if kernel % 2 == 0:
        raise ValueError("kernel 必須是奇數")
    half = kernel // 2
    H, W = img.shape
    x0, y0 = int(round(x)), int(round(y))

    if (y0 - half < 0 or x0 - half < 0 or
        y0 + half >= H or x0 + half >= W):
        return None

    patch = img[y0 - half:y0 + half + 1,
                x0 - half:x0 + half + 1].astype(np.float64)
    pmin, pmax = patch.min(), patch.max()
    if pmax - pmin < 1e-8:
        return None
    patch_n = (patch - pmin) / (pmax - pmin)

    ph, pw = patch_n.shape
    gi = RegularGridInterpolator(
        (np.arange(ph), np.arange(pw)), patch_n,
        method="linear", bounds_error=False, fill_value=None,
    )
    ys_u = np.linspace(0, ph - 1, (ph - 1) * upsample + 1)
    xs_u = np.linspace(0, pw - 1, (pw - 1) * upsample + 1)
    YY, XX = np.meshgrid(ys_u, xs_u, indexing="ij")
    patch_up = gi(np.column_stack([YY.ravel(), XX.ravel()])
                  ).reshape(YY.shape)

    mask = np.abs(patch_up - 0.5) < eta
    if not mask.any():
        return None

    iy, ix = np.where(mask)
    gx = xs_u[ix] + (x0 - half)
    gy = ys_u[iy] + (y0 - half)

    if pick == "nearest":
        d2 = (gx - x) ** 2 + (gy - y) ** 2
        k = int(np.argmin(d2))
        return float(gx[k]), float(gy[k])

    if pick == "centroid":
        lbl, n = label(mask)
        best_d2, best_xy = np.inf, None
        for k in range(1, n + 1):
            ii, jj = np.where(lbl == k)
            cx = xs_u[jj].mean() + (x0 - half)
            cy = ys_u[ii].mean() + (y0 - half)
            d2 = (cx - x) ** 2 + (cy - y) ** 2
            if d2 < best_d2:
                best_d2, best_xy = d2, (float(cx), float(cy))
        return best_xy

    raise ValueError("pick 只能是 'nearest' 或 'centroid'")


def refine_canny_points(img, pts, **kw):
    pts = np.asarray(pts, dtype=np.float64)
    out = np.empty_like(pts)
    ok = np.zeros(len(pts), dtype=bool)
    for i, (x, y) in enumerate(pts):
        res = refine_canny_point(img, x, y, **kw)
        if res is None:
            out[i] = (x, y)
        else:
            out[i] = res
            ok[i] = True
    return out, ok


# =========================================================
# 6. GoICP2D
# =========================================================
class GoICP2D:
    """二維 Go-ICP：BnB 全域搜尋 E_nearest 的最小值。"""

    def __init__(self, trans_bound=1.0, eps_mse=1e-8,
                 eps_theta=np.deg2rad(0.1), eps_t=1e-4,
                 max_boxes=50000, icp_iters_per_box=1,
                 icp_only_below_h_theta=0.2, trim_ratio=1.0):
        self.trans_bound = float(trans_bound)
        self.eps_mse = float(eps_mse)
        self.eps_theta = float(eps_theta)
        self.eps_t = float(eps_t)
        self.max_boxes = int(max_boxes)
        self.icp_iters_per_box = int(icp_iters_per_box)
        self.icp_only_below_h_theta = float(icp_only_below_h_theta)
        self.trim_ratio = float(trim_ratio)

        self.is_fitted_ = False
        self.theta_ = self.theta_deg_ = None
        self.R_ = self.offset_ = None
        self.rmse_ = self.info_ = None
        self._c_truth = self._c_now = self._scale = None

    def fit(self, pts_truth, pts_now):
        P = _as_pts(pts_truth, "pts_truth")
        Q = _as_pts(pts_now, "pts_now")

        c_truth = P.mean(axis=0)
        c_now = Q.mean(axis=0)
        s = max(float(np.max(np.linalg.norm(P - c_truth, axis=1))),
                float(np.max(np.linalg.norm(Q - c_now, axis=1))))
        if s <= 0:
            raise ValueError("兩組點集都退化成單點，無法決定尺度")

        res = self._go_icp_2d((P - c_truth) / s, (Q - c_now) / s)

        R = rotation_matrix_2d(res["theta_rad"])
        self.theta_ = float(res["theta_rad"])
        self.theta_deg_ = float(np.rad2deg(self.theta_))
        self.R_ = R
        self.offset_ = c_now - c_truth @ R.T + s * res["t"]
        self.rmse_ = float(res["rmse"] * s)
        self.info_ = dict(res); self.info_["scale"] = s
        self._c_truth = c_truth; self._c_now = c_now; self._scale = s
        self.is_fitted_ = True
        return self

    def fit_transform(self, P, Q):
        return self.fit(P, Q).transform(P)

    def transform(self, pts):
        self._check_fitted()
        return np.asarray(pts, dtype=float) @ self.R_.T + self.offset_

    def inverse_transform(self, pts):
        self._check_fitted()
        return (np.asarray(pts, dtype=float) - self.offset_) @ self.R_

    def score(self, P, Q, trim_k=None):
        self._check_fitted()
        P = _as_pts(P, "pts_truth"); Q = _as_pts(Q, "pts_now")
        tree = cKDTree(Q)
        d, _ = tree.query(self.transform(P), k=1)
        return float(np.sum(_trim(d ** 2, trim_k)))

    def rmse(self, P, Q):
        P = _as_pts(P, "pts_truth")
        return float(np.sqrt(self.score(P, Q) / len(P)))

    def _go_icp_2d(self, P, Q):
        n_pts = len(P)
        K = (n_pts if self.trim_ratio >= 1.0
             else max(1, min(n_pts, int(round(self.trim_ratio * n_pts)))))
        trim_k = K if K < n_pts else None
        norm_p = np.linalg.norm(P, axis=1)
        tree = cKDTree(Q)

        def eval_sse(theta, t):
            Pw = P @ rotation_matrix_2d(theta).T + t
            d, _ = tree.query(Pw, k=1)
            return float(np.sum(_trim(d ** 2, trim_k)))

        def lower_bound(theta, t, h_theta, h_x, h_y):
            Pw = P @ rotation_matrix_2d(theta).T + t
            d, _ = tree.query(Pw, k=1)
            gamma = (2.0 * np.sin(min(np.sqrt(3.0) * h_theta, np.pi) / 2.0)
                     * norm_p + np.sqrt(h_x ** 2 + h_y ** 2))
            return float(np.sum(_trim(np.maximum(d - gamma, 0.0) ** 2, trim_k)))

        def icp_step(theta0, t0, max_iters):
            cur_theta = float(theta0)
            cur_t = np.asarray(t0, dtype=float)
            for _ in range(int(max_iters)):
                Pw = P @ rotation_matrix_2d(cur_theta).T + cur_t
                d, idx = tree.query(Pw, k=1)
                d2 = d ** 2
                sel = (np.argpartition(d2, trim_k - 1)[:trim_k]
                       if (trim_k is not None and trim_k < len(d2))
                       else np.arange(len(d2)))
                p_sel, q_sel = P[sel], Q[idx[sel]]
                pm, qm = p_sel.mean(axis=0), q_sel.mean(axis=0)
                H = (p_sel - pm).T @ (q_sel - qm)
                cur_theta = float(np.arctan2(H[0, 1] - H[1, 0],
                                             H[0, 0] + H[1, 1]))
                cur_t = qm - pm @ rotation_matrix_2d(cur_theta).T
            return cur_theta, cur_t

        # ----- 多起點 ICP：每 30 度一個種子 -----
        best_theta, best_t = 0.0, np.zeros(2)
        best_sse = eval_sse(best_theta, best_t)

        for theta0_deg in range(0, 360, 30):
            theta0 = np.deg2rad(theta0_deg)
            it, itt = icp_step(theta0, np.zeros(2), max_iters=20)
            s = eval_sse(it, itt)
            if s < best_sse:
                best_sse, best_theta, best_t = s, it, itt

        root_box = (0.0, 0.0, 0.0, float(np.pi),
                    float(self.trans_bound), float(self.trans_bound))
        lb_root = lower_bound(0.0, np.zeros(2),
                              root_box[3], root_box[4], root_box[5])
        heap = [(lb_root, 0, root_box)]
        counter = 1
        global_lb = lb_root
        n_boxes = 0
        reason = "max_boxes_reached"
        t_start = time.time()

        while heap and n_boxes < self.max_boxes:
            lb, _, (c_theta, c_x, c_y, h_theta, h_x, h_y) = heapq.heappop(heap)
            global_lb = lb

            if lb >= best_sse:
                continue
            if (best_sse - lb) / K <= self.eps_mse:
                reason = "gap_converged"; break
            if h_theta <= self.eps_theta and max(h_x, h_y) <= self.eps_t:
                reason = "resolution_reached"; break

            n_boxes += 1
            ch_theta, ch_x, ch_y = h_theta / 2.0, h_x / 2.0, h_y / 2.0
            for s_theta in (-ch_theta, ch_theta):
                ct = c_theta + s_theta
                for s_x in (-ch_x, ch_x):
                    cx = c_x + s_x
                    for s_y in (-ch_y, ch_y):
                        cy = c_y + s_y
                        child_lb = lower_bound(ct, np.array([cx, cy]),
                                               ch_theta, ch_x, ch_y)

                        if (self.icp_iters_per_box > 0
                                and h_theta < self.icp_only_below_h_theta):
                            it, itt = icp_step(ct, (cx, cy),
                                               self.icp_iters_per_box)
                            sse = eval_sse(it, itt)
                            if sse < best_sse:
                                best_sse, best_theta, best_t = sse, it, itt
                        else:
                            sse = eval_sse(ct, np.array([cx, cy]))
                            if sse < best_sse:
                                best_sse = sse
                                best_theta = ct
                                best_t = np.array([cx, cy])

                        if child_lb < best_sse:
                            heapq.heappush(
                                heap,
                                (child_lb, counter,
                                 (ct, cx, cy, ch_theta, ch_x, ch_y)))
                            counter += 1

        global_lb = (min(global_lb, heap[0][0]) if heap
                     else min(global_lb, best_sse))
        global_lb = min(global_lb, best_sse)
        if not heap and reason == "max_boxes_reached":
            reason = "search_exhausted"

        return {
            "theta_rad": float((best_theta + np.pi) % (2.0 * np.pi) - np.pi),
            "theta_deg": float(np.rad2deg(
                (best_theta + np.pi) % (2.0 * np.pi) - np.pi)),
            "t": best_t,
            "rmse": float(np.sqrt(max(best_sse, 0.0) / K)),
            "upper_bound_sse": float(best_sse),
            "lower_bound_sse": float(global_lb),
            "gap_mse": float(max(best_sse - global_lb, 0.0) / K),
            "boxes_processed": int(n_boxes),
            "k_points": int(K),
            "termination_reason": reason,
            "elapsed_sec": float(time.time() - t_start),
        }

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("尚未 fit")

    def __repr__(self):
        if not self.is_fitted_:
            return f"GoICP2D(unfitted, eps_theta={np.rad2deg(self.eps_theta):.3f}deg)"
        return (f"GoICP2D(θ={self.theta_deg_:.4f}°, "
                f"t=[{self.offset_[0]:.4f}, {self.offset_[1]:.4f}], "
                f"rmse={self.rmse_:.4e}, boxes={self.info_['boxes_processed']})")


# =========================================================
# 7. 視覺化
# =========================================================
def plot_overlay(img, pts_int, pts_ref, ok, title="",
                 zoom_center=(320.0, 240.0), zoom_half=40.0):
    fig, axes = plt.subplots(1, 2, figsize=(15, 7))
    ax = axes[0]
    ax.imshow(img, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_int[:, 0], pts_int[:, 1], s=5,
               facecolors="none", edgecolors="cyan", linewidths=0.5,
               label=f"Canny n={len(pts_int)}")
    ax.scatter(pts_ref[ok, 0], pts_ref[ok, 1], s=2, c="red",
               label=f"refined n={int(ok.sum())}")
    ax.set_title(f"{title} — Overview")
    ax.legend(loc="upper right", fontsize=9)
    ax.set_xlabel("x (px)"); ax.set_ylabel("y (px)")

    zx, zy = zoom_center
    ax = axes[1]
    ax.imshow(img, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_int[:, 0], pts_int[:, 1], s=45,
               facecolors="none", edgecolors="cyan", linewidths=1.0)
    ax.scatter(pts_ref[ok, 0], pts_ref[ok, 1], s=14, c="red")
    ax.set_xlim(zx - zoom_half, zx + zoom_half)
    ax.set_ylim(zy + zoom_half, zy - zoom_half)
    ax.set_title(f"zoom ({zx:.0f}, {zy:.0f}) ± {zoom_half:.0f}px")
    ax.set_xlabel("x (px)"); ax.set_ylabel("y (px)")
    plt.tight_layout()
    return fig


def plot_registration(img_b, pts_a, pts_b, reg, title="",
                      zoom_center=(320.0, 240.0), zoom_half=120.0):
    Pw = reg.transform(pts_a)
    fig, axes = plt.subplots(1, 2, figsize=(15, 7))

    ax = axes[0]
    ax.imshow(img_b, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_a[:, 0], pts_a[:, 1], s=4, c="cyan", alpha=0.6,
               label=f"A (ref) n={len(pts_a)}")
    ax.scatter(pts_b[:, 0], pts_b[:, 1], s=4, c="orange", alpha=0.6,
               label=f"B (target) n={len(pts_b)}")
    ax.set_title(f"{title} — Before")
    ax.legend(loc="upper right", fontsize=9); ax.set_aspect("equal")

    ax = axes[1]
    ax.imshow(img_b, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_b[:, 0], pts_b[:, 1], s=4, c="orange", alpha=0.5,
               label="B (target)")
    ax.scatter(Pw[:, 0], Pw[:, 1], s=4, c="lime", alpha=0.7,
               label="A aligned")

    tree = cKDTree(pts_b)
    d, idx = tree.query(Pw, k=1)
    thr = max(float(np.percentile(d ** 2, 90)), 1e-12)
    for i in range(len(Pw)):
        if d[i] ** 2 > thr:
            ax.plot([Pw[i, 0], pts_b[idx[i], 0]],
                    [Pw[i, 1], pts_b[idx[i], 1]],
                    c="red", lw=0.5, alpha=0.4)

    zx, zy = zoom_center
    ax.set_xlim(zx - zoom_half, zx + zoom_half)
    ax.set_ylim(zy + zoom_half, zy - zoom_half)
    ax.set_title(f"{title} — After  θ={reg.theta_deg_:.4f}°  "
                 f"t=[{reg.offset_[0]:.3f}, {reg.offset_[1]:.3f}]")
    ax.legend(loc="upper right", fontsize=9); ax.set_aspect("equal")
    plt.tight_layout()
    return fig


# =========================================================
# 7.5 特徵診斷
# =========================================================
def diagnose_features(cfg: Config, shapes, title="", save_path=None):
    """
    只渲染、Canny、refine，把點集畫出來，不做配準。
    用來檢查特徵是否跑出畫面、refine 是否失敗。
    """
    img_a = renderer(cfg, shapes, target=False)
    img_b = renderer(cfg, shapes, target=True)

    pts_a_int = canny_points(img_a, cfg.canny_low, cfg.canny_high)
    pts_b_int = canny_points(img_b, cfg.canny_low, cfg.canny_high)

    refine_kw = dict(kernel=15, upsample=10, eta=0.02, pick="centroid")
    pts_a_ref, ok_a = refine_canny_points(img_a, pts_a_int, **refine_kw)
    pts_b_ref, ok_b = refine_canny_points(img_b, pts_b_int, **refine_kw)

    d_a = np.linalg.norm(pts_a_ref - pts_a_int, axis=1)
    d_b = np.linalg.norm(pts_b_ref - pts_b_int, axis=1)

    border_a = ((pts_a_int[:, 0] < 5) | (pts_a_int[:, 0] > cfg.width - 5) |
                (pts_a_int[:, 1] < 5) | (pts_a_int[:, 1] > cfg.height - 5))
    border_b = ((pts_b_int[:, 0] < 5) | (pts_b_int[:, 0] > cfg.width - 5) |
                (pts_b_int[:, 1] < 5) | (pts_b_int[:, 1] > cfg.height - 5))

    print("=" * 78)
    print(f"特徵診斷：{title}")
    print("=" * 78)
    print(f"  Config: {cfg.width}x{cfg.height}, ss={cfg.supersample}, "
          f"blur={cfg.blur_sigma}, canny=({cfg.canny_low},{cfg.canny_high})")
    print(f"  θ_gt={cfg.theta_gt:+.2f} deg  (dx,dy)=({cfg.dx:+.2f},{cfg.dy:+.2f})")
    print("-" * 78)
    print(f"  {'':6} {'Canny':>8} {'refined':>8} {'failed':>8} | "
          f"{'d_mean':>9} {'d_std':>9} {'d_max':>9} | {'border':>8}")
    print(f"  {'A':6} {len(pts_a_int):>8} {int(ok_a.sum()):>8} "
          f"{int((~ok_a).sum()):>8} | "
          f"{d_a[ok_a].mean():>9.4f} {d_a[ok_a].std():>9.4f} "
          f"{d_a[ok_a].max():>9.4f} | {int(border_a.sum()):>8}")
    print(f"  {'B':6} {len(pts_b_int):>8} {int(ok_b.sum()):>8} "
          f"{int((~ok_b).sum()):>8} | "
          f"{d_b[ok_b].mean():>9.4f} {d_b[ok_b].std():>9.4f} "
          f"{d_b[ok_b].max():>9.4f} | {int(border_b.sum()):>8}")
    print("=" * 78)

    fig, axes = plt.subplots(2, 3, figsize=(18, 10))

    axes[0, 0].imshow(img_a, cmap="gray", vmin=0, vmax=255)
    axes[0, 0].scatter(pts_a_int[:, 0], pts_a_int[:, 1], s=1, c="cyan")
    axes[0, 0].set_title(f"A 影像 + Canny  n={len(pts_a_int)}")
    axes[0, 0].set_aspect("equal")

    axes[0, 1].imshow(img_a, cmap="gray", vmin=0, vmax=255)
    axes[0, 1].scatter(pts_a_int[:, 0], pts_a_int[:, 1], s=2,
                       facecolors="none", edgecolors="cyan")
    axes[0, 1].scatter(pts_a_ref[ok_a, 0], pts_a_ref[ok_a, 1], s=2, c="red")
    axes[0, 1].set_title(f"A: Canny(青) vs refined(紅)")
    axes[0, 1].set_aspect("equal")

    axes[0, 2].hist(d_a[ok_a], bins=40, color="red", alpha=0.7)
    axes[0, 2].set_title(f"A refine 位移  "
                         f"mean={d_a[ok_a].mean():.3f}  "
                         f"max={d_a[ok_a].max():.3f}")
    axes[0, 2].set_xlabel("px")

    axes[1, 0].imshow(img_b, cmap="gray", vmin=0, vmax=255)
    axes[1, 0].scatter(pts_b_int[:, 0], pts_b_int[:, 1], s=1, c="orange")
    axes[1, 0].set_title(f"B 影像 + Canny  n={len(pts_b_int)}  "
                         f"(θ={cfg.theta_gt:+.1f}°)")
    axes[1, 0].set_aspect("equal")

    axes[1, 1].imshow(img_b, cmap="gray", vmin=0, vmax=255)
    axes[1, 1].scatter(pts_b_int[:, 0], pts_b_int[:, 1], s=2,
                       facecolors="none", edgecolors="orange")
    axes[1, 1].scatter(pts_b_ref[ok_b, 0], pts_b_ref[ok_b, 1], s=2, c="lime")
    axes[1, 1].set_title(f"B: Canny(橙) vs refined(綠)")
    axes[1, 1].set_aspect("equal")

    axes[1, 2].hist(d_b[ok_b], bins=40, color="green", alpha=0.7)
    axes[1, 2].set_title(f"B refine 位移  "
                         f"mean={d_b[ok_b].mean():.3f}  "
                         f"max={d_b[ok_b].max():.3f}")
    axes[1, 2].set_xlabel("px")

    plt.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=120)
        plt.close(fig)
    else:
        plt.show()
    return fig


# =========================================================
# 8. Pipeline
# =========================================================
def _truth_offset(cfg):
    """真值 offset：center0 - R(θ_gt) @ center0 + (dx, dy)。"""
    cx0, cy0 = cfg.width / 2.0, cfg.height / 2.0
    R_gt = rotation_matrix_2d(np.deg2rad(cfg.theta_gt))
    return np.array([cx0, cy0]) - R_gt @ np.array([cx0, cy0]) + np.array([cfg.dx, cfg.dy])


def run_case(cfg: Config, shapes: List[Shape], title: str,
             zoom_center=(500.0, 500.0), zoom_half=40.0,
             refine_kw=None, icp_kw=None, show=True, verbose=True):
    if refine_kw is None:
        refine_kw = dict(kernel=15, upsample=10, eta=0.02, pick="centroid")
    if icp_kw is None:
        icp_kw = dict(eps_theta=np.deg2rad(0.1), eps_mse=1e-8,
                      max_boxes=50000, icp_iters_per_box=1,
                      icp_only_below_h_theta=0.2)

    img_a = renderer(cfg, shapes, target=False)
    img_b = renderer(cfg, shapes, target=True)

    pts_a_int = canny_points(img_a, cfg.canny_low, cfg.canny_high)
    pts_b_int = canny_points(img_b, cfg.canny_low, cfg.canny_high)

    pts_a_ref, ok_a = refine_canny_points(img_a, pts_a_int, **refine_kw)
    pts_b_ref, ok_b = refine_canny_points(img_b, pts_b_int, **refine_kw)
    pts_a_use = pts_a_ref[ok_a]
    pts_b_use = pts_b_ref[ok_b]

    reg = GoICP2D(**icp_kw)
    reg.fit(pts_a_use, pts_b_use)

    offset_gt = _truth_offset(cfg)
    err = compute_errors(reg.theta_deg_, reg.offset_, cfg.theta_gt, offset_gt)

    if verbose:
        print(f"=== {title} ===")
        print(f"  A: Canny {len(pts_a_int):4d} → refined {int(ok_a.sum()):4d}"
              f"   B: Canny {len(pts_b_int):4d} → refined {int(ok_b.sum()):4d}")
        print(f"  ── 精度評測 ──────────────────────────────────────")
        print(f"  Δθ        = {err['diff_theta_deg']:+.5f} °")
        print(f"  Δtx       = {err['dx_err']:+.5f} px")
        print(f"  Δty       = {err['dy_err']:+.5f} px")
        print(f"  |Δt|      = {err['displacement_err']:.5f} px")
        print(f"  (θ est = {reg.theta_deg_:+.5f}°  t est = "
              f"[{reg.offset_[0]:+.4f}, {reg.offset_[1]:+.4f}])")
        print(f"  (θ gt  = {cfg.theta_gt:+.5f}°  t gt  = "
              f"[{offset_gt[0]:+.4f}, {offset_gt[1]:+.4f}])")
        print(f"  rmse = {reg.rmse_:.4e} px   "
              f"elapsed = {reg.info_['elapsed_sec']:.2f} s   "
              f"boxes = {reg.info_['boxes_processed']}   "
              f"reason = {reg.info_['termination_reason']}")

    if show:
        plot_overlay(img_a, pts_a_int, pts_a_ref, ok_a,
                     title=f"A (ref)  {title}",
                     zoom_center=zoom_center, zoom_half=zoom_half)
        plot_overlay(img_b, pts_b_int, pts_b_ref, ok_b,
                     title=f"B (target)  {title}", 
                     zoom_center=zoom_center, zoom_half=zoom_half)
        plot_registration(img_b, pts_a_use, pts_b_use, reg,
                          title=title, zoom_center=zoom_center,
                          zoom_half=max(zoom_half, 100.0))
        plt.show()

    return dict(reg=reg, err=err, offset_gt=offset_gt,
                n_a=int(ok_a.sum()), n_b=int(ok_b.sum()))


# =========================================================
# 9. Benchmark
# =========================================================
def benchmark(cases, shapes_fn, refine_kw=None, icp_kw=None,
              title="Benchmark"):
    if refine_kw is None:
        refine_kw = dict(kernel=15, upsample=10, eta=0.02, pick="centroid")
    if icp_kw is None:
        icp_kw = dict(eps_theta=np.deg2rad(0.1), eps_mse=1e-8,
                      max_boxes=50000, icp_iters_per_box=1,
                      icp_only_below_h_theta=0.2)

    print("=" * 72)
    print(f"{title}   ({len(cases)} cases)")
    print("=" * 72)
    print(f"{'idx':>3} | {'θ_gt':>8} {'Δθ':>10} | "
          f"{'dx_gt':>7} {'dy_gt':>7} | "
          f"{'Δtx':>9} {'Δty':>9} {'|Δt|':>9} | "
          f"{'t(s)':>5} {'boxes':>6} reason")
    print("-" * 72)

    results = []
    for i, case in enumerate(cases):
        if len(case) == 3:
            theta, dx, dy = case
            blur_sigma = 0.8
        else:
            theta, dx, dy, blur_sigma = case

        cfg = Config(theta_gt=float(theta), dx=float(dx), dy=float(dy),
                     blur_sigma=float(blur_sigma))
        shapes = shapes_fn()
        res = run_case(cfg, shapes,
                       title=f"case {i}",
                       show=False, verbose=False,
                       refine_kw=refine_kw, icp_kw=icp_kw)

        reg = res["reg"]; err = res["err"]
        results.append({**err,
                        "theta_gt": cfg.theta_gt,
                        "dx_gt": cfg.dx, "dy_gt": cfg.dy,
                        "elapsed": reg.info_["elapsed_sec"],
                        "boxes": reg.info_["boxes_processed"],
                        "reason": reg.info_["termination_reason"]})

        print(f"{i:>3} | {cfg.theta_gt:>+8.3f} {err['diff_theta_deg']:>+10.5f} | "
              f"{cfg.dx:>+7.2f} {cfg.dy:>+7.2f} | "
              f"{err['dx_err']:>+9.5f} {err['dy_err']:>+9.5f} "
              f"{err['displacement_err']:>9.5f} | "
              f"{reg.info_['elapsed_sec']:>5.2f} "
              f"{reg.info_['boxes_processed']:>6d} "
              f"{reg.info_['termination_reason']}")

    dthetas = np.array([r["diff_theta_deg"] for r in results])
    dts = np.array([r["displacement_err"] for r in results])

    print("-" * 72)
    print(f"Δθ    max |.| = {np.max(np.abs(dthetas)):.5f}°   "
          f"mean = {np.mean(dthetas):+.5f}°   "
          f"std = {np.std(dthetas):.5f}°")
    print(f"|Δt|  max     = {np.max(dts):.5f} px   "
          f"mean = {np.mean(dts):.5f} px   "
          f"std = {np.std(dts):.5f} px")
    print("=" * 72)
    return results


# =========================================================
# 10. Main
# =========================================================
if __name__ == "__main__":

    # ============================================================
    # Step 1: 特徵診斷 — 先確認形狀有沒有跑出畫面
    # ============================================================
    # print()
    # print("################  特徵診斷：原始 complex()（為 640x480 設計）  ################")
    # print()

    # for theta in [0.0, 30.0, 90.0, 150.0]:
        # cfg = Config(width=1000, height=1000,
                     # theta_gt=theta, dx=0.0, dy=0.0,
                     # supersample=3, blur_sigma=0.8)
        # diagnose_features(cfg, Shape.complex(),
                          # title=f"θ={theta:+.0f}°  (原始配置)")

    # print()
    # print("################  特徵診斷：complex_for(1000, 1000)  ################")
    # print()

    # for theta in [0.0, 30.0, 90.0, 150.0]:
        # cfg = Config(width=1000, height=1000,
                     # theta_gt=theta, dx=0.0, dy=0.0,
                     # supersample=3, blur_sigma=0.8)
        # diagnose_features(cfg, Shape.complex_for(1000, 1000),
                          # title=f"θ={theta:+.0f}°  (自動縮放)")

    # ============================================================
    # Step 2: Benchmark
    # ============================================================
    print()
    print("################  Benchmark  ################")

    cases = []
    for theta in [-75.0, 30.0]:
        for (dx, dy) in [(12.0, -8.0), (0.0, 0.0), (-20.0, 15.0)]:
            cases.append((theta, dx, dy, 0.8))

    benchmark(cases,
              lambda: Shape.complex_for(1000, 1000),
              title="複雜形狀 (自動縮放) × 6 組變換")

    cases_l = [(t, 10.0, -5.0, 0.8)
               for t in [0.0, 30.0, 60.0, 90.0, 120.0, 150.0]]
    benchmark(cases_l,
              lambda: Shape.complex_for(1000, 1000),
              title="複雜形狀 × 6 組角度")