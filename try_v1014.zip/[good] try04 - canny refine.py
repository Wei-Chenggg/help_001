"""
Step 1：產生仿真圖 → Canny → 通用 patch 亞像素細化 → 疊圖
"""
import numpy as np
import cv2
from dataclasses import dataclass
from scipy.ndimage import gaussian_filter, label
from scipy.interpolate import RegularGridInterpolator
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["Microsoft JhengHei"]   # Windows 正體中文
plt.rcParams["axes.unicode_minus"] = False                 # 負號正常顯示

# =========================================================
# 1. Config（與你檔案一致）
# =========================================================
@dataclass
class Config:
    width: int = 640
    height: int = 480
    center_x: float = 320.0
    center_y: float = 240.0
    radius: float = 150.0
    dx: float = 0.0
    dy: float = 0.0
    supersample: int = 4
    blur_size: int = 7
    blur_sigma: float = 0.8
    canny_low: float = 50
    canny_high: float = 150


# =========================================================
# 2. renderer（復刻你的版本，去掉 Imgtool 依賴）
# =========================================================
def renderer(cfg: Config, target: bool = False) -> np.ndarray:
    ss = cfg.supersample
    x = (np.arange(cfg.width * ss) + 0.5) / ss - 0.5
    y = (np.arange(cfg.height * ss) + 0.5) / ss - 0.5
    xx, yy = np.meshgrid(x, y)

    cx = cfg.center_x + (cfg.dx if target else 0.0)
    cy = cfg.center_y + (cfg.dy if target else 0.0)
    u = (xx - cx) ** 2 + (yy - cy) ** 2

    img = np.where(u <= cfg.radius ** 2, 255.0, 0.0)
    img = img.reshape(cfg.height, ss, cfg.width, ss).mean(axis=(1, 3))
    img = np.clip(np.rint(img), 0, 255).astype(np.uint8).astype(np.float64)

    if cfg.blur_sigma > 0:
        # 等價於 Imgtool.smooth(size=7, sigma=0.8)
        img = gaussian_filter(
            img,
            sigma=cfg.blur_sigma,
            truncate=cfg.blur_size / 2.0 / cfg.blur_sigma,
        )
    return img


# =========================================================
# 3. Canny（與 Imgtool.canny(low, high) 對齊）
# =========================================================
def canny_points(img: np.ndarray, low: int, high: int):
    edges = cv2.Canny(img.astype(np.uint8), low, high)
    ys, xs = np.nonzero(edges)
    pts = np.column_stack((xs, ys)).astype(np.float64)   # (x, y)
    return pts, edges


# =========================================================
# 4. 通用 patch 亞像素細化
#    你指定的流程：
#       patch (kernel×kernel)
#       → 正規化灰階 0~1
#       → 雙線性上採樣
#       → 找 |v - 0.5| < eta
#       → 取離原點最近的質心
# =========================================================
def refine_canny_point(img, x, y,
                       kernel=7, upsample=8, eta=0.02,
                       pick="centroid"):
    if kernel % 2 == 0:
        raise ValueError("kernel 必須是奇數")
    half = kernel // 2
    H, W = img.shape
    x0, y0 = int(round(x)), int(round(y))

    # 邊界保護
    if (y0 - half < 0 or x0 - half < 0 or
        y0 + half >= H or x0 + half >= W):
        return None

    # ---- (a) 取 patch ----
    patch = img[y0 - half:y0 + half + 1,
                x0 - half:x0 + half + 1].astype(np.float64)

    # ---- (b) 正規化灰階 0~1 ----
    pmin, pmax = patch.min(), patch.max()
    if pmax - pmin < 1e-8:
        return None
    patch_n = (patch - pmin) / (pmax - pmin)

    # ---- (c) 雙線性上採樣 ----
    ph, pw = patch_n.shape
    gi = RegularGridInterpolator(
        (np.arange(ph), np.arange(pw)), patch_n,
        method="linear", bounds_error=False, fill_value=None,
    )
    ys_u = np.linspace(0, ph - 1, (ph - 1) * upsample + 1)
    xs_u = np.linspace(0, pw - 1, (pw - 1) * upsample + 1)
    YY, XX = np.meshgrid(ys_u, xs_u, indexing="ij")
    patch_up = gi(np.column_stack([YY.ravel(), XX.ravel()])
                  ).reshape(YY.shape)

    # ---- (d) 找 0.5 等值線 ----
    mask = np.abs(patch_up - 0.5) < eta
    if not mask.any():
        return None

    iy, ix = np.where(mask)
    gx = xs_u[ix] + (x0 - half)
    gy = ys_u[iy] + (y0 - half)

    if pick == "nearest":
        d2 = (gx - x) ** 2 + (gy - y) ** 2
        k = int(np.argmin(d2))
        return float(gx[k]), float(gy[k])

    if pick == "centroid":
        lbl, n = label(mask)
        best_d2, best_xy = np.inf, None
        for k in range(1, n + 1):
            ii, jj = np.where(lbl == k)
            cx = xs_u[jj].mean() + (x0 - half)
            cy = ys_u[ii].mean() + (y0 - half)
            d2 = (cx - x) ** 2 + (cy - y) ** 2
            if d2 < best_d2:
                best_d2, best_xy = d2, (float(cx), float(cy))
        return best_xy

    raise ValueError("pick 只能是 'nearest' 或 'centroid'")


def refine_canny_points(img, pts, **kw):
    pts = np.asarray(pts, dtype=np.float64)
    out = np.empty_like(pts)
    ok = np.zeros(len(pts), dtype=bool)
    for i, (x, y) in enumerate(pts):
        res = refine_canny_point(img, x, y, **kw)
        if res is None:
            out[i] = (x, y)        # 失敗就保留原點
        else:
            out[i] = res
            ok[i] = True
    return out, ok


# =========================================================
# 5. 疊圖
# =========================================================
def plot_result(img, pts_int, pts_ref, ok, cx, cy, radius,
                title, zoom=12.0):
    fig, axes = plt.subplots(1, 2, figsize=(15, 7))

    # ---- 左：全圖概覽 ----
    ax = axes[0]
    ax.imshow(img, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_int[:, 0], pts_int[:, 1],
               s=6, facecolors="none", edgecolors="cyan",
               linewidths=0.6,
               label=f"Canny 整數點  n={len(pts_int)}")
    ax.scatter(pts_ref[ok, 0], pts_ref[ok, 1],
               s=2, c="red",
               label=f"細化後  n={int(ok.sum())}")
    ax.set_title(f"{title}  —  Overview")
    ax.legend(loc="upper right", fontsize=9)
    ax.set_xlabel("x (px)")
    ax.set_ylabel("y (px)")

    # ---- 右：右側邊緣局部放大 ----
    ax = axes[1]
    ax.imshow(img, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_int[:, 0], pts_int[:, 1],
               s=45, facecolors="none", edgecolors="cyan",
               linewidths=1.0)
    ax.scatter(pts_ref[ok, 0], pts_ref[ok, 1],
               s=12, c="red")

    rx, ry = cx + radius, cy
    ax.set_xlim(rx - zoom, rx + zoom)
    ax.set_ylim(ry + zoom, ry - zoom)
    ax.set_title(f"{title}  —  右側邊緣放大 (±{zoom:.0f}px)")
    ax.set_xlabel("x (px)")
    ax.set_ylabel("y (px)")

    plt.tight_layout()
    return fig


# =========================================================
# 6. Main
# =========================================================
def main():
    cfg = Config(dx=10.0, dy=-5.0)

    for tag, target in [("原始 (target=False)", False),
                        ("平移後 (target=True)", True)]:
        img = renderer(cfg, target=target)
        cx = cfg.center_x + (cfg.dx if target else 0.0)
        cy = cfg.center_y + (cfg.dy if target else 0.0)

        # 1) Canny 整數點
        pts_int, _ = canny_points(img, cfg.canny_low, cfg.canny_high)

        # 2) 通用 patch 亞像素細化
        pts_ref, ok = refine_canny_points(
            img, pts_int,
            kernel=7, upsample=8, eta=0.02, pick="centroid",
        )

        # 3) 統計：半徑方向的散佈
        r_int = np.hypot(pts_int[:, 0] - cx, pts_int[:, 1] - cy)
        r_ref = np.hypot(pts_ref[ok, 0] - cx, pts_ref[ok, 1] - cy)

        print(f"=== {tag} ===")
        print(f"  Canny 點數         : {len(pts_int)}")
        print(f"  細化成功           : {int(ok.sum())}")
        print(f"  半徑 std (整數)    : {r_int.std():.4f} px")
        print(f"  半徑 std (細化後)  : {r_ref.std():.4f} px")
        print(f"  半徑 std 縮小倍率  : {r_int.std() / max(r_ref.std(), 1e-9):.2f}x")
        print()

        # 4) 疊圖
        plot_result(img, pts_int, pts_ref, ok, cx, cy, cfg.radius,
                    title=tag)

    plt.show()


if __name__ == "__main__":
    main()