"""
GoICP2D 精度分層診斷
============================================================================
隔離「GoICP2D 本身」與「Canny/refine 引入」的誤差。

Level 0 : P 數學生成   ->  Q 對 P 數學旋轉        (純 GoICP2D)
Level 1 : P 來自 Canny ->  Q 對 P 數學旋轉        (+A 圖 Canny/refine)
Level 2 : P 來自 A Canny  ->  Q 來自 B Canny      (+B 圖獨立 Canny/refine)
"""
import time
import heapq
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

import numpy as np
import cv2
import matplotlib
import matplotlib.pyplot as plt
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False

from scipy.ndimage import gaussian_filter, label
from scipy.interpolate import RegularGridInterpolator
from scipy.spatial import cKDTree


# =========================================================
# 0. 共用工具
# =========================================================
def rotation_matrix_2d(theta):
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s], [s, c]])


def _as_pts(pts, name="pts"):
    arr = np.asarray(pts, dtype=float)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError(f"{name} 必須是 (n,2)，收到 {arr.shape}")
    if len(arr) == 0:
        raise ValueError(f"{name} 不能是空點集")
    if not np.isfinite(arr).all():
        raise ValueError(f"{name} 包含 NaN 或 Inf")
    return arr


def _trim(sq, trim_k):
    if trim_k is None or int(trim_k) >= len(sq):
        return sq
    k = max(1, int(trim_k))
    return np.partition(sq, k - 1)[:k]


def _wrap_deg(x):
    return (x + 180.0) % 360.0 - 180.0


def compute_errors(theta_est_deg, offset_est, theta_gt_deg, offset_gt):
    theta_est_deg = float(theta_est_deg)
    offset_est = np.asarray(offset_est, dtype=float)
    offset_gt = np.asarray(offset_gt, dtype=float)
    return {
        "diff_theta_deg": float(_wrap_deg(theta_est_deg - float(theta_gt_deg))),
        "dx_err": float(offset_est[0] - offset_gt[0]),
        "dy_err": float(offset_est[1] - offset_gt[1]),
        "displacement_err": float(np.linalg.norm(offset_est - offset_gt)),
    }


# =========================================================
# 1. Config
# =========================================================
@dataclass
class Config:
    width: int = 640
    height: int = 480
    theta_gt: float = 0.0
    dx: float = 0.0
    dy: float = 0.0
    supersample: int = 4
    blur_size: int = 7
    blur_sigma: float = 0.8
    canny_low: int = 50
    canny_high: int = 150


# =========================================================
# 2. Shape
# =========================================================
@dataclass
class Shape:
    kind: str
    cx: float
    cy: float
    angle: float = 0.0
    kwargs: Dict[str, Any] = field(default_factory=dict)

    def rasterize(self, xx, yy):
        t = np.deg2rad(-self.angle)
        c, s = np.cos(t), np.sin(t)
        dx = xx - self.cx
        dy = yy - self.cy
        u = c * dx - s * dy
        v = s * dx + c * dy
        k, p = self.kind, self.kwargs

        if k == "circle":
            return (u * u + v * v) <= p["r"] ** 2
        if k == "ring":
            r2 = u * u + v * v
            return (r2 <= p["r_out"] ** 2) & (r2 >= p["r_in"] ** 2)
        if k == "rect":
            return (np.abs(u) <= p["w"] / 2.0) & (np.abs(v) <= p["h"] / 2.0)
        if k == "triangle":
            r_in = p["size"] / 2.0
            normals = [(0.0, 1.0),
                       (np.sqrt(3) / 2.0, -0.5),
                       (-np.sqrt(3) / 2.0, -0.5)]
            m = np.ones_like(u, dtype=bool)
            for nx, ny in normals:
                m &= (nx * u + ny * v) <= r_in
            return m
        if k == "star":
            rr = np.sqrt(u * u + v * v)
            ang = np.arctan2(v, u)
            period = 2.0 * np.pi / p["n_arm"]
            a = np.mod(ang + period / 2.0, period) - period / 2.0
            t_ = np.abs(a) / (period / 2.0)
            r_edge = p["r_out"] * (1.0 - t_) + p["r_in"] * t_
            return rr <= r_edge
        if k == "polygon":
            verts = np.asarray(p["verts"], dtype=float)
            N = len(verts)
            crosses = []
            for i in range(N):
                x1, y1 = verts[i]
                x2, y2 = verts[(i + 1) % N]
                cr = (x2 - x1) * (v - y1) - (y2 - y1) * (u - x1)
                crosses.append(cr)
            arr = np.stack(crosses, axis=0)
            return (arr >= 0).all(axis=0) | (arr <= 0).all(axis=0)
        raise ValueError(f"未知 kind: {k}")

    def transformed(self, theta_deg, dx, dy, cx0, cy0):
        t = np.deg2rad(theta_deg)
        c, s = np.cos(t), np.sin(t)
        rx, ry = self.cx - cx0, self.cy - cy0
        return Shape(
            kind=self.kind,
            cx=c * rx - s * ry + cx0 + dx,
            cy=s * rx + c * ry + cy0 + dy,
            angle=self.angle + theta_deg,
            kwargs=dict(self.kwargs),
        )

    @classmethod
    def complex(cls):
        return [
            cls("star",     180, 150, angle=15,
                kwargs=dict(r_out=65, r_in=28, n_arm=5)),
            cls("triangle", 460, 140, angle=-20,
                kwargs=dict(size=110)),
            cls("ring",     180, 340, angle=0,
                kwargs=dict(r_out=58, r_in=36)),
            cls("rect",     460, 340, angle=30,
                kwargs=dict(w=110, h=60)),
            cls("circle",   320, 245, angle=0,
                kwargs=dict(r=22)),
        ]

    @classmethod
    def lshape(cls):
        return [
            cls("polygon", 320, 240, angle=0,
                kwargs=dict(verts=[
                    (-90, -90), ( 30, -90), ( 30, -20),
                    ( 90, -20), ( 90,  90), (-90,  90),
                ])),
        ]


# =========================================================
# 3. Renderer
# =========================================================
def renderer(cfg: Config, shapes, target=False):
    ss = cfg.supersample
    W, H = cfg.width, cfg.height
    W_ss, H_ss = W * ss, H * ss

    x = (np.arange(W_ss) + 0.5) / ss - 0.5
    y = (np.arange(H_ss) + 0.5) / ss - 0.5
    xx, yy = np.meshgrid(x, y)

    mask_ss = np.zeros((H_ss, W_ss), dtype=bool)
    cx0, cy0 = W / 2.0, H / 2.0
    for s in shapes:
        if target:
            s = s.transformed(cfg.theta_gt, cfg.dx, cfg.dy, cx0, cy0)
        mask_ss |= s.rasterize(xx, yy)

    canvas = mask_ss.astype(np.float64) * 255.0
    canvas = canvas.reshape(H, ss, W, ss).mean(axis=(1, 3))

    if cfg.blur_sigma > 0:
        truncate = cfg.blur_size / 2.0 / cfg.blur_sigma
        canvas = gaussian_filter(canvas, sigma=cfg.blur_sigma, truncate=truncate)

    return np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)


# =========================================================
# 4. Canny
# =========================================================
def canny_points(img, low, high):
    edges = cv2.Canny(img.astype(np.uint8), low, high)
    ys, xs = np.nonzero(edges)
    return np.column_stack((xs, ys)).astype(np.float64)


# =========================================================
# 5. Subpixel refinement
# =========================================================
def refine_canny_point(img, x, y, kernel=7, upsample=8, eta=0.02,
                       pick="centroid"):
    if kernel % 2 == 0:
        raise ValueError("kernel 必須是奇數")
    half = kernel // 2
    H, W = img.shape
    x0, y0 = int(round(x)), int(round(y))

    if (y0 - half < 0 or x0 - half < 0 or
        y0 + half >= H or x0 + half >= W):
        return None

    patch = img[y0 - half:y0 + half + 1,
                x0 - half:x0 + half + 1].astype(np.float64)
    pmin, pmax = patch.min(), patch.max()
    if pmax - pmin < 1e-8:
        return None
    patch_n = (patch - pmin) / (pmax - pmin)

    ph, pw = patch_n.shape
    gi = RegularGridInterpolator(
        (np.arange(ph), np.arange(pw)), patch_n,
        method="linear", bounds_error=False, fill_value=None,
    )
    ys_u = np.linspace(0, ph - 1, (ph - 1) * upsample + 1)
    xs_u = np.linspace(0, pw - 1, (pw - 1) * upsample + 1)
    YY, XX = np.meshgrid(ys_u, xs_u, indexing="ij")
    patch_up = gi(np.column_stack([YY.ravel(), XX.ravel()])
                  ).reshape(YY.shape)

    mask = np.abs(patch_up - 0.5) < eta
    if not mask.any():
        return None

    iy, ix = np.where(mask)
    gx = xs_u[ix] + (x0 - half)
    gy = ys_u[iy] + (y0 - half)

    if pick == "nearest":
        d2 = (gx - x) ** 2 + (gy - y) ** 2
        k = int(np.argmin(d2))
        return float(gx[k]), float(gy[k])

    if pick == "centroid":
        lbl, n = label(mask)
        best_d2, best_xy = np.inf, None
        for k in range(1, n + 1):
            ii, jj = np.where(lbl == k)
            cx = xs_u[jj].mean() + (x0 - half)
            cy = ys_u[ii].mean() + (y0 - half)
            d2 = (cx - x) ** 2 + (cy - y) ** 2
            if d2 < best_d2:
                best_d2, best_xy = d2, (float(cx), float(cy))
        return best_xy

    raise ValueError("pick 只能是 'nearest' 或 'centroid'")


def refine_canny_points(img, pts, **kw):
    pts = np.asarray(pts, dtype=np.float64)
    out = np.empty_like(pts)
    ok = np.zeros(len(pts), dtype=bool)
    for i, (x, y) in enumerate(pts):
        res = refine_canny_point(img, x, y, **kw)
        if res is None:
            out[i] = (x, y)
        else:
            out[i] = res
            ok[i] = True
    return out, ok


# =========================================================
# 6. GoICP2D
# =========================================================
class GoICP2D:
    def __init__(self, trans_bound=1.0, eps_mse=1e-6,
                 eps_theta=np.deg2rad(0.1), eps_t=1e-4,
                 max_boxes=20000, icp_iters_per_box=1,
                 icp_only_below_h_theta=0.2, trim_ratio=1.0):
        self.trans_bound = float(trans_bound)
        self.eps_mse = float(eps_mse)
        self.eps_theta = float(eps_theta)
        self.eps_t = float(eps_t)
        self.max_boxes = int(max_boxes)
        self.icp_iters_per_box = int(icp_iters_per_box)
        self.icp_only_below_h_theta = float(icp_only_below_h_theta)
        self.trim_ratio = float(trim_ratio)

        self.is_fitted_ = False
        self.theta_ = self.theta_deg_ = None
        self.R_ = self.offset_ = None
        self.rmse_ = self.info_ = None
        self._c_truth = self._c_now = self._scale = None

    def fit(self, pts_truth, pts_now):
        P = _as_pts(pts_truth, "pts_truth")
        Q = _as_pts(pts_now, "pts_now")

        c_truth = P.mean(axis=0)
        c_now = Q.mean(axis=0)
        s = max(float(np.max(np.linalg.norm(P - c_truth, axis=1))),
                float(np.max(np.linalg.norm(Q - c_now, axis=1))))
        if s <= 0:
            raise ValueError("兩組點集都退化成單點")

        res = self._go_icp_2d((P - c_truth) / s, (Q - c_now) / s)

        R = rotation_matrix_2d(res["theta_rad"])
        self.theta_ = float(res["theta_rad"])
        self.theta_deg_ = float(np.rad2deg(self.theta_))
        self.R_ = R
        self.offset_ = c_now - c_truth @ R.T + s * res["t"]
        self.rmse_ = float(res["rmse"] * s)
        self.info_ = dict(res); self.info_["scale"] = s
        self._c_truth = c_truth; self._c_now = c_now; self._scale = s
        self.is_fitted_ = True
        return self

    def transform(self, pts):
        self._check_fitted()
        return np.asarray(pts, dtype=float) @ self.R_.T + self.offset_

    def inverse_transform(self, pts):
        self._check_fitted()
        return (np.asarray(pts, dtype=float) - self.offset_) @ self.R_

    def _go_icp_2d(self, P, Q):
        n_pts = len(P)
        K = (n_pts if self.trim_ratio >= 1.0
             else max(1, min(n_pts, int(round(self.trim_ratio * n_pts)))))
        trim_k = K if K < n_pts else None
        norm_p = np.linalg.norm(P, axis=1)
        tree = cKDTree(Q)

        def eval_sse(theta, t):
            Pw = P @ rotation_matrix_2d(theta).T + t
            d, _ = tree.query(Pw, k=1)
            return float(np.sum(_trim(d ** 2, trim_k)))

        def lower_bound(theta, t, h_theta, h_x, h_y):
            Pw = P @ rotation_matrix_2d(theta).T + t
            d, _ = tree.query(Pw, k=1)
            gamma = (2.0 * np.sin(min(np.sqrt(3.0) * h_theta, np.pi) / 2.0)
                     * norm_p + np.sqrt(h_x ** 2 + h_y ** 2))
            return float(np.sum(_trim(np.maximum(d - gamma, 0.0) ** 2, trim_k)))

        def icp_step(theta0, t0, max_iters):
            cur_theta = float(theta0)
            cur_t = np.asarray(t0, dtype=float)
            for _ in range(int(max_iters)):
                Pw = P @ rotation_matrix_2d(cur_theta).T + cur_t
                d, idx = tree.query(Pw, k=1)
                d2 = d ** 2
                sel = (np.argpartition(d2, trim_k - 1)[:trim_k]
                       if (trim_k is not None and trim_k < len(d2))
                       else np.arange(len(d2)))
                p_sel, q_sel = P[sel], Q[idx[sel]]
                pm, qm = p_sel.mean(axis=0), q_sel.mean(axis=0)
                H = (p_sel - pm).T @ (q_sel - qm)
                cur_theta = float(np.arctan2(H[0, 1] - H[1, 0],
                                             H[0, 0] + H[1, 1]))
                cur_t = qm - pm @ rotation_matrix_2d(cur_theta).T
            return cur_theta, cur_t

        best_theta, best_t = 0.0, np.zeros(2)
        best_sse = eval_sse(best_theta, best_t)
        it, itt = icp_step(0.0, best_t, max_iters=20)
        s = eval_sse(it, itt)
        if s < best_sse:
            best_sse, best_theta, best_t = s, it, itt

        root_box = (0.0, 0.0, 0.0, float(np.pi),
                    float(self.trans_bound), float(self.trans_bound))
        lb_root = lower_bound(0.0, np.zeros(2),
                              root_box[3], root_box[4], root_box[5])
        heap = [(lb_root, 0, root_box)]
        counter = 1
        global_lb = lb_root
        n_boxes = 0
        reason = "max_boxes_reached"
        t_start = time.time()

        while heap and n_boxes < self.max_boxes:
            lb, _, (c_theta, c_x, c_y, h_theta, h_x, h_y) = heapq.heappop(heap)
            global_lb = lb

            if lb >= best_sse:
                continue
            if (best_sse - lb) / K <= self.eps_mse:
                reason = "gap_converged"; break
            if h_theta <= self.eps_theta and max(h_x, h_y) <= self.eps_t:
                reason = "resolution_reached"; break

            n_boxes += 1
            ch_theta, ch_x, ch_y = h_theta / 2.0, h_x / 2.0, h_y / 2.0
            for s_theta in (-ch_theta, ch_theta):
                ct = c_theta + s_theta
                for s_x in (-ch_x, ch_x):
                    cx = c_x + s_x
                    for s_y in (-ch_y, ch_y):
                        cy = c_y + s_y
                        child_lb = lower_bound(ct, np.array([cx, cy]),
                                               ch_theta, ch_x, ch_y)

                        if (self.icp_iters_per_box > 0
                                and h_theta < self.icp_only_below_h_theta):
                            it, itt = icp_step(ct, (cx, cy),
                                               self.icp_iters_per_box)
                            sse = eval_sse(it, itt)
                            if sse < best_sse:
                                best_sse, best_theta, best_t = sse, it, itt
                        else:
                            sse = eval_sse(ct, np.array([cx, cy]))
                            if sse < best_sse:
                                best_sse = sse
                                best_theta = ct
                                best_t = np.array([cx, cy])

                        if child_lb < best_sse:
                            heapq.heappush(
                                heap,
                                (child_lb, counter,
                                 (ct, cx, cy, ch_theta, ch_x, ch_y)))
                            counter += 1

        global_lb = (min(global_lb, heap[0][0]) if heap
                     else min(global_lb, best_sse))
        global_lb = min(global_lb, best_sse)
        if not heap and reason == "max_boxes_reached":
            reason = "search_exhausted"

        return {
            "theta_rad": float((best_theta + np.pi) % (2.0 * np.pi) - np.pi),
            "theta_deg": float(np.rad2deg(
                (best_theta + np.pi) % (2.0 * np.pi) - np.pi)),
            "t": best_t,
            "rmse": float(np.sqrt(max(best_sse, 0.0) / K)),
            "upper_bound_sse": float(best_sse),
            "lower_bound_sse": float(global_lb),
            "gap_mse": float(max(best_sse - global_lb, 0.0) / K),
            "boxes_processed": int(n_boxes),
            "k_points": int(K),
            "termination_reason": reason,
            "elapsed_sec": float(time.time() - t_start),
        }

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("尚未 fit")

    def __repr__(self):
        if not self.is_fitted_:
            return "GoICP2D(unfitted)"
        return (f"GoICP2D(theta={self.theta_deg_:.4f} deg, "
                f"t=[{self.offset_[0]:.4f}, {self.offset_[1]:.4f}], "
                f"boxes={self.info_['boxes_processed']})")


# =========================================================
# 7. 三層實驗
# =========================================================
def make_ideal_pair_from_pts(pts_ref, theta_gt_deg, offset_gt):
    """對 pts_ref 做數學旋轉，產生理想 Q。"""
    R = rotation_matrix_2d(np.deg2rad(theta_gt_deg))
    return np.asarray(pts_ref, dtype=float) @ R.T + np.asarray(offset_gt, dtype=float)


def _truth_offset(cfg):
    cx0, cy0 = cfg.width / 2.0, cfg.height / 2.0
    R_gt = rotation_matrix_2d(np.deg2rad(cfg.theta_gt))
    return np.array([cx0, cy0]) - R_gt @ np.array([cx0, cy0]) + np.array([cfg.dx, cfg.dy])


def run_levels(cfg: Config, shapes: List[Shape],
               refine_kw=None, icp_kw=None,
               verbose=True):
    """
    執行三層實驗，回傳 dict of dict。
    """
    if refine_kw is None:
        refine_kw = dict(kernel=7, upsample=15, eta=0.02, pick="centroid")
    if icp_kw is None:
        icp_kw = dict(eps_theta=np.deg2rad(0.1), eps_mse=1e-6,
                      max_boxes=20000, icp_iters_per_box=1,
                      icp_only_below_h_theta=0.2)

    img_a = renderer(cfg, shapes, target=False)
    img_b = renderer(cfg, shapes, target=True)

    pts_a_int = canny_points(img_a, cfg.canny_low, cfg.canny_high)
    pts_b_int = canny_points(img_b, cfg.canny_low, cfg.canny_high)
    pts_a_ref, ok_a = refine_canny_points(img_a, pts_a_int, **refine_kw)
    pts_b_ref, ok_b = refine_canny_points(img_b, pts_b_int, **refine_kw)
    pts_a_use = pts_a_ref[ok_a]
    pts_b_use = pts_b_ref[ok_b]

    offset_gt = _truth_offset(cfg)
    theta_gt = cfg.theta_gt

    results = {}

    # ============================================================
    # Level 0：P 用數學生成，Q = rotate(P) 數學旋轉
    # ============================================================
    t = np.linspace(0, 2*np.pi, 300, endpoint=False)
    r = 1.0 + 0.3*np.cos(3*t) + 0.15*np.sin(5*t)
    pts_p0 = np.column_stack([r*np.cos(t), r*np.sin(t)]) * 150.0 + np.array([320.0, 240.0])
    pts_q0 = make_ideal_pair_from_pts(pts_p0, theta_gt, offset_gt)

    reg0 = GoICP2D(**icp_kw).fit(pts_p0, pts_q0)
    err0 = compute_errors(reg0.theta_deg_, reg0.offset_, theta_gt, offset_gt)
    results["Level 0 (math only)"] = dict(reg=reg0, err=err0,
                                          n_p=len(pts_p0), n_q=len(pts_q0))

    # ============================================================
    # Level 1：P 來自 A 圖 Canny，Q = rotate(P) 數學旋轉
    # ============================================================
    pts_p1 = pts_a_use
    pts_q1 = make_ideal_pair_from_pts(pts_p1, theta_gt, offset_gt)

    reg1 = GoICP2D(**icp_kw).fit(pts_p1, pts_q1)
    err1 = compute_errors(reg1.theta_deg_, reg1.offset_, theta_gt, offset_gt)
    results["Level 1 (+A Canny)"] = dict(reg=reg1, err=err1,
                                         n_p=len(pts_p1), n_q=len(pts_q1))

    # ============================================================
    # Level 2：P 來自 A Canny，Q 來自 B Canny
    # ============================================================
    reg2 = GoICP2D(**icp_kw).fit(pts_a_use, pts_b_use)
    err2 = compute_errors(reg2.theta_deg_, reg2.offset_, theta_gt, offset_gt)
    results["Level 2 (+B Canny)"] = dict(reg=reg2, err=err2,
                                         n_p=len(pts_a_use), n_q=len(pts_b_use))

    # ---- 報告 ----
    if verbose:
        print("=" * 78)
        print(f"三層隔離實驗   theta_gt={theta_gt:+.3f} deg  "
              f"(dx, dy)=({cfg.dx:+.2f}, {cfg.dy:+.2f})")
        print("=" * 78)
        print(f"{'Level':<22} | {'n_p':>5} {'n_q':>5} | "
              f"{'dtheta':>12} | {'dtx':>10} {'dty':>10} {'|dt|':>10} | "
              f"{'boxes':>5} reason")
        print("-" * 78)
        for name, r in results.items():
            e = r["err"]; reg = r["reg"]
            print(f"{name:<22} | {r['n_p']:>5} {r['n_q']:>5} | "
                  f"{e['diff_theta_deg']:>+12.6f} | "
                  f"{e['dx_err']:>+10.5f} {e['dy_err']:>+10.5f} "
                  f"{e['displacement_err']:>10.5f} | "
                  f"{reg.info_['boxes_processed']:>5d} "
                  f"{reg.info_['termination_reason']}")
        print("-" * 78)
        print("解讀：")
        print("  Level 0  d ~ 0        -> GoICP2D 在理想資料下完全精確")
        print("  Level 1  d 小         -> A 圖 Canny/refine 的 bias")
        print("  Level 2  d = L1 + dlt -> B 圖獨立 Canny 額外貢獻的誤差 dlt")
        print("=" * 78)

    return results


# =========================================================
# 8. 主程式
# =========================================================
if __name__ == "__main__":

    print()
    print("################  Case A: theta = +5 deg, t = (0, 0)  ################")
    cfg = Config(theta_gt=5.0, dx=0.0, dy=0.0, blur_sigma=0.8)
    run_levels(cfg, Shape.complex())

    print()
    print("################  Case B: theta = +5 deg, t = (12, -8)  ################")
    cfg = Config(theta_gt=5.0, dx=12.0, dy=-8.0, blur_sigma=0.8)
    run_levels(cfg, Shape.complex())

    print()
    print("################  Case C: theta = +25 deg, t = (0, 0)  ################")
    cfg = Config(theta_gt=25.0, dx=0.0, dy=0.0, blur_sigma=0.8)
    run_levels(cfg, Shape.complex())

    print()
    print("################  Case D: theta = +90 deg, t = (0, 0)  ################")
    cfg = Config(theta_gt=90.0, dx=0.0, dy=0.0, blur_sigma=0.8)
    run_levels(cfg, Shape.complex())