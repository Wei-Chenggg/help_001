"""
複雜 shape 渲染 → Canny → 通用 patch 亞像素細化 → 疊圖對照

物理模型：
    幾何遮罩（超採樣）→ 聯集 → 下採樣（階躍 + 抗鋸齒）
    → 一次性高斯模糊（模擬鏡頭 PSF）
"""
import numpy as np
import cv2
import matplotlib
import matplotlib.pyplot as plt
matplotlib.rcParams["font.family"] = "sans-serif"
matplotlib.rcParams["font.sans-serif"] = [
    "Microsoft JhengHei", "PingFang TC", "Noto Sans CJK TC", "DejaVu Sans",
]
matplotlib.rcParams["axes.unicode_minus"] = False

from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple
from scipy.ndimage import gaussian_filter, label
from scipy.interpolate import RegularGridInterpolator


# =========================================================
# 1. Config
# =========================================================
@dataclass
class Config:
    width: int = 640
    height: int = 480
    theta_gt: float = 0.0
    dx: float = 0.0
    dy: float = 0.0
    supersample: int = 4
    blur_size: int = 7           # truncate 基準
    blur_sigma: float = 0.8      # 全域模糊（模擬鏡頭 PSF）
    canny_low: int = 50
    canny_high: int = 150


# =========================================================
# 2. Shape（純幾何 + 剛體變換 + 形狀庫）
# =========================================================
@dataclass
class Shape:
    """純幾何。不含模糊、不含渲染。"""
    kind: str
    cx: float
    cy: float
    angle: float = 0.0
    kwargs: Dict[str, Any] = field(default_factory=dict)

    # ---------- 幾何：回傳布林遮罩 ----------
    def rasterize(self, xx: np.ndarray, yy: np.ndarray) -> np.ndarray:
        """在給定的座標網格上回傳布林遮罩。"""
        t = np.deg2rad(-self.angle)
        c, s = np.cos(t), np.sin(t)
        dx = xx - self.cx
        dy = yy - self.cy
        u = c * dx - s * dy
        v = s * dx + c * dy

        k = self.kind
        p = self.kwargs

        if k == "circle":
            return (u * u + v * v) <= p["r"] ** 2

        if k == "ring":
            r2 = u * u + v * v
            return (r2 <= p["r_out"] ** 2) & (r2 >= p["r_in"] ** 2)

        if k == "rect":
            return (np.abs(u) <= p["w"] / 2.0) & (np.abs(v) <= p["h"] / 2.0)

        if k == "triangle":
            r_in = p["size"] / 2.0
            normals = [(0.0, 1.0),
                       (np.sqrt(3) / 2.0, -0.5),
                       (-np.sqrt(3) / 2.0, -0.5)]
            m = np.ones_like(u, dtype=bool)
            for nx, ny in normals:
                m &= (nx * u + ny * v) <= r_in
            return m

        if k == "star":
            rr = np.sqrt(u * u + v * v)
            ang = np.arctan2(v, u)
            period = 2.0 * np.pi / p["n_arm"]
            a = np.mod(ang + period / 2.0, period) - period / 2.0
            t_ = np.abs(a) / (period / 2.0)
            r_edge = p["r_out"] * (1.0 - t_) + p["r_in"] * t_
            return rr <= r_edge

        if k == "polygon":
            verts = np.asarray(p["verts"], dtype=float)
            N = len(verts)
            crosses = []
            for i in range(N):
                x1, y1 = verts[i]
                x2, y2 = verts[(i + 1) % N]
                cr = (x2 - x1) * (v - y1) - (y2 - y1) * (u - x1)
                crosses.append(cr)
            arr = np.stack(crosses, axis=0)
            return (arr >= 0).all(axis=0) | (arr <= 0).all(axis=0)

        raise ValueError(f"未知 kind: {k}")

    # ---------- 剛體變換 ----------
    def transformed(self, theta_deg: float, dx: float, dy: float,
                    cx0: float, cy0: float) -> "Shape":
        t = np.deg2rad(theta_deg)
        c, s = np.cos(t), np.sin(t)
        rx = self.cx - cx0
        ry = self.cy - cy0
        nx = c * rx - s * ry
        ny = s * rx + c * ry
        return Shape(
            kind=self.kind,
            cx=nx + cx0 + dx,
            cy=ny + cy0 + dy,
            angle=self.angle + theta_deg,
            kwargs=dict(self.kwargs),
        )

    # =====================================================
    # 形狀庫（classmethod）
    # =====================================================
    @classmethod
    def simple_circle(cls) -> List["Shape"]:
        """單圓，對照組。"""
        return [cls("circle", 320, 240, kwargs=dict(r=150))]

    @classmethod
    def complex(cls) -> List["Shape"]:
        """複雜特徵：星形、三角形、圓環、矩形、小圓。"""
        return [
            cls("star",     180, 150, angle=15,
                kwargs=dict(r_out=65, r_in=28, n_arm=5)),
            cls("triangle", 460, 140, angle=-20,
                kwargs=dict(size=110)),
            cls("ring",     180, 340, angle=0,
                kwargs=dict(r_out=58, r_in=36)),
            cls("rect",     460, 340, angle=30,
                kwargs=dict(w=110, h=60)),
            cls("circle",   320, 245, angle=0,
                kwargs=dict(r=22)),
        ]

    @classmethod
    def lshape(cls) -> List["Shape"]:
        """L 形多邊形。"""
        return [
            cls("polygon", 320, 240, angle=0,
                kwargs=dict(verts=[
                    (-90, -90), ( 30, -90), ( 30, -20),
                    ( 90, -20), ( 90,  90), (-90,  90),
                ])),
        ]


# =========================================================
# 3. Renderer：整體渲染 + 整體模糊
# =========================================================
def renderer(cfg: Config, shapes: List[Shape], target: bool = False) -> np.ndarray:
    """
    物理模型：
        超採樣幾何聯集 → 下採樣（階躍 + 抗鋸齒）→ 一次性高斯模糊
    target=True 時，每個 Shape 先施加 cfg 的剛體真值再光柵化。
    """
    ss = cfg.supersample
    W, H = cfg.width, cfg.height
    W_ss, H_ss = W * ss, H * ss

    # 超採樣座標網格
    x = (np.arange(W_ss) + 0.5) / ss - 0.5
    y = (np.arange(H_ss) + 0.5) / ss - 0.5
    xx, yy = np.meshgrid(x, y)

    # 在超採樣層把全部形狀聯集成一張遮罩
    mask_ss = np.zeros((H_ss, W_ss), dtype=bool)
    cx0, cy0 = W / 2.0, H / 2.0
    for s in shapes:
        if target:
            s = s.transformed(cfg.theta_gt, cfg.dx, cfg.dy, cx0, cy0)
        mask_ss |= s.rasterize(xx, yy)

    # 下採樣 → 階躍 + 抗鋸齒（邊緣變成 1 px 過渡）
    canvas = mask_ss.astype(np.float64) * 255.0
    canvas = canvas.reshape(H, ss, W, ss).mean(axis=(1, 3))

    # 一次性模糊（模擬真實拍攝）
    if cfg.blur_sigma > 0:
        truncate = cfg.blur_size / 2.0 / cfg.blur_sigma
        canvas = gaussian_filter(canvas, sigma=cfg.blur_sigma, truncate=truncate)

    return np.clip(np.rint(canvas), 0, 255).astype(np.uint8).astype(np.float64)


# =========================================================
# 4. Canny（整數點）
# =========================================================
def canny_points(img: np.ndarray, low: int, high: int) -> np.ndarray:
    edges = cv2.Canny(img.astype(np.uint8), low, high)
    ys, xs = np.nonzero(edges)
    return np.column_stack((xs, ys)).astype(np.float64)   # (x, y)


# =========================================================
# 5. 通用 patch 亞像素細化
# =========================================================
def refine_canny_point(img, x, y,
                       kernel=7, upsample=8, eta=0.02,
                       pick="centroid"):
    if kernel % 2 == 0:
        raise ValueError("kernel 必須是奇數")
    half = kernel // 2
    H, W = img.shape
    x0, y0 = int(round(x)), int(round(y))

    if (y0 - half < 0 or x0 - half < 0 or
        y0 + half >= H or x0 + half >= W):
        return None

    patch = img[y0 - half:y0 + half + 1,
                x0 - half:x0 + half + 1].astype(np.float64)
    pmin, pmax = patch.min(), patch.max()
    if pmax - pmin < 1e-8:
        return None
    patch_n = (patch - pmin) / (pmax - pmin)

    ph, pw = patch_n.shape
    gi = RegularGridInterpolator(
        (np.arange(ph), np.arange(pw)), patch_n,
        method="linear", bounds_error=False, fill_value=None,
    )
    ys_u = np.linspace(0, ph - 1, (ph - 1) * upsample + 1)
    xs_u = np.linspace(0, pw - 1, (pw - 1) * upsample + 1)
    YY, XX = np.meshgrid(ys_u, xs_u, indexing="ij")
    patch_up = gi(np.column_stack([YY.ravel(), XX.ravel()])
                  ).reshape(YY.shape)

    mask = np.abs(patch_up - 0.5) < eta
    if not mask.any():
        return None

    iy, ix = np.where(mask)
    gx = xs_u[ix] + (x0 - half)
    gy = ys_u[iy] + (y0 - half)

    if pick == "nearest":
        d2 = (gx - x) ** 2 + (gy - y) ** 2
        k = int(np.argmin(d2))
        return float(gx[k]), float(gy[k])

    if pick == "centroid":
        lbl, n = label(mask)
        best_d2, best_xy = np.inf, None
        for k in range(1, n + 1):
            ii, jj = np.where(lbl == k)
            cx = xs_u[jj].mean() + (x0 - half)
            cy = ys_u[ii].mean() + (y0 - half)
            d2 = (cx - x) ** 2 + (cy - y) ** 2
            if d2 < best_d2:
                best_d2, best_xy = d2, (float(cx), float(cy))
        return best_xy

    raise ValueError("pick 只能是 'nearest' 或 'centroid'")


def refine_canny_points(img, pts, **kw):
    pts = np.asarray(pts, dtype=np.float64)
    out = np.empty_like(pts)
    ok = np.zeros(len(pts), dtype=bool)
    for i, (x, y) in enumerate(pts):
        res = refine_canny_point(img, x, y, **kw)
        if res is None:
            out[i] = (x, y)
        else:
            out[i] = res
            ok[i] = True
    return out, ok


# =========================================================
# 6. 疊圖
# =========================================================
def plot_overlay(img, pts_int, pts_ref, ok,
                 title="",
                 zoom_center: Tuple[float, float] = (320.0, 240.0),
                 zoom_half: float = 40.0):
    fig, axes = plt.subplots(1, 2, figsize=(15, 7))

    ax = axes[0]
    ax.imshow(img, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_int[:, 0], pts_int[:, 1],
               s=5, facecolors="none", edgecolors="cyan",
               linewidths=0.5,
               label=f"Canny 整數點  n={len(pts_int)}")
    ax.scatter(pts_ref[ok, 0], pts_ref[ok, 1],
               s=2, c="red",
               label=f"細化後  n={int(ok.sum())}")
    ax.set_title(f"{title}  —  Overview")
    ax.legend(loc="upper right", fontsize=9)
    ax.set_xlabel("x (px)")
    ax.set_ylabel("y (px)")

    zx, zy = zoom_center
    ax = axes[1]
    ax.imshow(img, cmap="gray", vmin=0, vmax=255, interpolation="none")
    ax.scatter(pts_int[:, 0], pts_int[:, 1],
               s=45, facecolors="none", edgecolors="cyan", linewidths=1.0)
    ax.scatter(pts_ref[ok, 0], pts_ref[ok, 1],
               s=14, c="red")
    ax.set_xlim(zx - zoom_half, zx + zoom_half)
    ax.set_ylim(zy + zoom_half, zy - zoom_half)
    ax.set_title(f"放大區 ({zx:.0f}, {zy:.0f}) ± {zoom_half:.0f}px")
    ax.set_xlabel("x (px)")
    ax.set_ylabel("y (px)")

    plt.tight_layout()
    return fig


# =========================================================
# 7. 一鍵跑
# =========================================================
def run_case(cfg: Config,
             shapes: List[Shape],
             title: str,
             zoom_center: Tuple[float, float] = (320.0, 240.0),
             zoom_half: float = 40.0,
             refine_kw: dict = None,
             show: bool = True):
    if refine_kw is None:
        refine_kw = dict(kernel=7, upsample=8, eta=0.02, pick="centroid")

    img_a = renderer(cfg, shapes, target=False)
    img_b = renderer(cfg, shapes, target=True)

    pts_a_int = canny_points(img_a, cfg.canny_low, cfg.canny_high)
    pts_b_int = canny_points(img_b, cfg.canny_low, cfg.canny_high)

    pts_a_ref, ok_a = refine_canny_points(img_a, pts_a_int, **refine_kw)
    pts_b_ref, ok_b = refine_canny_points(img_b, pts_b_int, **refine_kw)

    print(f"=== {title} ===")
    print(f"  A: Canny {len(pts_a_int)}  → 細化成功 {int(ok_a.sum())}")
    print(f"  B: Canny {len(pts_b_int)}  → 細化成功 {int(ok_b.sum())}")

    if show:
        plot_overlay(img_a, pts_a_int, pts_a_ref, ok_a,
                     title=f"A  {title}",
                     zoom_center=zoom_center, zoom_half=zoom_half)
        plot_overlay(img_b, pts_b_int, pts_b_ref, ok_b,
                     title=f"B  {title} (θ={cfg.theta_gt:.1f}°, "
                           f"t=({cfg.dx:.1f}, {cfg.dy:.1f}))",
                     zoom_center=zoom_center, zoom_half=zoom_half)
        plt.show()

    return (img_a, img_b,
            pts_a_int, pts_a_ref, ok_a,
            pts_b_int, pts_b_ref, ok_b)


# =========================================================
# 8. Main
# =========================================================
if __name__ == "__main__":

    # ---------- Case 1: 單圓 ----------
    # cfg = Config(dx=15.0, dy=-8.0, theta_gt=0.0)
    # run_case(cfg, Shape.simple_circle(),
             # title="單圓",
             # zoom_center=(cfg.width / 2 + 150, cfg.height / 2),
             # zoom_half=20)

    # ---------- Case 2: 複雜形狀 + 旋轉平移 ----------
    cfg = Config(theta_gt=25.0, dx=12.0, dy=-8.0, blur_sigma=0.8)
    run_case(cfg, Shape.complex(),
             title="複雜形狀",
             zoom_center=(180, 150),
             zoom_half=70)

    # ---------- Case 3: L 形 ----------
    # cfg = Config(theta_gt=-30.0, dx=20.0, dy=15.0)
    # run_case(cfg, Shape.lshape(),
             # title="L 形",
             # zoom_center=(320, 240),
             # zoom_half=120)