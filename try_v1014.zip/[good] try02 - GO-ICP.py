"""
2D 剛性點集全域配準工具
============================================================
- ShapeGenerator : 以極座標 sin/cos 級數產生複雜封閉輪廓
- GoICP2D        : 用 BnB 全域搜尋 E_nearest 的最小值
"""

import time
import heapq
import numpy as np
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch


# ============================================================
# 共用工具
# ============================================================
def rotation_matrix_2d(theta):
    """計算二維旋轉矩陣 R(theta)。"""
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s], [s, c]])


def _as_pts(pts, name="pts"):
    arr = np.asarray(pts, dtype=float)
    if arr.ndim != 2 or arr.shape[1] != 2:
        raise ValueError(f"{name} 必須是 (n,2)，收到 {arr.shape}")
    if len(arr) == 0:
        raise ValueError(f"{name} 不能是空點集")
    if not np.isfinite(arr).all():
        raise ValueError(f"{name} 包含 NaN 或 Inf")
    return arr


def _trim(sq, trim_k):
    if trim_k is None or int(trim_k) >= len(sq):
        return sq
    k = max(1, int(trim_k))
    return np.partition(sq, k - 1)[:k]


# ============================================================
# ShapeGenerator
# ============================================================
class ShapeGenerator:
    """
    以 r(φ) = r0 + Σ a_k cos(f_k φ) + Σ b_k sin(g_k φ) 產生封閉輪廓。

    參數
    ----
    r0        : 基準半徑
    cos_terms : [(amp, freq), ...]，對應 amp*cos(freq*φ)
    sin_terms : [(amp, freq), ...]，對應 amp*sin(freq*φ)
    seed      : 隨機種子
    """

    def __init__(self, r0=1.0, cos_terms=None, sin_terms=None, seed=None):
        self.r0 = float(r0)
        self.cos_terms = list(cos_terms) if cos_terms else []
        self.sin_terms = list(sin_terms) if sin_terms else []
        self.seed = seed

    def radial(self, phi):
        """計算 r(φ)，支援純量或陣列。"""
        phi = np.asarray(phi, dtype=float)
        r = np.full_like(phi, self.r0, dtype=float)
        for amp, freq in self.cos_terms:
            r = r + float(amp) * np.cos(float(freq) * phi)
        for amp, freq in self.sin_terms:
            r = r + float(amp) * np.sin(float(freq) * phi)
        return r

    def sample(self, n, phase=0.0, endpoint=False, order="ccw"):
        """取樣 n 個輪廓點。"""
        n = int(n)
        if n < 2:
            raise ValueError(f"n 至少為 2，收到 {n}")
        phi = np.linspace(0.0, 2.0 * np.pi, n, endpoint=endpoint) + float(phase)
        r = self.radial(phi)
        pts = np.column_stack([r * np.cos(phi), r * np.sin(phi)])

        if order == "cw":
            pts = pts[::-1]
        elif order == "random":
            rng = np.random.default_rng(self.seed)
            pts = pts[rng.permutation(len(pts))]
        elif order != "ccw":
            raise ValueError(f"order 必須是 ccw/cw/random，收到 {order}")
        return pts

    def make_pair(self,
                  n_ref=60, n_now=50,
                  theta=0.0, offset=(0.0, 0.0),
                  phase_shift=0.0, noise=0.0,
                  shuffle=True, rng=None, return_truth=False):
        """產生一對 (P, Q) 測試點集。"""
        if rng is None:
            rng = np.random.default_rng(self.seed)

        P = self.sample(int(n_ref), phase=0.0, order="ccw")
        Q = self.sample(int(n_now), phase=float(phase_shift), order="ccw")

        R = rotation_matrix_2d(float(theta))
        Q = Q @ R.T + np.asarray(offset, dtype=float)

        if noise > 0:
            Q = Q + rng.normal(0.0, float(noise), Q.shape)

        if shuffle:
            Q = Q[rng.permutation(len(Q))]

        if return_truth:
            truth = {"theta": float(theta),
                     "offset": np.asarray(offset, dtype=float),
                     "R": R}
            return P, Q, truth
        return P, Q

    @classmethod
    def random(cls, n_terms=4, freq_range=(1, 8), amp_range=(-0.7, 0.7),
               r0=1.0, seed=None, ensure_asymmetric=True):
        """隨機產生一個複雜形狀。"""
        rng = np.random.default_rng(seed)
        cos_terms, sin_terms = [], []

        for _ in range(int(n_terms)):
            freq = int(rng.integers(freq_range[0], freq_range[1] + 1))
            amp = float(rng.uniform(amp_range[0], amp_range[1]))
            if rng.random() < 0.5:
                cos_terms.append((amp, freq))
            else:
                sin_terms.append((amp, freq))

        if ensure_asymmetric and not sin_terms:
            freq = int(rng.integers(freq_range[0], freq_range[1] + 1))
            amp = float(rng.uniform(amp_range[0], amp_range[1]))
            sin_terms.append((amp, freq))

        return cls(r0=r0, cos_terms=cos_terms, sin_terms=sin_terms, seed=seed)

    def preview(self, n=400, ax=None, label=None, **kwargs):
        pts = self.sample(n, order="ccw")
        if ax is None:
            _, ax = plt.subplots(figsize=(5, 5))
        ax.plot(pts[:, 0], pts[:, 1], **kwargs)
        if label:
            ax.set_title(label)
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.3)
        return ax

    def to_dict(self):
        return {"r0": self.r0,
                "cos_terms": [list(t) for t in self.cos_terms],
                "sin_terms": [list(t) for t in self.sin_terms],
                "seed": self.seed}

    @classmethod
    def from_dict(cls, d):
        return cls(r0=d["r0"],
                   cos_terms=[tuple(t) for t in d["cos_terms"]],
                   sin_terms=[tuple(t) for t in d["sin_terms"]],
                   seed=d.get("seed"))

    def __repr__(self):
        return (f"ShapeGenerator(r0={self.r0}, "
                f"cos_terms={self.cos_terms}, "
                f"sin_terms={self.sin_terms})")


# ============================================================
# GoICP2D
# ============================================================
class GoICP2D:
    """二維 Go-ICP：BnB 全域搜尋 E_nearest 的最小值。"""

    def __init__(self,
                 trans_bound=1.0,
                 eps_mse=1e-4,
                 eps_theta=np.deg2rad(0.5),
                 eps_t=1e-3,
                 max_boxes=20000,
                 icp_iters_per_box=1,
                 icp_only_below_h_theta=0.2,
                 trim_ratio=1.0):
        self.trans_bound = float(trans_bound)
        self.eps_mse = float(eps_mse)
        self.eps_theta = float(eps_theta)
        self.eps_t = float(eps_t)
        self.max_boxes = int(max_boxes)
        self.icp_iters_per_box = int(icp_iters_per_box)
        self.icp_only_below_h_theta = float(icp_only_below_h_theta)
        self.trim_ratio = float(trim_ratio)

        self.is_fitted_ = False
        self.theta_ = None
        self.theta_deg_ = None
        self.R_ = None
        self.offset_ = None
        self.rmse_ = None
        self.info_ = None

        self._c_truth = None
        self._c_now = None
        self._scale = None

    # ---------- fit ----------
    def fit(self, pts_truth, pts_now):
        P = _as_pts(pts_truth, "pts_truth")
        Q = _as_pts(pts_now, "pts_now")

        c_truth = P.mean(axis=0)
        c_now = Q.mean(axis=0)
        s = max(float(np.max(np.linalg.norm(P - c_truth, axis=1))),
                float(np.max(np.linalg.norm(Q - c_now, axis=1))))
        if s <= 0:
            raise ValueError("兩組點集都退化成單點，無法決定尺度")

        Pn = (P - c_truth) / s
        Qn = (Q - c_now) / s

        res = self._go_icp_2d(Pn, Qn)

        R = rotation_matrix_2d(res["theta_rad"])
        offset = c_now - c_truth @ R.T + s * res["t"]

        self.theta_ = float(res["theta_rad"])
        self.theta_deg_ = float(np.rad2deg(self.theta_))
        self.R_ = R
        self.offset_ = offset
        self.rmse_ = float(res["rmse"] * s)
        self.info_ = dict(res)
        self.info_["scale"] = s

        self._c_truth = c_truth
        self._c_now = c_now
        self._scale = s
        self.is_fitted_ = True
        return self

    def fit_transform(self, pts_truth, pts_now):
        self.fit(pts_truth, pts_now)
        return self.transform(pts_truth)

    # ---------- 應用 ----------
    def transform(self, pts):
        self._check_fitted()
        return np.asarray(pts, dtype=float) @ self.R_.T + self.offset_

    def inverse_transform(self, pts):
        self._check_fitted()
        return (np.asarray(pts, dtype=float) - self.offset_) @ self.R_

    # ---------- 評估 ----------
    def score(self, pts_truth, pts_now, trim_k=None):
        self._check_fitted()
        P = _as_pts(pts_truth, "pts_truth")
        Q = _as_pts(pts_now, "pts_now")
        tree = cKDTree(Q)
        Pw = self.transform(P)
        d, _ = tree.query(Pw, k=1)
        return float(np.sum(_trim(d ** 2, trim_k)))

    def rmse(self, pts_truth, pts_now):
        P = _as_pts(pts_truth, "pts_truth")
        sse = self.score(pts_truth, pts_now)
        return float(np.sqrt(sse / len(P)))

    # ---------- 序列化 ----------
    def to_dict(self):
        self._check_fitted()
        return {
            "theta_rad": self.theta_,
            "theta_deg": self.theta_deg_,
            "offset": self.offset_.tolist(),
            "rmse": self.rmse_,
            "scale": self._scale,
            "c_truth": self._c_truth.tolist(),
            "c_now": self._c_now.tolist(),
            "info": self.info_,
            "params": {
                "trans_bound": self.trans_bound,
                "eps_mse": self.eps_mse,
                "eps_theta": self.eps_theta,
                "eps_t": self.eps_t,
                "max_boxes": self.max_boxes,
                "icp_iters_per_box": self.icp_iters_per_box,
                "icp_only_below_h_theta": self.icp_only_below_h_theta,
                "trim_ratio": self.trim_ratio,
            },
        }

    @classmethod
    def from_dict(cls, d):
        obj = cls(**d["params"])
        obj.theta_ = float(d["theta_rad"])
        obj.theta_deg_ = float(d["theta_deg"])
        obj.offset_ = np.asarray(d["offset"], dtype=float)
        obj.rmse_ = float(d["rmse"])
        obj.R_ = rotation_matrix_2d(obj.theta_)
        obj.info_ = dict(d["info"])
        obj._scale = float(d["scale"])
        obj._c_truth = np.asarray(d["c_truth"], dtype=float)
        obj._c_now = np.asarray(d["c_now"], dtype=float)
        obj.is_fitted_ = True
        return obj

    # ---------- 視覺化 ----------
    def visualize(self, pts_truth, pts_now,
                  title="Go-ICP 2D Registration",
                  show_correspondence=True,
                  show_arrows=True,
                  arrow_step=5,
                  figsize=(13, 6),
                  save_path=None):
        self._check_fitted()
        P = _as_pts(pts_truth, "pts_truth")
        Q = _as_pts(pts_now, "pts_now")
        P_aligned = self.transform(P)

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        ax = axes[0]
        ax.scatter(P[:, 0], P[:, 1], s=14, c="tab:blue",
                   label="pts_truth (原始)")
        ax.scatter(Q[:, 0], Q[:, 1], s=14, c="tab:orange",
                   label="pts_now (目標)")
        ax.set_title("Before registration")
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="best", fontsize=9)

        ax = axes[1]
        ax.scatter(Q[:, 0], Q[:, 1], s=14, c="tab:orange",
                   label="pts_now (目標)")
        ax.scatter(P_aligned[:, 0], P_aligned[:, 1], s=14, c="tab:green",
                   label="pts_truth (已對齊)")

        if show_correspondence:
            tree = cKDTree(Q)
            d, idx = tree.query(P_aligned, k=1)
            d2 = d ** 2
            Q_match = Q[idx]
            thr = np.percentile(d2, 90)
            for i in range(len(P_aligned)):
                if d2[i] > thr:
                    ax.plot([P_aligned[i, 0], Q_match[i, 0]],
                            [P_aligned[i, 1], Q_match[i, 1]],
                            c="tab:red", lw=0.6, alpha=0.5)

        if show_arrows:
            for i in range(0, len(P), max(1, arrow_step)):
                ax.add_patch(FancyArrowPatch(
                    P[i], P_aligned[i],
                    arrowstyle="-|>", mutation_scale=8,
                    color="tab:purple", alpha=0.5, lw=0.8
                ))

        ax.set_title("After registration")
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="best", fontsize=9)

        txt = (
            f"theta = {self.theta_deg_:.3f} deg\n"
            f"offset = [{self.offset_[0]:.4f}, {self.offset_[1]:.4f}]\n"
            f"RMSE (orig) = {self.rmse_:.4e}\n"
            f"boxes = {self.info_['boxes_processed']}   "
            f"reason = {self.info_['termination_reason']}\n"
            f"elapsed = {self.info_['elapsed_sec']:.2f} s"
        )
        fig.text(0.5, 0.01, txt, ha="center", va="bottom",
                 fontsize=10, family="monospace")

        fig.suptitle(title, fontsize=13)
        fig.tight_layout(rect=[0, 0.08, 1, 1])

        if save_path:
            fig.savefig(save_path, dpi=150)
            plt.close(fig)
        else:
            plt.show()

    # ---------- BnB ----------
    def _go_icp_2d(self, P, Q):
        n_pts = len(P)
        K = (n_pts if self.trim_ratio >= 1.0
             else max(1, min(n_pts, int(round(self.trim_ratio * n_pts)))))
        trim_k = K if K < n_pts else None
        norm_p = np.linalg.norm(P, axis=1)

        tree = cKDTree(Q)

        def eval_sse(theta, t):
            Pw = P @ rotation_matrix_2d(theta).T + t
            d, _ = tree.query(Pw, k=1)
            return float(np.sum(_trim(d ** 2, trim_k)))

        def lower_bound(theta, t, h_theta, h_x, h_y):
            Pw = P @ rotation_matrix_2d(theta).T + t
            d, _ = tree.query(Pw, k=1)
            gamma = (2.0 * np.sin(min(np.sqrt(3.0) * h_theta, np.pi) / 2.0)
                     * norm_p + np.sqrt(h_x ** 2 + h_y ** 2))
            return float(np.sum(_trim(np.maximum(d - gamma, 0.0) ** 2, trim_k)))

        def icp_step(theta0, t0, max_iters):
            cur_theta = float(theta0)
            cur_t = np.asarray(t0, dtype=float)
            for _ in range(int(max_iters)):
                Pw = P @ rotation_matrix_2d(cur_theta).T + cur_t
                d, idx = tree.query(Pw, k=1)
                d2 = d ** 2
                if trim_k is not None and trim_k < len(d2):
                    sel = np.argpartition(d2, trim_k - 1)[:trim_k]
                else:
                    sel = np.arange(len(d2))
                p_sel = P[sel]
                q_sel = Q[idx[sel]]
                pm = p_sel.mean(axis=0)
                qm = q_sel.mean(axis=0)
                H = (p_sel - pm).T @ (q_sel - qm)
                cur_theta = float(np.arctan2(H[0, 1] - H[1, 0],
                                             H[0, 0] + H[1, 1]))
                cur_t = qm - pm @ rotation_matrix_2d(cur_theta).T
            return cur_theta, cur_t

        best_theta = 0.0
        best_t = np.zeros(2)
        best_sse = eval_sse(best_theta, best_t)
        icp_theta, icp_t = icp_step(0.0, best_t, max_iters=20)
        icp_sse = eval_sse(icp_theta, icp_t)
        if icp_sse < best_sse:
            best_sse = icp_sse
            best_theta = icp_theta
            best_t = icp_t

        root_box = (0.0, 0.0, 0.0,
                    float(np.pi), float(self.trans_bound), float(self.trans_bound))
        lb_root = lower_bound(0.0, np.zeros(2),
                              root_box[3], root_box[4], root_box[5])
        heap = [(lb_root, 0, root_box)]
        counter = 1
        global_lb = lb_root
        n_boxes = 0
        reason = "max_boxes_reached"
        t_start = time.time()

        while heap and n_boxes < self.max_boxes:
            lb, _, (c_theta, c_x, c_y, h_theta, h_x, h_y) = heapq.heappop(heap)
            global_lb = lb

            if lb >= best_sse:
                continue
            if (best_sse - lb) / K <= self.eps_mse:
                reason = "gap_converged"
                break
            if h_theta <= self.eps_theta and max(h_x, h_y) <= self.eps_t:
                reason = "resolution_reached"
                break

            n_boxes += 1
            ch_theta = h_theta / 2.0
            ch_x = h_x / 2.0
            ch_y = h_y / 2.0

            for s_theta in (-ch_theta, ch_theta):
                ct = c_theta + s_theta
                for s_x in (-ch_x, ch_x):
                    cx = c_x + s_x
                    for s_y in (-ch_y, ch_y):
                        cy = c_y + s_y

                        child_lb = lower_bound(ct, np.array([cx, cy]),
                                               ch_theta, ch_x, ch_y)

                        if (self.icp_iters_per_box > 0
                                and h_theta < self.icp_only_below_h_theta):
                            it, itt = icp_step(ct, (cx, cy),
                                               self.icp_iters_per_box)
                            sse = eval_sse(it, itt)
                            if sse < best_sse:
                                best_sse = sse
                                best_theta = it
                                best_t = itt
                        else:
                            sse = eval_sse(ct, np.array([cx, cy]))
                            if sse < best_sse:
                                best_sse = sse
                                best_theta = ct
                                best_t = np.array([cx, cy])

                        if child_lb < best_sse:
                            heapq.heappush(
                                heap,
                                (child_lb, counter,
                                 (ct, cx, cy, ch_theta, ch_x, ch_y)))
                            counter += 1

        if heap:
            global_lb = min(global_lb, heap[0][0])
        else:
            reason = "search_exhausted"
        global_lb = min(global_lb, best_sse)

        return {
            "theta_rad": float((best_theta + np.pi) % (2.0 * np.pi) - np.pi),
            "theta_deg": float(np.rad2deg(
                (best_theta + np.pi) % (2.0 * np.pi) - np.pi)),
            "t": best_t,
            "rmse": float(np.sqrt(max(best_sse, 0.0) / K)),
            "upper_bound_sse": float(best_sse),
            "lower_bound_sse": float(global_lb),
            "gap_mse": float(max(best_sse - global_lb, 0.0) / K),
            "boxes_processed": int(n_boxes),
            "k_points": int(K),
            "termination_reason": reason,
            "elapsed_sec": float(time.time() - t_start),
        }

    # ---------- 內部 ----------
    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("尚未 fit，請先呼叫 fit(pts_truth, pts_now)")

    def __repr__(self):
        if not self.is_fitted_:
            return (f"GoICP2D(unfitted, "
                    f"eps_theta={np.rad2deg(self.eps_theta):.3f}deg, "
                    f"max_boxes={self.max_boxes})")
        return (f"GoICP2D(theta={self.theta_deg_:.3f}deg, "
                f"offset=[{self.offset_[0]:.4f}, {self.offset_[1]:.4f}], "
                f"rmse={self.rmse_:.4e}, "
                f"boxes={self.info_['boxes_processed']}, "
                f"reason={self.info_['termination_reason']})")


# ============================================================
# 測試
# ============================================================
if __name__ == "__main__":
    # ============================================================
    # 測試 1：固定形狀（原本的合成資料）
    # ============================================================
    print("=" * 70)
    print("Test 1: 固定形狀 (5 項 sin/cos 級數)")
    print("=" * 70)

    gen = ShapeGenerator(
        r0=1.0,
        cos_terms=[(0.35, 3), (0.15, 1), (-0.7, 5)],
    )
    print(gen)

    theta_gt = np.deg2rad(150.0)
    offset_gt = np.array([0.35, -0.22])

    P, Q, truth = gen.make_pair(
        n_ref=60, n_now=50,
        theta=theta_gt, offset=offset_gt,
        phase_shift=0.03,
        shuffle=True,
        return_truth=True,
    )

    reg = GoICP2D(
        eps_theta=np.deg2rad(0.5),
        eps_mse=1e-4,
        max_boxes=20000,
        icp_iters_per_box=1,
        icp_only_below_h_theta=0.2,
    )
    reg.fit(P, Q)

    print(reg)
    print(f"theta      = {reg.theta_deg_:.5f} deg  "
          f"(GT {np.rad2deg(theta_gt):.5f} deg)")
    print(f"offset     = [{reg.offset_[0]:.5f}, {reg.offset_[1]:.5f}]  "
          f"(GT [{offset_gt[0]:.5f}, {offset_gt[1]:.5f}])")
    print(f"rmse       = {reg.rmse_:.6e}")
    print(f"elapsed    = {reg.info_['elapsed_sec']:.2f} s")

    # 反變換檢驗
    back = reg.inverse_transform(reg.transform(P))
    print(f"inverse max err = {np.max(np.abs(back - P)):.3e}")

    # 序列化檢驗
    reg2 = GoICP2D.from_dict(reg.to_dict())
    print(f"restored   : {reg2}")

    reg.visualize(
        P, Q,
        title="Test 1: 固定形狀",
        show_correspondence=True,
        show_arrows=True,
        arrow_step=5,
        save_path=None,
    )

    # ============================================================
    # 測試 2：隨機形狀批次
    # ============================================================
    print()
    print("=" * 70)
    print("Test 2: 20 個隨機形狀批次測試")
    print("=" * 70)

    n_cases = 20
    theta_gt = np.deg2rad(123.0)
    offset_gt = np.array([0.4, -0.3])

    results = []
    t0 = time.time()
    for i in range(n_cases):
        gen_i = ShapeGenerator.random(n_terms=4, seed=i)
        P_i, Q_i, truth_i = gen_i.make_pair(
            n_ref=80, n_now=60,
            theta=theta_gt, offset=offset_gt,
            phase_shift=0.0,
            noise=0.005,
            shuffle=True,
            return_truth=True,
        )
        reg_i = GoICP2D(eps_theta=np.deg2rad(0.5), max_boxes=20000)
        reg_i.fit(P_i, Q_i)

        dtheta = np.rad2deg(reg_i.theta_ - truth_i["theta"])
        dt = np.linalg.norm(reg_i.offset_ - truth_i["offset"])
        results.append((i, dtheta, dt, reg_i.info_["elapsed_sec"],
                        reg_i.info_["termination_reason"]))

        print(f"[{i:2d}] dtheta={dtheta:+8.4f}deg  "
              f"dt={dt:.4e}  "
              f"t={reg_i.info_['elapsed_sec']:.2f}s  "
              f"{reg_i.info_['termination_reason']}")

    total_t = time.time() - t0
    dthetas = np.array([r[1] for r in results])
    dts = np.array([r[2] for r in results])

    print()
    print(f"--- 統計（{n_cases} 個形狀，總耗時 {total_t:.2f}s）---")
    print(f"|dtheta| max = {np.max(np.abs(dthetas)):.4f} deg")
    print(f"|dtheta| avg = {np.mean(np.abs(dthetas)):.4f} deg")
    print(f"dt     max = {np.max(dts):.4e}")
    print(f"dt     avg = {np.mean(dts):.4e}")

    # ============================================================
    # 測試 3：預覽隨機形狀
    # ============================================================
    print()
    print("=" * 70)
    print("Test 3: 預覽 6 個隨機形狀")
    print("=" * 70)

    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    for ax, i in zip(axes.flat, range(6)):
        gen_i = ShapeGenerator.random(n_terms=5, seed=i)
        gen_i.preview(400, ax=ax, label=f"seed={i}", lw=1.5, color="tab:blue")
        print(f"seed={i}: {gen_i}")
    plt.tight_layout()
    plt.show()