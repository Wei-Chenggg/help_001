import heapq
import time
import numpy as np
from scipy.spatial import KDTree


def rotation_matrix_2d(theta: float) -> np.ndarray:
    """計算二維旋轉矩陣 R(theta)。"""
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s], [s, c]])


def icp_2d_step(P: np.ndarray, Q_tree: KDTree, Q_pts: np.ndarray, 
                theta: float, t: np.ndarray, max_iters: int = 5):
    """局部 2D ICP 迭代（使用 closed-form atan2 解），用於快速更新全域上界。"""
    cur_theta = theta
    cur_t = np.array(t, dtype=float)
    
    for _ in range(max_iters):
        R = rotation_matrix_2d(cur_theta)
        P_trans = P @ R.T + cur_t
        _, idxs = Q_tree.query(P_trans)
        matched_Q = Q_pts[idxs]
        
        p_mean = np.mean(P, axis=0)
        q_mean = np.mean(matched_Q, axis=0)
        P_centered = P - p_mean
        Q_centered = matched_Q - q_mean
        
        H = P_centered.T @ Q_centered
        new_theta = np.arctan2(H[0, 1] - H[1, 0], H[0, 0] + H[1, 1])
        new_R = rotation_matrix_2d(new_theta)
        new_t = q_mean - p_mean @ new_R.T
        
        cur_theta = new_theta
        cur_t = new_t
        
    return cur_theta, cur_t


def eval_sse(P: np.ndarray, Q_tree: KDTree, theta: float, t: np.ndarray, trim_k: int = None) -> float:
    """計算目標姿態下的最近鄰殘差平方和 (SSE)。"""
    R = rotation_matrix_2d(theta)
    P_trans = P @ R.T + t
    dists, _ = Q_tree.query(P_trans)
    sq_dists = dists ** 2
    if trim_k is not None and trim_k < len(P):
        sq_dists = np.partition(sq_dists, trim_k - 1)[:trim_k]
    return float(np.sum(sq_dists))


def go_icp_2d(P: np.ndarray, Q: np.ndarray, 
              trans_bound: float = 1.0, 
              eps_mse: float = 1e-5, 
              eps_theta: float = np.deg2rad(0.05), 
              eps_t: float = 1e-3, 
              max_boxes: int = 20000, 
              icp_iters_per_box: int = 3, 
              trim_ratio: float = 1.0) -> dict:
    """
    Go-ICP 二維分支定界核心搜尋函式。
    """
    N = len(P)
    K = int(np.round(trim_ratio * N)) if trim_ratio < 1.0 else N
    norm_p = np.linalg.norm(P, axis=1)
    Q_tree = KDTree(Q)
    box_counter = 0

    best_theta = 0.0
    best_t = np.zeros(2)
    best_sse = eval_sse(P, Q_tree, best_theta, best_t, trim_k=K)
    
    cand_theta, cand_t = icp_2d_step(P, Q_tree, Q, best_theta, best_t, max_iters=20)
    cand_sse = eval_sse(P, Q_tree, cand_theta, cand_t, trim_k=K)
    if cand_sse < best_sse:
        best_sse = cand_sse
        best_theta = cand_theta
        best_t = cand_t

    def compute_lower_bound(theta_0, tx_0, ty_0, h_theta, h_x, h_y):
        gamma_r = 2.0 * norm_p * np.sin(min(h_theta, np.pi) / 2.0)
        gamma_t = np.sqrt(h_x**2 + h_y**2)
        gamma_i = gamma_r + gamma_t
        
        R_0 = rotation_matrix_2d(theta_0)
        t_0 = np.array([tx_0, ty_0])
        P_0 = P @ R_0.T + t_0
        d_Q_0, _ = Q_tree.query(P_0)
        
        ell_i = np.maximum(d_Q_0 - gamma_i, 0.0)
        sq_ell = ell_i ** 2
        if K < N:
            sq_ell = np.partition(sq_ell, K - 1)[:K]
        return float(np.sum(sq_ell))

    root_box = (0.0, 0.0, 0.0, np.pi, trans_bound, trans_bound)
    lb_root = compute_lower_bound(*root_box)
    
    pq = []
    heapq.heappush(pq, (lb_root, box_counter, *root_box))
    box_counter += 1
    
    num_processed = 0

    while pq and num_processed < max_boxes:
        lb, _, th0, tx0, ty0, h_th, hx, hy = heapq.heappop(pq)
        
        if lb >= best_sse:
            continue
            
        gap_mse = (best_sse - lb) / K
        if gap_mse <= eps_mse:
            break
            
        if h_th <= eps_theta and max(hx, hy) <= eps_t:
            break
            
        num_processed += 1

        child_h_th = h_th / 2.0
        child_hx = hx / 2.0
        child_hy = hy / 2.0
        
        for d_th in [-child_h_th, child_h_th]:
            child_th = th0 + d_th
            for d_x in [-child_hx, child_hx]:
                child_tx = tx0 + d_x
                for d_y in [-child_hy, child_hy]:
                    child_ty = ty0 + d_y
                    
                    child_lb = compute_lower_bound(child_th, child_tx, child_ty, 
                                                   child_h_th, child_hx, child_hy)
                    if child_lb >= best_sse:
                        continue
                        
                    child_sse = eval_sse(P, Q_tree, child_th, np.array([child_tx, child_ty]), trim_k=K)
                    if child_sse < best_sse:
                        best_sse = child_sse
                        best_theta = child_th
                        best_t = np.array([child_tx, child_ty])
                        
                    if icp_iters_per_box > 0:
                        icp_th, icp_t = icp_2d_step(P, Q_tree, Q, child_th, [child_tx, child_ty], 
                                                     max_iters=icp_iters_per_box)
                        icp_sse = eval_sse(P, Q_tree, icp_th, icp_t, trim_k=K)
                        if icp_sse < best_sse:
                            best_sse = icp_sse
                            best_theta = icp_th
                            best_t = icp_t
                            
                    if child_lb < best_sse:
                        heapq.heappush(pq, (child_lb, box_counter, 
                                          child_th, child_tx, child_ty, 
                                          child_h_th, child_hx, child_hy))
                        box_counter += 1

    return {
        "theta_rad": best_theta,
        "t": best_t,
        "rmse": float(np.sqrt(best_sse / K))
    }


def find_rigid_transform_2d(
    pts_now: np.ndarray, 
    pts_truth: np.ndarray,
    trans_bound: float = 1.0,
    trim_ratio: float = 1.0,
    max_boxes: int = 15000
) -> tuple[float, np.ndarray]:
    """
    輸入:
      pts_now    : np.ndarray, shape (m, 2)  # 當前待配準點集
      pts_truth  : np.ndarray, shape (n, 2)  # 真值/基準點集 (目標)
      trans_bound: float                     # 正規化空間平移搜尋半徑 (預設 1.0)
      trim_ratio : float                     # 保留內點比例 (0.0 ~ 1.0，預設 1.0)
      max_boxes  : int                       # 搜尋盒子上限預算 (預設 15000)

    輸出:
      theta      : float                     # 旋轉角度 (單位：rad)
      offset     : np.ndarray, shape (2,)    # 平移向量 [tx, ty]

    變換定義:
      pts_aligned = pts_now @ R(theta).T + offset ≈ pts_truth
    """
    # 1. 中心化與尺度正規化
    c_now = np.mean(pts_now, axis=0)
    c_truth = np.mean(pts_truth, axis=0)
    
    scale_now = np.max(np.linalg.norm(pts_now - c_now, axis=1))
    scale_truth = np.max(np.linalg.norm(pts_truth - c_truth, axis=1))
    s = max(scale_now, scale_truth)
    if s == 0:
        s = 1.0

    p_norm = (pts_now - c_now) / s
    q_norm = (pts_truth - c_truth) / s

    # 2. 執行 2D Go-ICP 全域搜尋
    res = go_icp_2d(
        P=p_norm, 
        Q=q_norm, 
        trans_bound=trans_bound,
        trim_ratio=trim_ratio,
        max_boxes=max_boxes
    )

    # 3. 還原至原始物理座標系平移
    theta = float(res["theta_rad"])
    R_opt = rotation_matrix_2d(theta)
    offset = c_truth - c_now @ R_opt.T + s * res["t"]

    return theta, offset


if __name__ == "__main__":
    np.random.seed(42)

    # 模擬輸入資料 (m != n)
    m = 120  # pts_now 點數
    n = 150  # pts_truth 點數

    # 生成位於大座標像素 (1500, 2500) 附近的點群
    pts_now = np.random.uniform(-40, 40, size=(m, 2)) + np.array([1500.0, 2500.0])

    # 設定真值變換: 73 度旋轉，平移 [12.5, -8.3]
    true_theta_deg = 73.0
    true_theta_rad = np.deg2rad(true_theta_deg)
    true_R = rotation_matrix_2d(true_theta_rad)
    true_offset = np.array([12.5, -8.3])

    # 目標點集包含真值對齊點 + 高斯雜訊 + 額外背景干擾點
    aligned_pts = pts_now @ true_R.T + true_offset
    noise = np.random.normal(0, 0.3, size=(m, 2))
    extra_pts = np.random.uniform(-50, 50, size=(n - m, 2)) + np.mean(aligned_pts, axis=0)
    pts_truth = np.vstack([aligned_pts + noise, extra_pts])

    print(f"輸入 pts_now.shape   : {pts_now.shape}")
    print(f"輸入 pts_truth.shape : {pts_truth.shape}")

    # 呼叫 API
    t_start = time.time()
    theta, offset = find_rigid_transform_2d(pts_now, pts_truth)
    cost_time = time.time() - t_start

    # 檢視輸出
    print("\nAPI 輸出結果:")
    print(f"  theta (rad) : {theta:.6f} (真值: {true_theta_rad:.6f})")
    print(f"  theta (deg) : {np.rad2deg(theta):.4f}° (真值: {true_theta_deg:.1f}°)")
    print(f"  offset      : {offset} (真值: {true_offset})")
    print(f"  耗時        : {cost_time:.2f} 秒")